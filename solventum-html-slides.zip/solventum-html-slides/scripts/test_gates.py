#!/usr/bin/env python3
"""Controls for scripts/check_deck.py.

    python3 scripts/test_gates.py

Every gate in check_deck.py exists because a specific defect shipped once. This
file proves each one still fires on that defect, and — just as important — stays
quiet on a legitimate variation.

The quiet half is the half that matters. A gate that cries wolf gets skimmed past,
and then it hides the real defect when it finally appears. Two measured examples
from building this version, both now controls below:

  * the flex-shrink gate fired on assets/onepager.html for all ten components, a
    file with no .slide-body at all, so it cannot have the bug described;
  * the foreign-brand gate fired on every file, because this skill's own CSS
    comment names the icon file `snowflake_trail`.

Exit code is non-zero if any control misbehaves.
"""
import pathlib
import re
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import importlib.util

_spec = importlib.util.spec_from_file_location(
    "check_deck", pathlib.Path(__file__).resolve().parent / "check_deck.py")
cd = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cd)

SKILL = pathlib.Path(__file__).resolve().parent.parent
SHELL = (SKILL / "assets/shell.html").read_text(encoding="utf-8")
ONEPAGER = (SKILL / "assets/onepager.html").read_text(encoding="utf-8")
EXAMPLE = (SKILL / "examples/example-deck.html").read_text(encoding="utf-8")

results = []


def control(name, text, gate, must_fire, needle="", scope="all"):
    """Run one gate over one document and assert whether it reported.

    `scope` matters. Several gates deliberately warn rather than error, and a
    control that lumps warnings in with errors cannot express "this should warn
    but must not fail the build". Conflating the two is what made the prose-brand
    control below fail against a gate that was behaving perfectly correctly.
    """
    r = cd.Report(pathlib.Path(name))
    gate(text, r)
    msgs = {"all": r.errors + r.warns, "errors": r.errors, "warns": r.warns}[scope]
    hit = any(needle.lower() in m.lower() for m in msgs) if needle else bool(msgs)
    ok = hit == must_fire
    results.append((ok, name, "fired" if hit else "quiet",
                    "expected fire" if must_fire else "expected quiet",
                    msgs[:1]))
    return ok


# ─────────────────────────────────────────────────────────────────────────
# MUST FIRE — each mutation is a defect that actually shipped once
# ─────────────────────────────────────────────────────────────────────────

# The measured .arch-box bug: one non-visible axis computes the other to auto.
control("overflow-x:auto must error",
        SHELL.replace("overflow: visible;", "overflow-x: auto;"),
        cd.check_scroll, True, "overflow-x")

# print() throws in a sandbox without allow-modals; unguarded, the deck stays
# stacked with every slide active.
control("unguarded print() must error",
        SHELL.replace("try {\n        window.print();", "{\n        window.print();"),
        cd.check_sandbox_safe, True, "print")

# A plausible-but-wrong hardcoded count hides a dead script.
control("numeric counter placeholder must error",
        SHELL.replace('id="count">&mdash; / &mdash;', 'id="count">1 / 2'),
        cd.check_sandbox_safe, True, "numeric")

# Bare localStorage aborts the rest of the script on an opaque origin.
control("bare localStorage must error",
        SHELL.replace("let current = 0;", "let current = localStorage.getItem('s');"),
        cd.check_sandbox_safe, True, "storage")

# Generic vendor class names: inlined <style> is document-scoped.
control("generic .cls-N must error",
        SHELL.replace("<style>", "<style>.cls-1{fill:#000}", 1),
        cd.check_icons, True, "generic class")

# An undeclared var() is an invalid value; the property silently falls back.
control("undeclared var() must error",
        SHELL.replace("var(--brand-deep)", "var(--nope-not-declared)", 1),
        cd.check_tokens, True, "never declared")

# Emoji in slide content, where 326 bundled SVGs exist.
control("emoji in slide content must warn",
        SHELL.replace('<div class="eyebrow">Section label</div>',
                      '<div class="eyebrow">\U0001F680 Section label</div>'),
        cd.check_emoji, True, "emoji")

# A foreign brand occupying a brand slot is an identity problem, not a mention.
control("foreign brand in brand slot must error",
        '<div class="brand-bar">Databricks</div>',
        cd.check_brand, True, "brand slot")

# Both icon families inside one grid.
control("mixed icon families must warn",
        '<div class="deck"><div class="cards">'
        '<svg viewBox="0 0 24 24"></svg><svg viewBox="0 0 64 64"></svg>'
        '</div></div><!-- /deck -->',
        cd.check_icon_families, True, "mixes both")

# A referenced duplicate id: url(#id) resolves to the first match, so one icon
# clips or masks another.
control("duplicate referenced id must error",
        '<svg><clipPath id="c"/></svg><svg><clipPath id="c"/></svg>'
        '<path clip-path="url(#c)"/>',
        cd.check_icons, True, "duplicate referenced")


# ─────────────────────────────────────────────────────────────────────────
# MUST STAY QUIET — legitimate variations that previously produced noise
# ─────────────────────────────────────────────────────────────────────────

# The one-pager has no .slide-body, so it cannot have the shrink defect. This
# control is the reason check_scroll returns early unless a flex .slide-body
# exists; without it the gate reported ten confident warnings for an impossible
# bug.
control("one-pager must not warn about flex-shrink",
        ONEPAGER, cd.check_scroll, False, "flex-shrink")

# The shell's own comments name an icon file. A gate that reads its own
# documentation is worse than no gate.
control("icon filename in a comment must not warn as a brand",
        SHELL, cd.check_brand, False, "foreign brand")

# The blanket rule satisfies every component at once; demanding per-component
# declarations on top of it is noise.
control("blanket flex-shrink rule satisfies the gate",
        SHELL, cd.check_scroll, False, "flex-shrink")

# A vendor named in prose is a judgement call for the author: it must WARN so the
# author sees it, and must NOT error, or naming a competitor would fail the build.
control("brand in prose warns",
        '<p>We evaluated Databricks and chose otherwise.</p>',
        cd.check_brand, True, "databricks", scope="warns")
control("brand in prose does not error",
        '<p>We evaluated Databricks and chose otherwise.</p>',
        cd.check_brand, False, scope="errors")

# The PDF button's own glyph lives outside the deck and is exempt.
control("chrome glyphs outside the deck are exempt",
        SHELL, cd.check_emoji, False, "emoji")

# A deck that DOCUMENTS these rules must not trip them. A slide explaining the
# sandbox rule with `<code>print()</code>` in its prose was reported as having an
# unguarded window.print() — the gate was reading slide copy as JavaScript.
control("print() named in slide prose must not error",
        SHELL.replace('<div class="eyebrow">Section label</div>',
                      '<div class="eyebrow">Sandbox-safe <code>print()</code> and '
                      '<code>localStorage</code></div>'),
        cd.check_sandbox_safe, False, scope="errors")

# ...but the real thing, inside a <script>, must still be caught.
control("unguarded print() inside a script still errors",
        '<script>document.body.onclick = () => { window.print(); };</script>',
        cd.check_sandbox_safe, True, "print")

# .icon / .icon.solid is an ordinary base/modifier pair, not a collision.
control("base/modifier icon classes are not a conflict",
        SHELL, cd.check_icons, False, "two scopes")

# 57 of the 326 bundled icons split one class across two rules inside their own
# <style> block — ordinary CSS cascade, and it renders perfectly:
#     .ic-X-cls-1 { fill-rule: evenodd; }
#     .ic-X-cls-1, .ic-X-cls-2 { fill: currentColor; }
# An earlier version of the collision gate compared declarations document-wide, so
# each of those 57 reported ITSELF as a collision: a hard error on correct artwork.
_cascade = (SKILL / "assets/icons/ra_virtual_warehouse.svg").read_text(encoding="utf-8")
control("intra-icon cascade must not error",
        f'<span class="icon solid">{_cascade}</span>',
        cd.check_icons, False, scope="errors")

# The same icon used on two slides is two identical scopes, not a disagreement.
control("same icon used twice must not error",
        f'<span class="icon solid">{_cascade}</span>'
        f'<span class="icon solid">{_cascade}</span>',
        cd.check_icons, False, scope="errors")

# But a genuine cross-scope disagreement must still be caught: same class name,
# two different icons, different rules. This is the defect the gate exists for.
control("cross-icon class collision must error",
        '<svg><style>.ic-a-cls-1{fill:currentColor}</style></svg>'
        '<svg><style>.ic-a-cls-1{fill:#5ab2e3}</style></svg>',
        cd.check_icons, True, "two scopes")

# Two grids, one family each, sitting next to each other. A flat 9000-character
# lookahead ran out of the first grid into the second and reported the slide as
# mixing families — penalising exactly the layout the rule asks for.
control("adjacent single-family grids must not warn",
        '<div class="deck">'
        '<div class="cards"><svg viewBox="0 0 64 64"></svg></div>'
        '<div class="cards"><svg viewBox="0 0 24 24"></svg></div>'
        '</div><!-- /deck -->',
        cd.check_icon_families, False, "mixes both")

# Nested markup must not defeat the depth match either.
control("nested markup inside a grid still scans correctly",
        '<div class="deck"><div class="cards">'
        '<div class="card"><div><svg viewBox="0 0 24 24"></svg></div></div>'
        '<div class="card"><div><svg viewBox="0 0 64 64"></svg></div></div>'
        '</div></div><!-- /deck -->',
        cd.check_icon_families, True, "mixes both")

# An unreferenced duplicate id is what you get from using one icon twice: worth a
# note, but nothing renders wrong, so it must not fail the build.
control("unreferenced duplicate id must not error",
        '<svg><g id="dup"/></svg><svg><g id="dup"/></svg>',
        cd.check_icons, False, scope="errors")


# ─────────────────────────────────────────────────────────────────────────
# The shipped fixtures must all pass with zero errors
# ─────────────────────────────────────────────────────────────────────────
for label, path in (("assets/shell.html", SKILL / "assets/shell.html"),
                    ("assets/onepager.html", SKILL / "assets/onepager.html"),
                    ("examples/example-deck.html", SKILL / "examples/example-deck.html")):
    rep = cd.check_file(path)
    ok = not rep.errors
    results.append((ok, f"fixture {label} has zero errors",
                    f"{len(rep.errors)} error(s)", "expected 0", rep.errors[:1]))


# ─────────────────────────────────────────────────────────────────────────
# Documented counts must match what is on disk. A drifted count in the docs is
# not cosmetic: it is the author's basis for choosing an icon.
# ─────────────────────────────────────────────────────────────────────────
icons = sorted((SKILL / "assets/icons").glob("*.svg"))
line = [p for p in icons if 'viewBox="0 0 24 24"' in p.read_text(encoding="utf-8")]
solid = [p for p in icons if p not in line]
partner = sorted((SKILL / "assets/partner").glob("*.svg"))
index_md = (SKILL / "references/icon-index.md").read_text(encoding="utf-8")
skill_md = (SKILL / "SKILL.md").read_text(encoding="utf-8")

for label, cond in (
    (f"disk has {len(icons)} icons and docs say 326", len(icons) == 326),
    (f"line family is 50 (found {len(line)})", len(line) == 50),
    (f"solid family is 276 (found {len(solid)})", len(solid) == 276),
    (f"partner marks are 4 (found {len(partner)})", len(partner) == 4),
    ("icon-index.md states 326", "326" in index_md),
    ("SKILL.md states 326", "326" in skill_md),
    ("every icon on disk is named in icon-index.md",
     all(f"`{p.stem}`" in index_md for p in icons)),
):
    results.append((cond, label, "ok" if cond else "MISMATCH", "expected ok", []))


# ─────────────────────────────────────────────────────────────────────────
failed = [r for r in results if not r[0]]
for ok, name, got, want, detail in results:
    mark = "  ok  " if ok else "FAIL  "
    print(f"{mark}{name}")
    if not ok:
        print(f"        got {got}, {want}")
        if detail:
            print(f"        first message: {detail[0][:150]}")
print(f"\n{len(results) - len(failed)}/{len(results)} controls passed")
if failed:
    print("\nWhen a control fails, suspect the CONTROL first: a needle that matches the")
    print("mutation's own filename, or a mutation that did not actually apply, will")
    print("'prove' a defect that never existed.")
sys.exit(1 if failed else 0)
