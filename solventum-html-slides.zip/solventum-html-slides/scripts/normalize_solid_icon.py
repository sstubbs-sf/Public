#!/usr/bin/env python3
"""
normalize_solid_icon.py - normalize SOLID-family icons for inline, theme-adaptive use.

The official Snowflake icon pack is monochrome Snowflake Blue (#29b5e8), colored via a
CSS class. This script rewrites the fill to `currentColor` so an inlined icon inherits
its container's `color` (adapts to dark/light themes and any brand accent), cleans the
markup for inlining, and gives files tidy, referenceable names.

It also NAMESPACES every internal class and id. The vendor pack keys its `<defs><style>`
block on generic names (`.cls-1`, `.st0`, `#clippath`) and reuses them across every icon. Once
inlined, those rules are document-scoped rather than element-scoped, so the last icon on
the page redefines `.cls-1` for all of them. Measured symptom: an icon whose `.cls-1` was
`currentColor` rendered a hardcoded blue because another icon later in the same document
defined `.cls-1` as `#5ab2e3`. It fails more quietly for knockouts -- `.cls-3` is white in
~32 icons and `currentColor` in ~13, so mixing them paints part of an icon white-on-white.
Prefixing per file makes inlined icons independent of each other.

This is the SOLID family only (fill:currentColor, viewBox 0 0 64 64). The LINE family
(24-grid, stroke:currentColor, fill:none) has its own normalizer, scripts/normalize_icon.py
-- do not cross them. This script preserves the <style> block the solid family renders
from; the line normalizer strips it, which makes a solid icon invisible.

Usage:
    # one file
    python3 normalize_solid_icon.py <input.svg> --out assets/icons
    # a whole folder
    python3 normalize_solid_icon.py <input_dir> --out assets/icons

Options:
    --out     Output directory for normalized SVGs (required).
    --index   If set, write a Markdown index of icon names grouped by prefix.
    --keep-prefix   Keep the 'Snowflake_ICON_' prefix in output names (default: strip).
    --partner Directory of partner marks to list in the index; defaults to a 'partner'
              folder beside the input directory. Those are NOT normalized: their color is
              part of a third-party trademark. See the Icons section of SKILL.md.
"""

import argparse
import os
import re
import sys

BRAND_BLUE = re.compile(r"#29b5e8", re.IGNORECASE)
# Structural Snowflake icon colors that should become the theme color.
# Covers primary blue, a near-duplicate blue, the dark navy used by reference-
# architecture object icons, and the magenta highlight tone. White (#fff) is a
# knockout/interior-detail color and is intentionally preserved so detail survives.
# 5ab2e3 / 52c3ec / 7fd2f1 are lighter blues used by a handful of icons; without them those
# files ship with a hardcoded fill that ignores the container's color and, once inlined,
# overrides `.cls-1` for every other icon on the page.
PALETTE = re.compile(r"#(?:29b5e8|2ab5e8|11567f|ec008c|5ab2e3|52c3ec|7fd2f1)\b", re.IGNORECASE)
HEX = re.compile(r"#[0-9A-Fa-f]{3,8}\b")
XML_PROLOG = re.compile(r"<\?xml[^>]*\?>\s*", re.IGNORECASE)
DOCTYPE = re.compile(r"<!DOCTYPE[^>]*>\s*", re.IGNORECASE)
SVG_OPEN = re.compile(r"<svg\b[^>]*>", re.IGNORECASE)
# Illustrator wraps the real artwork in <switch> and parks a base64 Adobe PGF copy of the
# same image alongside it, either in a <foreignObject> or in an <i:aipgf> element. Four icons
# in the pack carry one, which is why they weigh ~400KB each against 12KB for the next
# largest -- inlining one bloats a deck by 400KB of markup no browser renders.
FOREIGN_OBJECT = re.compile(r"<foreignObject\b.*?</foreignObject>", re.IGNORECASE | re.DOTALL)
ADOBE_ELEM = re.compile(r"<i:[\w.-]+\b[^>]*(?:/>|>.*?</i:[\w.-]+>)", re.IGNORECASE | re.DOTALL)
# Namespace declarations that point at DOCTYPE entities (&ns_ai;) dangle once the DOCTYPE is
# stripped, and the i:/x:/graph: attributes they enable are Illustrator bookkeeping.
ENTITY_NS_ATTR = re.compile(r'\sxmlns:(?:x|i|graph)="&[^"]*"', re.IGNORECASE)
ADOBE_ATTR = re.compile(r'\s(?:i|x|graph):[\w-]+="[^"]*"', re.IGNORECASE)
WH_ATTR = re.compile(r'\s(?:width|height)="[^"]*"', re.IGNORECASE)
VIEWBOX = re.compile(r'viewBox="([^"]+)"', re.IGNORECASE)


# Curated concept -> icon lookup, emitted at the top of the generated index.
#
# Without it, choosing an icon means scanning 172 general filenames and guessing, which is
# enough friction that the step gets skipped and the deck ships with emoji instead. Entries are
# validated against the icons actually written, so a rename shows up as a dropped row rather
# than an index that points at a file nobody has.
CONCEPT_MAP = [
    ("AI / Cortex", ["cortex", "ai_star", "document_ai", "copilot", "snowconvert_ai"]),
    ("Analytics / BI", ["analytics", "data_analytics", "accelerated_analytics",
                        "embedded_analytics", "geospatial_analytics"]),
    ("Pipelines / data engineering", ["data_engineering", "simplify_pipelines", "dynamic_tables",
                                     "openflow", "kafka_connectors", "snowpark", "spark_connect"]),
    ("Tables / storage formats", ["database", "sno_database", "hybrid_tables", "iceberg_tables",
                                 "external_tables", "storage_compute", "structured_data",
                                 "semi_structured_data", "unstructured_data"]),
    ("Compute / performance", ["warehouse_gen2", "warehouse_adaptive", "warehouse_snowpark",
                              "concurrency", "instant_elasticity", "performance_scale", "scale"]),
    ("Governance / security", ["security_governance", "security", "secure_data", "horizon",
                              "access", "tag", "trusted", "integrity", "metadata",
                              "universal_search"]),
    ("Cost / value", ["cost_savings", "pricing", "optimization", "optimize", "economy_scale",
                     "profit", "capacity"]),
    ("Sharing / collaboration", ["sharing_collaboration", "private_data_exchange",
                                "public_data_exchange", "application_collaboration",
                                "native_app"]),
    ("Apps / development", ["streamlit_in_snowflake", "web_app", "dev", "code", "sql",
                           "javascript", "snowpark_containers", "application"]),
    ("Operations / monitoring", ["alert", "log", "snowflake_trail", "management",
                                "easy_management", "operating_snowflake", "simplify_admin",
                                "refresh", "process"]),
    ("Migration / consolidation", ["hadoop_replace", "hadoop", "consolidate", "easy_consolidate",
                                  "easily_onboard", "all_your_data", "integrated_data"]),
    ("People / organization", ["user_1", "users", "users_multiple", "corporate", "enterprise",
                              "self_service"]),
    ("Status / outcome", ["check", "no", "target", "results", "faster_insights",
                         "eliminate_complexity", "eliminate_delays", "launch", "idea", "flag",
                         "information", "time", "speed_1"]),
    ("Content / enablement", ["documentation", "blog", "case_study", "data_sheet", "webinar",
                             "workshop", "event"]),
    ("File types", ["csv", "json", "xml", "xls", "generic_file", "spreadsheet_1", "video"]),
]


def clean_name(fname: str, keep_prefix: bool) -> str:
    base = os.path.basename(fname)
    base = re.sub(r"\.svg$", "", base, flags=re.IGNORECASE)
    if not keep_prefix:
        base = re.sub(r"^Snowflake[_ ]?ICON[_ ]?", "", base, flags=re.IGNORECASE)
    base = base.strip().lower()
    base = re.sub(r"[^a-z0-9]+", "_", base).strip("_")
    return base + ".svg"


STYLE_BLOCK = re.compile(r"<style[^>]*>(.*?)</style>", re.IGNORECASE | re.DOTALL)
CLASS_SELECTOR = re.compile(r"\.(-?[A-Za-z_][\w-]*)")
ID_ATTR = re.compile(r'\bid=["\']([^"\']+)["\']')
# IDREF attributes point at an id without `url(#...)` syntax; treating their targets as
# unreferenced strips the id and leaves the reference dangling.
IDREF_ATTR = re.compile(r'\baria-(?:labelledby|describedby)=["\']([^"\']+)["\']')


def namespace_locals(text: str, slug: str) -> str:
    """Prefix internal class names and ids with `slug` so inlined icons cannot collide.

    Class names are discovered from the icon's own `<style>` block rather than assumed to be
    `.cls-N`: the pack also ships `.st0`-style and uuid-style names, and any scheme reused
    across two files has the same collision. Rewrites the selectors, the matching `class`
    attributes, `id` values, and the `url(#...)` / `href="#..."` references that target them.
    """
    names = set()
    for block in STYLE_BLOCK.findall(text):
        names.update(CLASS_SELECTOR.findall(block))
    # `ic-` keeps the result a valid CSS identifier: several icon names start with a digit
    # (`3rd_party`), and a class selector cannot.
    prefix = f"ic-{slug}"
    # Skip names this script already namespaced, so re-running over assets/icons is a no-op
    # rather than producing `.ic-cortex-ic-cortex-cls-1`. Idempotency matters because
    # assets/icons is the regeneration source once an icon has been added by hand.
    names = {n for n in names if not n.startswith(prefix + "-")}
    for old in sorted(names, key=len, reverse=True):
        new = f"{prefix}-{old}"
        # Lookarounds rather than `\b`: a class may legitimately start with `-`, and `\b`
        # cannot match between a quote and a hyphen, which renamed the selector while leaving
        # the class attribute generic -- an icon with no fill AND the collision still present.
        # The attribute may also be single-quoted, which an anchor on `class="` never saw.
        bound = r"(?<![\w-])%s(?![\w-])" % re.escape(old)
        text = re.sub(r"\." + bound, lambda m, n=new: "." + n, text)
        text = re.sub(r'(class=["\'][^"\']*?)' + bound,
                      lambda m, n=new: m.group(1) + n, text)
    ids = ID_ATTR.findall(text)
    # Ids that nothing points at are Illustrator layer names (`id="Expanded_Icons"`) and are
    # worse than useless once inlined: the same icon used on two slides yields a duplicate
    # id in the document. Drop those; namespace the ones that are actually referenced.
    referenced = set(re.findall(r'url\(#([^)]+)\)', text)) | set(re.findall(r'href="#([^"]+)"', text))
    for value in IDREF_ATTR.findall(text):
        referenced.update(value.split())
    for old in sorted(set(ids), key=len, reverse=True):
        if old not in referenced:
            text = re.sub(r'\s+id=["\']%s["\']' % re.escape(old), "", text)
            continue
        if old.startswith(prefix + "-"):  # already namespaced; see the note above
            continue
        new = f"{prefix}-{old}"
        # Anchored so `data-id="x"` and similar attributes ending in `id` are left alone.
        text = re.sub(r'(?<![-\w])id="%s"' % re.escape(old), f'id="{new}"', text)
        text = text.replace(f"url(#{old})", f"url(#{new})")
        text = text.replace(f'href="#{old}"', f'href="#{new}"')
        text = re.sub(r'(aria-(?:labelledby|describedby)="[^"]*?)(?<![\w-])%s(?![\w-])'
                      % re.escape(old), lambda m, n=new: m.group(1) + n, text)
    return text


def normalize(text: str, slug: str = ""):
    """Return (normalized_svg, residual_hex_colors)."""
    text = XML_PROLOG.sub("", text)
    text = DOCTYPE.sub("", text)
    # Drop anything before the root <svg>. Four icons carry an Illustrator comment plus a
    # multi-line DOCTYPE of <!ENTITY> declarations; DOCTYPE.sub cannot remove those because
    # the internal subset contains '>' characters, and pasting them into HTML is garbage.
    root = text.lower().find("<svg")
    if root > 0:
        text = text[root:]
    text = FOREIGN_OBJECT.sub("", text)
    text = ADOBE_ELEM.sub("", text)
    text = ENTITY_NS_ATTR.sub("", text)
    text = ADOBE_ATTR.sub("", text)
    # Recolor: structural Snowflake tones -> currentColor (covers <style> class
    # fills and inline fills). White knockouts are preserved for interior detail.
    text = PALETTE.sub("currentColor", text)
    # Remove fixed width/height on the root <svg> so CSS controls size; keep viewBox.
    m = SVG_OPEN.search(text)
    if m:
        opening = m.group(0)
        new_opening = WH_ATTR.sub("", opening)
        text = text[:m.start()] + new_opening + text[m.end():]
    if slug:
        text = namespace_locals(text, slug)
    # White knockouts are preserved on purpose (interior detail), so they are not a second
    # tone. Including them made the report 45 rows long and every printed row was #fff --
    # and because the printout truncates at 40, a genuinely two-tone icon sorting after that
    # was never shown. The report only earns its place if every row needs a decision.
    residual = sorted({c.lower() for c in HEX.findall(text)} - {"#fff", "#ffffff"})
    return text.strip() + "\n", residual


def main():
    ap = argparse.ArgumentParser(description="Normalize Snowflake SVG icons to currentColor for inline use.")
    ap.add_argument("input", help="An .svg file or a directory of .svg files")
    ap.add_argument("--out", required=True, help="Output directory")
    ap.add_argument("--index", help="Optional path to write a Markdown icon index")
    ap.add_argument("--keep-prefix", action="store_true", help="Keep 'Snowflake_ICON_' prefix in names")
    ap.add_argument("--partner", help="Directory of partner marks to list in the index "
                                      "(default: a 'partner' folder beside the input directory)")
    args = ap.parse_args()

    if os.path.isdir(args.input):
        files = [os.path.join(args.input, f) for f in os.listdir(args.input) if f.lower().endswith(".svg")]
    elif os.path.isfile(args.input):
        files = [args.input]
    else:
        print(f"error: not found: {args.input}", file=sys.stderr)
        sys.exit(2)

    os.makedirs(args.out, exist_ok=True)
    written, multitone, nonsquare = [], [], []
    for fp in sorted(files):
        name = clean_name(fp, args.keep_prefix)
        with open(fp, "r", encoding="utf-8", errors="replace") as f:
            svg, residual = normalize(f.read(), slug=name[:-4])
        with open(os.path.join(args.out, name), "w", encoding="utf-8") as f:
            f.write(svg)
        written.append(name)
        vb = VIEWBOX.search(svg)
        if vb:
            try:
                nums = [float(n) for n in vb.group(1).replace(",", " ").split()]
                if len(nums) == 4 and abs(nums[2] - nums[3]) > 0.01:
                    nonsquare.append((name[:-4], f"{nums[2]:g}x{nums[3]:g}"))
            except ValueError:
                pass
        if residual:  # any hex color left after recolor = a second tone
            multitone.append((name, residual))

    print(f"Normalized {len(written)} icon(s) -> {args.out}")
    if nonsquare:
        print(f"\n{len(nonsquare)} icon(s) are NOT square; sizing them in a square box distorts them:")
        for name, vb in nonsquare:
            print(f"  {name}: viewBox {vb}")
    if multitone:
        print(f"\n{len(multitone)} icon(s) still contain a non-brand color (two-tone); review:")
        for name, cols in multitone[:40]:
            print(f"  {name}: {', '.join(cols)}")

    if args.index:
        groups = {}
        for name in written:
            key = name.split("_", 1)[0] if "_" in name else "general"
            # collapse the big families
            if key in ("ra",):
                key = "ra (reference architecture objects)"
            elif key == "industry":
                key = "industry"
            elif key == "workloads":
                key = "workloads"
            else:
                key = "general"
            groups.setdefault(key, []).append(name[:-4])
        lines = ["# Snowflake Icon Index",
                 "",
                 f"{len(written)} theme-adaptive icons in `assets/icons/` (fill = currentColor, class names "
                 "namespaced per file so inlined icons cannot override each other). "
                 "Reference by filename (without `.svg`). Inline them per the Icons section of SKILL.md.",
                 ""]
        if nonsquare:
            lines += ["## Not square (size these by width only)",
                      "",
                      "A square box squashes these. Set `width` and let `height:auto` follow the viewBox:",
                      "",
                      ", ".join(f"`{n}` ({vb})" for n, vb in sorted(nonsquare)),
                      "",
                      "`marketplace` is not an icon at all — it is the full Snowflake Marketplace "
                      "lockup (snowflake mark + wordmark). Use it as a logo in a header or a "
                      "partner slide, never as a tile icon in a card grid.",
                      ""]
        stems = {n[:-4] for n in written}
        rows = [(topic, [i for i in icons if i in stems]) for topic, icons in CONCEPT_MAP]
        rows = [(t, i) for t, i in rows if i]
        if rows:
            lines += ["## Pick by concept",
                      "",
                      "Start here rather than scanning filenames. First entry in each row is the "
                      "safe default.",
                      "",
                      "| Slide is about | Use |",
                      "|---|---|"]
            lines += [f"| {topic} | {', '.join('`%s`' % i for i in icons)} |" for topic, icons in rows]
            lines += ["",
                      "For a vertical, use `industry_<name>`; for a diagram of Snowflake objects, "
                      "`ra_<object>` (those keep white knockouts, so put them on a tinted chip). "
                      "Full lists below.",
                      ""]
        for key in sorted(groups):
            lines.append(f"## {key} ({len(groups[key])})")
            lines.append("")
            lines.append(", ".join(f"`{n}`" for n in sorted(groups[key])))
            lines.append("")
        # Partner marks live outside assets/icons and outside the currentColor rule; index them
        # here so they are discoverable, with the exception stated where it will be read.
        # Resolved against the INPUT directory, not --out: --out is usually a scratch dir, so
        # keying off it silently skipped the section on every run.
        if args.partner:
            partner_dir = args.partner
        elif os.path.isdir(args.input):
            partner_dir = os.path.join(os.path.dirname(os.path.abspath(args.input)), "partner")
        else:
            partner_dir = ""
        if partner_dir and os.path.isdir(partner_dir):
            pnames = sorted(f[:-4] for f in os.listdir(partner_dir) if f.lower().endswith(".svg"))
            if pnames:
                lines += [f"## partner marks ({len(pnames)}) — `assets/partner/`",
                          "",
                          ", ".join(f"`{n}`" for n in pnames),
                          "",
                          "**These keep their original colors and are NOT theme-adaptive.** They are "
                          "third-party trademarks (AWS, Microsoft, Google), and their color is part of "
                          "the mark — recoloring them to `currentColor` would flatten a multi-tone logo "
                          "into one tone and make it unrecognizable. Inline them the same way, but do "
                          "not set `color` on the wrapper and do not run them through "
                          "`normalize_icon.py`. Use them only to label a cloud storage source in a "
                          "reference-architecture diagram.",
                          ""]
        with open(args.index, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print(f"\nWrote index: {args.index}")


if __name__ == "__main__":
    main()
