#!/usr/bin/env python3
"""Quality gate for a Solventum HTML deck, one-pager, or exec brief.

    python3 scripts/check_deck.py path/to/deck.html [more.html ...]

Checks the failure modes that are expensive to catch by eye, and cheap to catch here:

  1. LOGO INTEGRITY   the official swoosh path is present, and no stroke-primitive
                      approximation or bare text wordmark is standing in for it
  2. SELF-CONTAINED   no external src/href, CDN, webfont, or remote image
  3. BRAND PURITY     no foreign brand tokens or non-Solventum accent palettes
  4. CONTRAST         #05dd4d is not used as text colour on a light surface
  5. PRINT INTACT     the @page rule and the print overrides survived editing
  6. STRUCTURE        tags balance, deck nav wiring is consistent, no placeholders left
  7. SANDBOX SAFE     no bare localStorage, and print() cannot take out the deck
  8. SLIDE SCROLL     only .slide-body scrolls; no inner box steals it
  9. ICON HYGIENE     inlined icon <style> blocks cannot restyle each other
 10. ICON FAMILIES    the 24-grid line set and the 64-grid solid set are not mixed
 11. TOKENS           every var() used is actually declared

Exit code 0 = pass (warnings allowed), 1 = at least one error.
"""
import argparse
import collections
import pathlib
import re
import sys

# The report uses box-drawing and dash characters, and decks are UTF-8. Neither
# can be assumed to survive the platform's locale encoding — on Windows that is
# usually cp1252, and in a bare container it can be ASCII — so pin both ends.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):  # non-standard stream; keep going
        pass

# The first curve of the official Solventum swoosh. Present in every legitimate
# copy of the lockup, whether inlined or URL-encoded in a CSS data URI.
LOGO_MARKER = "M89.5 51.3c0-19.3"

FOREIGN_BRAND = [
    "snowflake", "databricks", "microsoft", "azure", "aws", "amazon", "google",
    "salesforce", "oracle", "sap", "servicenow-logo", "openai", "anthropic",
]
# Palettes that are not in the Solventum system; a stray one usually means a
# component was pasted in from another deck.
FOREIGN_HEX = ["#29b5e8", "#11567f", "#7d44cf", "#635bff", "#ff4b4b", "#1f6feb"]

PLACEHOLDERS = [
    "DECK TITLE HERE", "ONE-PAGER TITLE HERE", "SECTION EYEBROW", "DECK NAME",
    "DOCUMENT TYPE", "DOCUMENT NAME", "MONTH YEAR", "AUDIENCE", "OWNER",
    "Lorem ipsum", "TODO", "TBD", "XXX", "FIXME",
]

# Blocks that sit inside the height-constrained .slide-body flex column. Without
# flex-shrink:0 a flex child is free to shrink below its content height, which
# silently squashes an illustration to a sliver (measured on the base deck: a
# 353px arch diagram rendered at 41px, showing only its first line, no error).
# The shell satisfies all of these at once with `.slide-body > * { flex-shrink:0 }`;
# see BLANKET_SHRINK below.
CONTENT_BLOCKS = [
    ".arch-box", ".cards", ".dtable", ".steps-grid", ".scenes", ".tier-grid",
    ".stat-grid", ".bars", ".qa-grid", ".two-col",
]
# One umbrella rule covers every current and future direct child of .slide-body,
# so a deck carrying it needs no per-component declaration. Recognising it is what
# keeps this gate from crying wolf on the shipped shell.
BLANKET_SHRINK = re.compile(r"\.slide-body\s*>\s*\*[^{}]*\{[^{}]*"
                            r"(?:flex-shrink\s*:\s*0\b|flex\s*:\s*(?:none\b|0\s+0\b))")


class Report:
    def __init__(self, path):
        self.path = path
        self.errors = []
        self.warns = []

    def err(self, msg):
        self.errors.append(msg)

    def warn(self, msg):
        self.warns.append(msg)


def _strip_comments(s):
    """Remove HTML, CSS and JS comments before scanning.

    A gate that reads its own documentation is worse than no gate. The shells
    explain every rule below in a comment, so an unstripped scan finds
    `localStorage`, `overflow-x: auto` and `.cls-1` in the prose that warns
    against them and reports a clean file as dirty — or, worse, finds the
    declaration it was looking for in a comment and passes a file missing it.

    `//` line comments matter as much as the block forms. The negative lookbehind
    keeps `https://` from being eaten as a comment.
    """
    s = re.sub(r"<!--.*?-->", " ", s, flags=re.DOTALL)
    s = re.sub(r"/\*.*?\*/", " ", s, flags=re.DOTALL)
    return re.sub(r"(?m)(^|[^:/\w])//[^\n]*$", r"\1 ", s)


def _guarded_by_try(body, pos, window=200):
    """True if `pos` sits inside a try block opened within `window` chars before it.

    A substring test for "try" is not enough: `const industry = ...` contains it,
    so a bare unguarded call right after that line would pass.
    """
    m = None
    head = body[max(0, pos - window):pos]
    for m in re.finditer(r"\btry\s*\{", head):
        pass
    if not m:
        return False
    # An intervening close of that try block means we are past it, not inside it.
    tail = head[m.end():]
    return tail.count("}") <= tail.count("{")


def _rules_for(body, sel):
    """Bodies of rules whose selector list contains `sel` as a selector in its own right.

    Excludes descendant variants (`.slide.dense .dtable`), which would otherwise
    be read as the base rule, and unlike an anchored search it still finds `sel`
    when it is not first in a grouped selector list (`.arch-box, .qa-grid { }`).
    """
    out = []
    # Lookbehind, not a consuming match: consuming the `}` that separates two
    # rules leaves the next rule with no delimiter to match against, so every
    # second rule becomes invisible.
    for m in re.finditer(r"(?:\A|(?<=[};{>]))\s*([^{}@][^{}]*?)\s*\{([^{}]*)\}", body):
        parts = [p.strip() for p in m.group(1).split(",")]
        if any(p == sel or p.startswith(sel + ":") for p in parts):
            out.append(m.group(2))
    return out


def _deck_content(t):
    """Just the slide content, so shell chrome is not scanned as authored content.

    The deck container is `<div class="deck">` and it closes with a
    `<!-- /deck -->` marker. Tolerate whitespace before the marker: requiring
    `</div><!--` exactly means one reformat silently widens the scan to the whole
    document, which then reports the PDF button's own glyph.
    """
    m = re.search(r'<div[^>]*class="[^"]*\bdeck\b[^"]*"[^>]*>(.*)</div>\s*<!--\s*/deck',
                  t, re.DOTALL)
    return m.group(1) if m else t


def check_logo(t, r):
    n = t.count(LOGO_MARKER)
    if n == 0:
        r.err(
            "logo missing: the official swoosh path was not found. Paste the SVG from "
            "assets/brand/ verbatim — do not redraw it, and do not substitute a text "
            "wordmark or an icon."
        )
        return
    # A hand-drawn stand-in usually shows up as stroke primitives inside an element
    # that is named like the logo.
    for m in re.finditer(r'<svg[^>]*class="[^"]*(?:logo|lockup|wordmark)[^"]*"[^>]*>(.{0,900}?)</svg>',
                         t, re.DOTALL | re.IGNORECASE):
        frag = m.group(1)
        if LOGO_MARKER not in frag and re.search(r"<(line|polyline|circle|ellipse|rect)\b", frag):
            r.err(
                "logo approximation: an element classed as a logo is built from stroke "
                "primitives instead of the official path."
            )
            break
    # A text-only wordmark is a fallback, not the logo. Flag it only if it looks like
    # it is doing the logo's job in the brand chrome.
    if re.search(r'class="[^"]*(?:logo|lockup|wordmark)[^"]*"[^>]*>\s*[Ss]olventum\.?\s*<', t):
        r.err("text wordmark is standing in for the lockup in a logo slot.")


def check_self_contained(t, r):
    for m in re.finditer(r'\b(?:src|href)\s*=\s*["\']([^"\']+)["\']', t):
        url = m.group(1).strip()
        if url.startswith(("#", "data:", "mailto:", "tel:")):
            continue
        if url.startswith(("http://", "https://", "//")):
            # A link the reader clicks is fine; a resource the page loads is not.
            tag_start = t.rfind("<", 0, m.start())
            tag = t[tag_start:m.start()].lower()
            if "<a" in tag:
                continue
            r.err(f"external resource loaded at render time: {url}")
        else:
            r.err(f"relative file reference breaks the single-file guarantee: {url}")
    # Require the at-rule as it is actually written — followed by a url() or a
    # quoted path — so a deck that merely names @import in prose is not failed.
    if re.search(r"@import\s+(?:url\(|['\"])", t, re.IGNORECASE):
        r.err("@import pulls in an external stylesheet.")
    if re.search(r"@font-face\s*\{", t):
        r.err("@font-face: use the system font stack instead of a webfont.")
    # Any absolute URL inside url() breaks self-containment, whether or not the
    # host is a known CDN — a tracking pixel on a private host is still a
    # network call and still leaks who opened the deck.
    for m in re.finditer(r'url\(\s*["\']?\s*((?:https?:)?//[^"\')\s]+)', t, re.IGNORECASE):
        r.err(f"external URL in CSS url(): {m.group(1)}")
    # Scope the CDN scan to URL-ish context, so prose that merely mentions a CDN
    # (including this skill's own comments) does not trip the gate.
    for m in re.finditer(r'(?:https?:)?//[^\s"\'()<>]+|url\(\s*["\']?([^"\')]+)', t, re.IGNORECASE):
        frag = (m.group(0) or "").lower()
        if frag.startswith("url(") and "data:" in frag:
            continue
        for bad in ("cdn.", "unpkg.com", "jsdelivr", "fonts.googleapis", "cdnjs", "googleapis.com"):
            if bad in frag:
                r.err(f"CDN reference found: {bad}")
    if re.search(r'\bfetch\s*\(|XMLHttpRequest|new\s+Image\s*\(\s*["\']http', t):
        r.err("runtime network call found; the file must render with no network.")


def check_no_active_content(t, r):
    """Reject executable content that arrives with pasted-in art.

    A deck is a file people email onward and open locally, so it must not carry
    anything that runs on its own. The usual way this happens is not malice but
    an SVG downloaded from the internet and pasted in with an onload handler or
    a <foreignObject> still attached.
    """
    for m in re.finditer(r"<[^>]*?\s(on[a-z]+)\s*=", t, re.IGNORECASE):
        r.err(f"inline event handler '{m.group(1)}' — move behaviour into the deck's script "
              "block, or strip it if it came from pasted art")
    for m in re.finditer(r'(?:href|src|to|from|values)\s*=\s*["\']?\s*javascript:', t, re.IGNORECASE):
        r.err("javascript: URL found")
    for tag in ("iframe", "object", "embed", "foreignobject", "use", "image"):
        for m in re.finditer(rf"<\s*{tag}\b", t, re.IGNORECASE):
            r.err(f"<{tag}> is not allowed: it can load or execute external content. "
                  "Icons must be plain shape elements — run scripts/normalize_icon.py "
                  "over any SVG taken from the internet")
            break
    # Animation elements can retarget an href to a javascript: URL at runtime.
    for m in re.finditer(r"<\s*(animate|animatetransform|animatemotion|set)\b", t, re.IGNORECASE):
        r.err(f"<{m.group(1).lower()}> animation element found in art; strip it")
        break


def _prose_only(t):
    """Text with comments and machine-facing identifiers blanked out.

    The brand scan must read what the AUDIENCE reads, not what the markup is made
    of. 290 of the bundled solid icons carry their own name inside a namespaced
    class or id (`ic-snowflake_trail-st1`, `ic-ra_snowflake_database-clippath`),
    and the skill's own CSS comments name those files. Scanning raw text made
    every deck that used one of those icons emit a foreign-brand warning — which
    is worse than no gate, because a gate that always fires trains the reader to
    skip it, and this is the gate protecting against another company's identity
    appearing in a brand slot.

    Blanks rather than deletes, so reported offsets and the surrounding-context
    lookups in other gates stay aligned with the original string.
    """
    def blank(m):
        return " " * (m.end() - m.start())

    t = re.sub(r"<!--.*?-->", blank, t, flags=re.DOTALL)
    t = re.sub(r"/\*.*?\*/", blank, t, flags=re.DOTALL)
    # Attribute values that name things rather than say things. `class` and `id`
    # only: alt/title/aria-label ARE read by the audience and must stay in scope.
    t = re.sub(r'\b(?:class|id|data-name)\s*=\s*"[^"]*"', blank, t, flags=re.IGNORECASE)
    # CSS selector text, for the same reason: `.ic-snowflake_trail-st1 { }` names a
    # file, it does not address the reader. Only the selector is blanked, never the
    # declarations — the off-palette hex scan below reads colour values out of CSS,
    # so blanking whole <style> blocks would silently disable that gate instead.
    def strip_selectors(m):
        return re.sub(r"(\A|[{};])([^{}();]*?)(?=\{)",
                      lambda s: s.group(1) + blank_str(s.group(2)), m.group(0))

    def blank_str(s):
        return " " * len(s)

    return re.sub(r"<style[^>]*>.*?</style>", strip_selectors, t,
                  flags=re.DOTALL | re.IGNORECASE)


def check_brand(t, r):
    # Read prose, not identifiers: see _prose_only for why this is not the raw text.
    low = _prose_only(t).lower()
    for name in FOREIGN_BRAND:
        # A deck may legitimately name a vendor in prose, so this is a warning.
        # It becomes an error only where the name sits in a logo or brand slot,
        # which means another company's identity is being presented as ours.
        # Word-bounded: an unbounded scan matches "sap" inside "disappears".
        word = re.compile(rf"(?<![a-z0-9]){re.escape(name)}(?![a-z0-9])")
        if not word.search(low):
            continue
        # The error case reads the RAW text on purpose: a brand slot is identified
        # by its class, which _prose_only has deliberately blanked.
        if re.search(rf'class="[^"]*(?:logo|lockup|wordmark|brand)[^"]*"[^>]*>[^<]*{re.escape(name)}',
                     t.lower(), re.IGNORECASE):
            r.err(f"foreign brand '{name}' is occupying a logo or brand slot")
        else:
            r.warn(f"foreign brand reference: '{name}' — confirm it belongs in this deck")
    for hexv in FOREIGN_HEX:
        if hexv in low:
            r.warn(f"off-palette colour {hexv} — check it against assets/brand/BRAND.md")


def check_contrast(t, r):
    # #05dd4d on white is ~1.7:1. Legal as an accent or a large fill, not as text.
    for m in re.finditer(r"(?<!-)\bcolor\s*:\s*(#05dd4d|var\(--brand\))", t, re.IGNORECASE):
        start = max(0, m.start() - 400)
        ctx = t[start:m.start()].lower()
        # Inside .slide.title / .brand-bar / .inverse / .arch-box the surface is dark.
        on_dark = any(k in ctx for k in (
            ".slide.title", ".brand-bar", ".inverse", ".arch-box", ".arch-title", "--inverse",
        ))
        if not on_dark:
            r.warn(
                "--brand (#05dd4d) used as a text colour outside a dark surface — "
                "roughly 1.7:1 on white. Use --brand-deep (#0a7d38) for text."
            )
            break


def check_print(t, r):
    # Match the at-rule as it is actually written (start of a line, brace on the
    # same line), not prose in a comment that happens to mention it.
    has_page = re.search(r"^\s*@page\b[^{\n]*\{", t, re.MULTILINE)
    has_print = re.search(r"^\s*@media\s+print\b[^{\n]*\{", t, re.MULTILINE)
    if not has_page:
        r.err("no @page rule: PDF export will not set page size or margins.")
    elif re.search(r"@media\s+print\b[^{]*\{(?:[^{}]|\{[^{}]*\})*?@page", t, re.DOTALL):
        r.warn("@page appears nested inside @media print; keep it at top level.")
    if not has_print:
        r.err("no @media print block: the deck will print with screen chrome.")
        return
    if "print-color-adjust" not in t:
        r.warn("no print-color-adjust: brand colours may drop out of the PDF.")
    is_deck = 'class="deck"' in t or "class='deck'" in t
    if is_deck:
        if not re.search(r"page-break-after|break-after", t):
            r.err("deck print CSS has no page break: slides will run together.")
        if not re.search(r"max-height\s*:\s*none", t):
            r.err(
                "print CSS does not release .slide-body max-height/overflow — on paper "
                "overflow:auto clips silently."
            )


def check_structure(t, r):
    for tag in ("div", "section", "span", "table", "tr", "td", "ul", "li", "svg"):
        opens = len(re.findall(rf"<{tag}\b", t, re.IGNORECASE))
        closes = len(re.findall(rf"</{tag}\s*>", t, re.IGNORECASE))
        if opens != closes:
            r.err(f"unbalanced <{tag}>: {opens} open, {closes} close")

    slides = re.findall(r'<section[^>]*class="[^"]*\bslide\b[^"]*"', t)
    if slides:
        active = [s for s in slides if "active" in s]
        if len(active) != 1:
            r.err(f"{len(active)} slides carry 'active'; exactly one should on load.")
        # Content slides (not the title/divider) should carry the brand footer.
        content = [s for s in slides if "title" not in s]
        footers = t.count('class="slide-footer"')
        if content and footers < len(content):
            r.warn(f"{len(content)} content slides but {footers} slide-footer blocks.")
        for el in ("prev-btn", "next-btn", "count", "progress-bar"):
            if f'id="{el}"' not in t:
                r.err(f"nav element #{el} is missing; the deck will not navigate.")
        if "keydown" not in t:
            r.warn("no keydown handler: arrow-key navigation is gone.")

    found = [p for p in PLACEHOLDERS if p in t]
    if found:
        r.warn("unfilled placeholder text: " + ", ".join(sorted(set(found))[:6]))


def _script_only(t):
    """Just the contents of <script> blocks, positions preserved.

    JS gates must read JS. Scanning the whole document means a deck that
    *documents* these rules trips them: a slide explaining the sandbox rule with
    `<code>print()</code>` in its prose was reported as having an unguarded
    window.print(), and a deck naming `localStorage` in a caveat would error the
    same way. Everything outside <script> is blanked rather than removed so the
    try/catch proximity window still measures real distances.
    """
    out = ["\x00"] * len(t)
    for m in re.finditer(r"<script\b[^>]*>(.*?)</script>", t, re.DOTALL | re.IGNORECASE):
        for i in range(m.start(1), m.end(1)):
            out[i] = t[i]
    return "".join(out).replace("\x00", " ")


def check_sandbox_safe(t, r):
    """The failure that makes a shared deck look broken rather than imperfect.

    Decks get forwarded, and recipients open them in places that render HTML in a
    sandboxed iframe without allow-same-origin: Slack and Teams link previews,
    Notion embeds, GitHub's HTML preview, st.components.v1.html. There the
    document has an opaque origin, so any localStorage access throws
    SecurityError — and a throw at top level aborts the rest of the script, so
    every listener registered after it never binds. The reader gets a frozen
    slide 1 with dead arrows and concludes the file is broken.

    This shell has no theme toggle and no storage access today. The gate stays so
    that the first edit which introduces either is caught on the way in.
    """
    body = _script_only(_strip_comments(t))
    for m in re.finditer(r"\b(?:localStorage|sessionStorage)\s*\.", body):
        if not _guarded_by_try(body, m.start()):
            r.err(
                "unguarded storage access: localStorage throws SecurityError in a "
                "sandboxed iframe (Slack/Teams previews, Notion, GitHub HTML preview, "
                "st.components.v1.html) and the throw kills every listener registered "
                "after it. Route it through a try/catch store.get/store.set helper."
            )
            break
    for m in re.finditer(r"\bprint\s*\(\s*\)", body):
        if not _guarded_by_try(body, m.start()):
            r.err(
                "unguarded window.print(): it needs allow-modals in a sandbox, and "
                "the PDF handler reveals every slide BEFORE calling it — so a throw "
                "here leaves all slides stacked and visible with no restore. Wrap it "
                "in try { } catch (e) { render(); }."
            )
            break
    # A numeric placeholder is worse than an obviously empty one: a plausible but
    # wrong count (1 / 2 on a 12-slide deck) hides a dead script instead of
    # revealing it, because the chrome looks correct.
    counter = re.search(r'id\s*=\s*["\']count["\'][^>]*>(.*?)</', t, re.DOTALL)
    if counter and re.search(r"\d", counter.group(1)):
        r.err(
            f"#count placeholder is numeric ({counter.group(1).strip()!r}). A "
            "plausible-but-wrong hardcoded count hides a dead script instead of "
            "revealing it — keep it non-numeric, e.g. '\u2014 / \u2014'."
        )


def check_nav_race(t, r):
    """Fast navigation, or a failed print, must not blank or stack the deck.

    Two shapes of the same bug. If a deck removes .active from the OUTGOING slide
    on a timer, pressing right then left inside that window strips .active from
    the slide that has since become current: zero active slides, an empty canvas
    with a working brand bar and nav. And if the PDF handler adds .active to every
    slide to reveal them for printing, it must restore on the failure path too,
    or a print() that throws leaves the deck permanently stacked.
    """
    body = _script_only(_strip_comments(t))
    rm = ("classList.remove('active')" in body) or ('classList.remove("active")' in body)
    if rm:
        for m in re.finditer(r"setTimeout\s*\(", body):
            chunk = body[m.start():m.start() + 400]
            # Scope to a cleanup timer that targets the OUTGOING slide. A forEach
            # over every slide needs no guard; flagging it would train the author
            # to ignore the gate.
            if "slides[prev]" not in chunk:
                continue
            if "classList.remove('active')" not in chunk and \
               'classList.remove("active")' not in chunk:
                continue
            if not re.search(r"prev\s*!==?\s*current|current\s*!==?\s*prev", chunk):
                r.err(
                    "the .active-cleanup timer is unguarded: navigating again inside "
                    "its window leaves NO active slide and the deck renders blank. "
                    "Guard the removal with `if (prev !== current)`."
                )
                break
    # The reveal-for-print path: every slide made active, so a restore is mandatory.
    if re.search(r"forEach\s*\([^)]*\)\s*=>\s*[\w.]*classList\.add\(\s*['\"]active", body) \
            and not re.search(r"catch\s*\([^)]*\)\s*\{[^{}]*render", body):
        r.warn(
            "the PDF handler reveals every slide but has no restore on the catch "
            "path; if print() throws, the deck stays stacked. Call render() in the "
            "catch as well as after the dialog."
        )


def check_scroll(t, r):
    """Only .slide-body may scroll. An inner box that scrolls hides its own content."""
    body = _strip_comments(t)
    for m in re.finditer(r"([.#][\w-]+)[^{}]*\{[^{}]*overflow-x\s*:\s*auto", body):
        r.err(
            f"overflow-x: auto on {m.group(1)} — per CSS spec, a non-visible overflow "
            "on one axis computes the other to auto, so this also creates a VERTICAL "
            "scrollbar and the box steals the scroll from .slide-body, hiding most of "
            "its own content. Use overflow: visible."
        )
        break
    # One umbrella rule is the preferred fix and satisfies every component at once.
    if BLANKET_SHRINK.search(body):
        return
    # The shrink defect only exists inside a height-constrained flex column. The
    # one-pager lays its components out on a normal block page with no .slide-body
    # at all, so running the loop there reported all ten components as defective
    # for a bug the file cannot have — noise that teaches the author to skim past
    # this gate, which then hides the real thing on a deck.
    sb = _rules_for(body, ".slide-body")
    if not any(re.search(r"display\s*:\s*flex", b) for b in sb):
        return
    for sel in CONTENT_BLOCKS:
        rules = _rules_for(body, sel)
        # Match the VALUE, not the property name: `flex-shrink: 1` is the exact
        # defect this gate documents, and a name-only substring test passes it.
        # `flex: 0 0 ...` and `flex: none` set shrink to 0 via the shorthand.
        ok = any(re.search(r"flex-shrink\s*:\s*0\b", b)
                 or re.search(r"flex\s*:\s*(?:none\b|0\s+0\b)", b) for b in rules)
        if rules and not ok:
            r.warn(
                f"{sel} has no flex-shrink: 0. .slide-body is a height-constrained "
                "flex column, so its children shrink below their content size by "
                "default and an illustration can be squashed to a sliver silently. "
                "Prefer the blanket rule `.slide-body > * { flex-shrink: 0 }`."
            )


def check_emoji(t, r):
    """Emoji standing in for an icon inside slide content.

    There are 326 bundled SVGs in assets/icons/, so an emoji in a card grid means
    the icon step was skipped. It is not only a brand issue: emoji render from a
    different font on every OS, ignore the theme (no currentColor), and land in
    the PDF at whatever size the system font gives them. Scoped to deck content,
    because the PDF button legitimately uses a glyph and lives outside the deck.
    """
    content = _strip_comments(_deck_content(t))
    # Pictographs and dingbats only. Deliberately excludes arrows and box-drawing,
    # which the .arch-box diagrams use as structure rather than decoration — which
    # is why the dingbat range stops at U+2793, before the Dingbats block's own
    # arrows (U+2794-27BE).
    found = sorted(set(re.findall(
        r"[\U0001F300-\U0001F5FF\U0001F600-\U0001F64F\U0001F680-\U0001F6FF"
        r"\U0001F900-\U0001F9FF\U0001FA70-\U0001FAFF\u2600-\u26FF\u2700-\u2793]",
        content)))
    if found:
        r.warn(
            "emoji used as a visual inside slide content (" + " ".join(found[:6]) + "). "
            "Replace with a bundled SVG from assets/icons/ — see "
            "references/icon-index.md → Pick by concept. Emoji vary by OS, ignore the "
            "theme, and read as unfinished."
        )


def check_icons(t, r):
    """Inlined icon <style> blocks are document-scoped, not element-scoped.

    The solid family carries its rules in a <style> block inside each SVG. Once
    inlined, that block styles the whole document — so with the vendor's generic
    class names the last icon on the page redefines the fill for every earlier
    one. (Measured on the base deck: an icon whose .cls-1 was currentColor
    rendered a hardcoded blue because a later icon defined .cls-1 as #5ab2e3.)
    The knockout case is quieter still: 45 of these icons paint interior detail
    with a hardcoded #fff, so a collision can paint part of an icon white-on-white.
    """
    body = _strip_comments(t)
    # 1. A vendor class scheme (`cls-N`, `stN`) means an icon was pasted without
    #    normalizing. Flag it even in isolation, because the next icon added will
    #    collide with it.
    vendor = sorted(set(re.findall(r"\.(cls-\d+|st\d+)\b", body)))
    if vendor:
        r.err(
            "icon SVGs still use generic class names (" + ", ".join(vendor[:5]) +
            "): inlined <style> rules are document-scoped, so one icon will restyle "
            "the others. Re-run scripts/normalize_solid_icon.py, which namespaces "
            "them per file as .ic-<name>-cls-N."
        )

    # 2. The general case, which also catches single-letter and uuid-style vendor
    #    names: an icon-internal class declared differently in two DIFFERENT
    #    scopes. The scope distinction is the whole test. Splitting one class over
    #    several rules inside a single icon is ordinary, correct CSS cascade:
    #
    #        .ic-ra_virtual_warehouse-cls-1 { fill-rule: evenodd; }
    #        .ic-ra_virtual_warehouse-cls-1, .ic-...-cls-2 { fill: currentColor; }
    #
    #    57 of the 326 bundled icons are authored that way. An earlier version of
    #    this gate compared declarations document-wide, so those 57 each reported
    #    themselves as a collision — a hard error on artwork that renders perfectly.
    #    A conflict only exists when two separate scopes disagree about the same
    #    class name, because that is when the document-scoped cascade makes one
    #    icon restyle another.
    def _class_decls(scope):
        """class name -> the combined declarations that scope gives it."""
        acc = {}
        for st in re.finditer(r"<style[^>]*>(.*?)</style>", scope, re.DOTALL | re.IGNORECASE):
            for rule in re.finditer(r"([^{}]+)\{([^{}]*)\}", st.group(1)):
                decls = re.sub(r"\s+", "", rule.group(2))
                for sel in rule.group(1).split(","):
                    for cls in re.findall(r"\.(-?[A-Za-z_][\w-]*)", sel):
                        acc.setdefault(cls, set()).add(decls)
        # Order-independent: the same rules written in a different order are the
        # same styling, and flagging that would be noise.
        return {c: "|".join(sorted(d)) for c, d in acc.items()}

    scopes = []
    icon_classes = set()
    for svg in re.finditer(r"<svg\b.*?</svg>", body, re.DOTALL | re.IGNORECASE):
        d = _class_decls(svg.group(0))
        if d:
            scopes.append(d)
            icon_classes |= set(d)
    # Document-level CSS is its own scope: a deck class that collides with an
    # icon-internal name is exactly as damaging as two icons colliding.
    outside = _class_decls(re.sub(r"<svg\b.*?</svg>", " ", body,
                                  flags=re.DOTALL | re.IGNORECASE))
    if outside:
        scopes.append(outside)

    seen, conflicts = {}, set()
    for sc in scopes:
        for cls, decls in sc.items():
            if cls not in icon_classes or cls in vendor:
                continue
            if cls in seen and seen[cls] != decls:
                conflicts.add(cls)
            seen.setdefault(cls, decls)
    if conflicts:
        r.err(
            "icon-internal class name(s) declared differently in two scopes (" +
            ", ".join(sorted(conflicts)[:5]) + "): inlined <style> is document-scoped, "
            "so the last declaration wins and restyles every earlier icon using that "
            "name. Namespace the icon classes or rename the deck class."
        )

    ids = re.findall(r'id="([^"]+)"', t)
    referenced = set(re.findall(r"url\(#([^)]+)\)", t)) | set(re.findall(r'href="#([^"]+)"', t))
    dupes = sorted(i for i, c in collections.Counter(ids).items() if c > 1)
    # Only a REFERENCED duplicate is a defect: url(#id) and clip-path resolve to
    # the first match, so one icon ends up clipped by another's mask. An
    # unreferenced duplicate is what you get from using the same icon on two
    # slides, which is normal and harmless.
    breaking = [i for i in dupes if i in referenced]
    if breaking:
        r.err("duplicate referenced id(s): " + ", ".join(breaking[:5]) +
              ". url(#id) / clip-path resolves to the first match, so one icon will "
              "clip or mask another.")
    elif dupes:
        r.warn("duplicate id(s): " + ", ".join(dupes[:5]) + " (not referenced, so "
               "nothing breaks today, but ids are meant to be unique).")


def _element_extent(text, start, tag):
    """Return text[start:end] where end closes the tag that opens at `start`.

    A fixed-size lookahead window is not good enough here. Scanning a flat 9000
    characters forward from one grid ran straight into the NEXT grid, so a slide
    with a solid-icon grid followed by a separate line-icon grid was reported as
    mixing families inside one component — the exact thing it had carefully
    avoided doing. Depth-matching keeps each component's scan inside itself.
    """
    depth = 0
    pattern = re.compile(rf"<\s*(/?){tag}\b", re.IGNORECASE)
    for m in pattern.finditer(text, start):
        depth += -1 if m.group(1) else 1
        if depth == 0:
            return text[start:m.end()]
    return text[start:]


def check_icon_families(t, r):
    """The two bundled icon families must not be mixed inside one grid.

    assets/icons/ holds two sets that are not interchangeable: 50 line icons on a
    24 grid (stroke:currentColor, fill:none, 1.6 stroke) and 276 solid icons on a
    64 grid (fill:currentColor). A filled icon reads much heavier than a 1.6px
    outline, so a row that mixes them looks like two decks spliced together —
    which is a design defect the author cannot see while writing markup, because
    each icon looks correct on its own.
    """
    content = _deck_content(t)
    for m in re.finditer(r'<(div|ul|tr)[^>]*class="[^"]*\b'
                         r'(cards|tier-grid|stat-grid|steps-grid|scenes|qa-grid)\b[^"]*"[^>]*>',
                         content):
        chunk = _element_extent(content, m.start(), m.group(1))
        boxes = set(re.findall(r'viewBox="0 0 (24 24|64 64)"', chunk))
        if {"24 24", "64 64"} <= boxes:
            r.warn(
                f".{m.group(2)} mixes both icon families (24-grid line icons and "
                "64-grid solid icons) in one grid. Pick one family per grid — the "
                "solid set is filled and reads far heavier than the 1.6px outlines. "
                "See references/icon-index.md → Two families."
            )
            break


def check_tokens(t, r):
    """A var() that resolves to nothing renders nothing, silently.

    `color: var(--accent)` with no `--accent` declared is an invalid value, so the
    property falls back to inherited or initial and the emphasis the author
    intended just disappears. This is the usual symptom of a component pasted in
    from another deck, which is also why it pairs with the foreign-palette warning.
    """
    body = _strip_comments(t)
    defined = set(re.findall(r"(--[\w-]+)\s*:", body))
    # A var() with a fallback degrades gracefully, so only bare uses matter.
    used = set(re.findall(r"var\(\s*(--[\w-]+)\s*\)", body))
    missing = sorted(used - defined)
    if missing:
        r.err("CSS custom propert" + ("ies" if len(missing) > 1 else "y") +
              " used but never declared: " + ", ".join(missing[:6]) +
              ". An undeclared var() is an invalid value, so the property silently "
              "falls back to inherited or initial.")


def check_file(path):
    r = Report(path)
    try:
        t = path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        r.err(f"cannot read file: {e}")
        return r
    if not t.lstrip().lower().startswith("<!doctype html"):
        r.warn("missing <!DOCTYPE html>")
    check_logo(t, r)
    check_self_contained(t, r)
    check_no_active_content(t, r)
    check_brand(t, r)
    check_contrast(t, r)
    check_print(t, r)
    check_structure(t, r)
    check_sandbox_safe(t, r)
    check_nav_race(t, r)
    check_scroll(t, r)
    check_emoji(t, r)
    check_icons(t, r)
    check_icon_families(t, r)
    check_tokens(t, r)
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()

    failed = False
    for f in args.files:
        r = check_file(pathlib.Path(f))
        head = f"── {r.path}"
        print(head)
        if not r.errors and not r.warns:
            print("   PASS — no issues found\n")
            continue
        for e in r.errors:
            print(f"   ERROR  {e}")
        for w in r.warns:
            print(f"   warn   {w}")
        print(f"   {len(r.errors)} error(s), {len(r.warns)} warning(s)\n")
        failed = failed or bool(r.errors)

    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
