# Solventum HTML Slides — a Cortex Code skill

Builds Solventum-branded HTML slide decks, one-pagers, and executive briefs as **single
self-contained files**. No CDN, no webfonts, no sidecar assets — one `.html` that opens anywhere,
emails cleanly, and prints to landscape PDF with one slide per page.

## Install

Unzip the `solventum-html-slides` folder into either location:

```
~/.snowflake/cortex/skills/solventum-html-slides/     # available in every project
<your-project>/.cortex/skills/solventum-html-slides/  # available in that project only
```

There is no registration step. Restart Cortex Code and the skill appears in the `/` picker as
`/solventum-html-slides`.

Verify the install:

```bash
cd ~/.snowflake/cortex/skills/solventum-html-slides
python3 scripts/check_deck.py examples/example-deck.html   # expect: PASS
```

Requires Python 3.8+ for the scripts (already present on macOS and most Linux). On Windows use
`python` or `py -3` in place of `python3`. All scripts read and write UTF-8 explicitly and force
UTF-8 console output, so they behave the same on a `cp1252` Windows shell or an ASCII-only
container as they do on macOS.

The skill needs **no Snowflake connection, warehouse, role, or account privilege** — it never runs
SQL and makes no network call. It works identically on any account, or with no account at all.
The generated HTML itself needs nothing but a browser.

## Use it

Ask for what you want in plain language — the skill loads automatically:

- "Build a Solventum deck for the Q1 automation readout"
- "Make a one-pager exec brief on the data platform decision"
- "Turn this status doc into a 6-slide board readout"

Or invoke it explicitly with `/solventum-html-slides`.

The skill will ask about the audience, the decision, and your source numbers, then show you a
slide-by-slide outline **before** building anything. Correct the outline at that point — it is far
cheaper than restructuring finished HTML.

## What comes out

A single `.html` file with:

- The official Solventum lockup, brand green palette, and system type scale
- Keyboard navigation (arrows, Home, End), a progress bar, and a slide counter
- A PDF button that prints landscape, one slide per page
- 20+ components: cards, tables with status pills, horizon grids, stat blocks, proportional bars,
  ASCII architecture panels, Q&A grids, hover tooltips

Open `examples/example-deck.html` to see the target quality.

## What is in the folder

```
SKILL.md                  the workflow and rules Cortex Code follows
README.md                 this file
assets/
  shell.html              deck shell — every deck starts as a copy of this
  onepager.html           one-pager / exec-brief shell
  brand/
    BRAND.md              logo rules, tokens, contrast rule, type scale
    solventum-logo-horz-white.svg    white wordmark, for dark surfaces
    solventum-logo-horz-dark.svg     ink wordmark, for light surfaces
    solventum-mark-green.svg         swoosh only
  icons/                  326 icons in two families: 50 line (24x24, stroke)
                          and 276 solid (64x64, fill) — see references/icon-index.md
  partner/                4 third-party cloud marks; keep their own colours
references/
  components.md           copy-paste markup for every component
  icon-index.md           the two icon families, Pick-by-concept, full name lists
  maintenance.md          changing the skill itself; what is generated from what
examples/
  example-deck.html       worked 5-slide deck, passes the gate
scripts/
  check_deck.py           quality gate — run before handing anything over
  test_gates.py           proves each gate fires on a defect and stays quiet otherwise
  normalize_icon.py       force an SVG into the LINE icon house style
  normalize_solid_icon.py force an SVG into the SOLID icon house style
  build_icons.py          regenerate the 50 line icons
  build_onepager.py       regenerate onepager.html from shell.html
  build_example.py        regenerate the example deck from shell.html
```

## The quality gate

```bash
python3 scripts/check_deck.py path/to/your-deck.html
```

It catches the failures that are expensive to spot by eye:

| Check | Why it matters |
|---|---|
| Logo integrity | The official swoosh path is present, and no stroke approximation or text wordmark is standing in for it |
| Self-contained | No external `src`, CDN, webfont, `@import`, absolute `url()`, or runtime network call |
| No active content | No inline `on*` handlers, `javascript:` URLs, `<iframe>`/`<object>`/`<foreignObject>`/`<use>`/`<image>`, or SVG animation elements |
| Brand purity | No foreign brand names or off-palette accent colours |
| Contrast | `#05dd4d` is not used as text on a light surface (~1.7:1 on white) |
| Print intact | The `@page` rule and print overrides survived editing |
| Structure | Tags balance, one slide is `active`, nav wiring is present, no placeholders left |

Exit code 0 means pass. The two shells report placeholder warnings by design — they are templates.

## Security posture

The skill has **no third-party dependencies** — the five scripts import only the Python standard
library (`argparse`, `pathlib`, `re`, `sys`), so there is no package supply chain to patch. Nothing
in the skill makes a network call, spawns a subprocess, or evaluates data as code.

Two properties are worth understanding before you extend it:

1. **An SVG inlined into HTML runs in the page's origin.** That makes a downloaded icon an
   executable-content risk, not just an image. `scripts/normalize_icon.py` therefore filters pasted
   art against an **allowlist** — only shape elements (`path`, `circle`, `rect`, `line`,
   `polyline`, `polygon`, `ellipse`, `g`) and geometry attributes survive. Handlers, `href`,
   `<script>`, `<foreignObject>`, `<use>`, `<image>`, and animation elements are dropped and
   reported on stderr. Run it over **any** SVG that did not come from `assets/icons/`.
2. **The gate is the backstop for hand-pasted art.** `check_no_active_content` in
   `scripts/check_deck.py` fails a deck that carries an inline handler, a `javascript:` URL, a
   framing element, or an absolute `url()` — so art pasted straight in, bypassing the normalizer,
   still cannot ship.

`--name` is restricted to `[a-z0-9-]` and the resolved output path is confirmed to sit inside
`assets/icons/`, so a crafted name cannot write elsewhere on disk.

## Brand ground rules

1. **Never redraw the logo.** Paste the SVG verbatim from `assets/brand/`. Not stroke primitives,
   not an icon, not a text-only `Solventum.` wordmark.
2. **`#05dd4d` is not a text colour on white.** It is roughly 1.7:1 — use `#0a7d38`
   (`var(--brand-deep)`) for anything text-sized on a light surface.
3. **Never invent a number.** Every figure gets a source note naming the system, the date range,
   and any exclusions.
4. **Chart geometry must match the data.** If a true-to-scale bar is invisible, that is the finding.

## Customising it

- **Logo refresh:** drop the new SVG into `assets/brand/` keeping the filenames. If the swoosh path
  changes, update `LOGO_MARKER` in `scripts/check_deck.py` to the new first curve.
- **Token change:** edit `:root` in `assets/shell.html`, then run
  `python3 scripts/build_onepager.py` and `python3 scripts/build_example.py` to propagate.
- **New icon:** `python3 scripts/normalize_icon.py my.svg --name my-icon`, then add it to
  `references/icon-index.md`.
- **New component:** add the CSS to both shells and the markup snippet to
  `references/components.md`. Keeping the gallery and the shells in step is what makes the skill
  usable by someone who did not build it.
