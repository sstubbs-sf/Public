---
name: solventum-html-slides
description: Build Solventum-branded HTML slide decks, one-pagers, and executive briefs as single self-contained files, with the official logo, brand colour system, component library, and landscape PDF export. Use whenever the user wants to build a deck, presentation, slide, exec brief, one-pager, board or steering-committee readout, QBR, roadmap, or any Solventum-styled HTML document. Triggers: build a deck, create a presentation, make a slide, HTML presentation, Solventum branded, exec brief, one-pager, executive summary, board deck, steering committee, QBR, roadmap deck, readout, leadership update, slide deck, export to PDF.
---

# Solventum HTML Slides

Build presentation-grade HTML in Solventum branding. Output is a **single self-contained `.html`
file** — no CDN, no webfont, no sidecar assets — that opens anywhere, emails cleanly, and prints
to landscape PDF with one slide per page.

Everything needed ships in this skill. Nothing is loaded from the network at render time.

## Files in this skill

| Path | What it is | When to read it |
|---|---|---|
| `assets/shell.html` | Deck shell: tokens, all component CSS, nav JS, print CSS | Copy for every deck |
| `assets/onepager.html` | One-pager / exec-brief shell, same tokens, prints portrait | Copy for every brief |
| `assets/brand/BRAND.md` | Logo rules, colour tokens, contrast rule, type scale, geometry | Before any colour or logo decision |
| `assets/brand/*.svg` | The three official logo forms | Paste from these, verbatim |
| `assets/icons/*.svg` | 326 icons in **two families** — 50 line, 276 solid | When a slide needs iconography |
| `assets/partner/*.svg` | 4 third-party cloud marks; keep their own colours | Labelling a storage source in a diagram |
| `references/components.md` | Copy-paste markup for every component, plus the slide budget | While building slides |
| `references/icon-index.md` | The two families, Pick-by-concept, per-family name lists | When choosing an icon |
| `references/maintenance.md` | Changing the skill itself: what is generated, gate self-test | Not needed to build a deck |
| `examples/example-deck.html` | Worked 5-slide deck; passes the quality gate | To see the target quality |
| `scripts/check_deck.py` | Quality gate — run before you hand anything over | Always, before delivery |
| `scripts/normalize_icon.py` | Force an SVG into the **line** icon house style | Adding a custom line icon |
| `scripts/normalize_solid_icon.py` | Force an SVG into the **solid** icon house style | Adding a custom solid icon |
| `scripts/test_gates.py` | Proves each gate fires on a defect and stays quiet otherwise | After editing `check_deck.py` |
| `scripts/build_icons.py`, `build_onepager.py`, `build_example.py` | Regenerate the shipped assets | Only when changing the system itself |

## Accuracy and sourcing — non-negotiable

A deck is an argument someone will act on. A wrong number in a beautiful deck is worse than no
deck, because the polish buys it trust it has not earned.

- **Never invent a number, date, name, owner, or status.** If the user has not supplied it, ask, or
  write the placeholder in visible caps (`TBD — OWNER`) so it cannot ship unnoticed.
- **Do not round in a flattering direction.** 41% is 41%, not "over 40%".
- **Every slide carrying figures gets a `.source-note`** naming the system, date range, and any
  exclusions. If you cannot name the source, the number does not go on the slide.
- **Chart geometry must match the data.** A bar at 60% width for a 12% value is a false statement.
  If a true-to-scale bar is invisible, that is the finding — label it, do not inflate it.
- **Do not restate the user's claims as measured results.** "Expected" and "achieved" are different
  slides.

## The logo

Paste the SVG verbatim from `assets/brand/`. Never redraw, reconstruct, or substitute it — not with
stroke primitives, not with an icon, not with a text-only `Solventum.` wordmark. The lockup is the
one element every reader recognises instantly, so a wrong one discredits the whole document.

- Deep-green or dark surface → `solventum-logo-horz-white.svg`
- White or light surface → `solventum-logo-horz-dark.svg`
- Tight space, bar, favicon → `solventum-mark-green.svg`

In the deck shell, the title slide carries the inline white lockup and content-slide footers draw
the ink lockup from the `--logo-dark` token. Both are already wired; do not replace them.

## Colour, in one paragraph

`#05dd4d` is the logo green and it is **roughly 1.7:1 on white** — it fails accessible contrast for
text and vanishes on a projector. Use `var(--brand-deep)` (`#0a7d38`) for anything text-sized on a
light surface, and reserve `var(--brand)` for the logo, accents on deep green, and fills 24px or
larger. Full token table in `assets/brand/BRAND.md`.

## Icons — two families, and they don't mix

`assets/icons/` holds **326 icons in two families**, and they are not interchangeable:

| | Line family | Solid family |
|---|---|---|
| Count | 50 | 276 |
| Geometry | `viewBox 0 0 24 24` | `viewBox 0 0 64 64` (5 exceptions) |
| Rendering | `stroke="currentColor"`, `fill="none"`, 1.6 stroke | `fill: currentColor`, declared in a `<style>` block inside the file |
| Wrapper | `.icon` | `.icon solid` |

**Never mix them inside one card grid, tier row, or step list.** Each icon looks correct on its own,
so this is a defect you cannot see while writing markup — but one filled icon in a row of 1.6px
outlines reads as two decks spliced together. Across a deck, one family per slide is fine; within a
component, pick one. `check_deck.py` warns when it finds both `viewBox`es in one grid.

Rules that cause silent, invisible failures if broken:

- **Paste the SVG inline. Never `<img src>`** — an external reference breaks the single-file guarantee.
- **Never rename a solid icon's internal classes.** `.ic-cost_savings-cls-1` looks redundant, but an
  inlined `<style>` block is **document-scoped**: with the vendor's generic `.cls-1` names the last
  icon on the page redefines the fill for every earlier one. Measured on the source deck: an icon
  whose `.cls-1` was `currentColor` rendered a hardcoded blue because a later icon defined `.cls-1`
  as `#5ab2e3`. The gate fails the build if generic names return.
- **Recolour on the icon element, not the parent.** `.icon` declares its own `color`, and a
  declaration beats inheritance, so `color` on the card has no effect whatsoever.
- **Five icons are not square** and a square box distorts them. Constrain **height**, not width —
  `marketplace` is 226×64, so sizing it by width renders it 26×7.36px: correct aspect ratio, useless
  on a slide. Use `.icon wide` for `marketplace`, `.icon tall` for the four `warehouse_*`; both are
  height-driven so everything in a row stays the same optical size.
- **45 icons carry hardcoded white interior detail** (all 44 `ra_*` plus `snowflake_trail`), which
  disappears on a white slide or the pale chip. Put those on `.icon-chip deep`.

The solid family is **official Snowflake artwork**. Most of it is generic concept iconography that
carries no vendor identity, but the named-product icons and all `ra_*` / `workloads_*` files will
read as a Snowflake product slide to anyone who knows the platform — `references/icon-index.md`
lists exactly which, and *Pick by concept* is where to start instead of scanning 326 filenames.

## The slide scrolls, never an inner box

`.slide-body` is the only scroll container. Two traps let an illustration steal the scroll and hide
most of itself, silently, with no error and no scrollbar to reveal it:

- **`overflow-x: auto` on a content box also creates a vertical scrollbar.** Per CSS spec, when one
  overflow axis is non-`visible` the `visible` axis computes to `auto`. Use `overflow: visible`. (A
  real failure this happened on: an `.arch-box` squashed to 41px against 353px of content, so an
  architecture diagram showed only its first line.)
- **`.slide-body` is a height-constrained flex column**, so children shrink below their content size
  by default. The shell handles this with one blanket rule, `.slide-body > * { flex-shrink: 0 }`, so
  any component you add is covered — do not remove it, and do not reintroduce per-component
  `flex-shrink: 1`.

If a diagram genuinely does not fit, shorten it or add `dense` to the slide. Do not make it scroll.


---

## Workflow

### 1. Establish the argument — before touching HTML

Ask for what you do not have. Do not guess at these:

- **Audience and decision.** Who is in the room, and what do they need to decide or approve?
- **The one-sentence takeaway.** If the audience remembers one thing, what is it?
- **The source material.** Numbers, status, owners, dates — and where they came from.
- **Format.** Navigable deck, one-pager / exec brief, or both.
- **Length.** Executive readouts land at 5-8 slides. A 20-slide deck for a 15-minute slot is a
  planning failure, not a thoroughness win.

Use `ask_user_question` for anything genuinely blocking. Do not ask what you can read from files
the user has already given you.

### 2. Outline, and stop

Write the slide-by-slide outline as **headline sentences**, not topics. "Automation is now the
cheapest capacity we have" is a headline; "Automation update" is a label. If the headlines read in
sequence do not make the argument on their own, the deck will not either.

For each slide name the component you will use (see the mapping table below).

**STOP. Show the outline and get agreement before building.** Restructuring an outline costs a
minute; restructuring 12 slides of HTML costs an hour, and the user will have stopped reading.

### 3. Build

Copy `assets/shell.html` (deck) or `assets/onepager.html` (brief) to the target path. Then:

1. Set `<title>`, the title slide, and the footer note.
2. Add one `<section class="slide">` per outline slide, each with a `.slide-body` and a
   `.slide-footer`.
3. Paste components from `references/components.md` as direct children of `.slide-body`.
4. Add an icon to every card grid, tier card, and step badge — this is the default, not a flourish.
   Start from `references/icon-index.md` → *Pick by concept*, and keep one family per component.
5. Leave the nav counter alone. `render()` computes it from `.slide` count, so there is nothing to
   update. Its `— / —` placeholder is deliberately non-numeric: if the script ever dies, dashes
   reveal that, where a hardcoded `1 / 2` would look plausible and hide it.

Never write your own CSS. Every class in the gallery is already defined in both shells. If you
find yourself adding a style rule, you are almost certainly rebuilding a component that exists —
check the gallery first. Genuine one-offs belong in a `style="--c:var(--amber)"` attribute, not a
new rule.

### 4. Verify

```bash
python3 scripts/check_deck.py path/to/deck.html
```

Fix every ERROR. Read every warning and decide deliberately.

The gate covers logo integrity, self-containment, brand purity, contrast, print CSS, structure,
sandbox safety, slide-scroll integrity, icon hygiene, icon-family consistency, and undeclared
tokens. What it **cannot** judge is layout, so look at the file too: open it, arrow through every
slide, and confirm no `.slide-body` scrolls and no inner box scrolls. A scrolling slide is a slide
the room cannot read — split it, or add `dense` to the `<section class="slide">` for about 20% more
room.

Check the PDF too: click **PDF**, choose landscape, and confirm one slide per page with nothing
clipped.

### 5. Hand over

Report the file path, the slide count, and anything you had to leave as a placeholder. Call out
explicitly any number you could not source — that is the thing most likely to embarrass the user
in the room.

---

## Content to component

| The content is... | Use | Notes |
|---|---|---|
| A single point that deserves the whole slide | headline + `.callout` | The strongest slide in the system |
| Before / after, old / new, us / them | `.two-col` with `ul.clean` and `ul.clean check` | The check list is the "after" side |
| 3-6 parallel items, each a sentence | `.cards` (3-up) or `.cards.two` | Add `.tag` for stage or status |
| 4-8 labels with no prose | `.cards.four` | Two rows maximum |
| Time horizons (now / next / later) | `.tier-grid` with `--c` per card | Green, amber, indigo — not red |
| A sequence of 4-6 actions | `.steps-grid` | Above 6, switch to `.scenes` |
| A sequence of 6-9 stages, or a storyboard | `.scenes` | Densest sequence layout |
| Rows and columns of facts | `.dtable` with `.pill` and `.badge` | `.num` for figures; `dense` past 8 rows |
| Headline metrics | `.stat-grid` | 4 maximum, each with a `.stat-note` |
| Two quantities compared | `.bars` with one `.hero` row | Widths must be proportional |
| A pipeline, flow, or system path | `.arch-box` with `.hl` / `.hl2` / `.hl3` | ASCII, dark panel, prints cleanly |
| 4-6 supporting facts | `.mini-card` in a `.two-col` | Compact, left accent |
| Objections you expect | `.qa-grid` | Use the room's own words |
| A definition or caveat that would clutter the slide | `.ipill` tooltip | Never load-bearing — hidden in print |
| The ask, or the closing statement | `.callout inverse` | Once per deck |
| Any card grid, tier card, or step badge | Pair it with an icon | `references/icon-index.md` → *Pick by concept* maps a topic to a name |
| An emoji as a visual (🔒, 🚀, ⚠️) | **Don't** — use the equivalent bundled SVG | Emoji render from a different font per OS, ignore the theme, and land in the PDF at the system font's size |

## Quality gates

Before handing anything over, all of these are true:

- [ ] `scripts/check_deck.py` reports no errors
- [ ] The official logo is pasted verbatim; no redraw, no text substitute
- [ ] Every figure has a `.source-note`; nothing is invented
- [ ] Bar and chart geometry is proportional to the values
- [ ] No `.slide-body` scrolls at 1120x690
- [ ] **No inner box scrolls either** — only `.slide-body` may. Check in the browser: no element
      other than `.slide-body` has `scrollHeight > clientHeight`
- [ ] **Icon families are not mixed** within any single grid, tier row, or step list
- [ ] `var(--brand)` is not used as text on a light surface
- [ ] Landscape PDF gives one slide per page, nothing clipped
- [ ] Exactly one slide carries `active`; the nav counter shows the real total
- [ ] Opens with no network: no CDN, webfont, or external `src`
- [ ] Any SVG taken from outside `assets/icons/` was run through the matching normalizer
      (`normalize_icon.py` for line, `normalize_solid_icon.py` for solid) — pasted art can carry an
      `onload` handler or a `<foreignObject>`, and an SVG inlined into HTML executes in the page's origin
- [ ] Headlines read as an argument when read in sequence

## Habits worth keeping

**Headlines are sentences.** A slide titled "Risks" tells the reader nothing; "Two feeds are still
manual, so the numbers lag a day" tells them everything and survives being forwarded without you.

**One idea per slide.** If a slide needs three components to make its point, it is two slides that
have not been separated yet.

**Say the ask plainly, once.** Use `.callout inverse` exactly once, on the decision. Two of them and
neither reads as important.

**Let white space work.** `.slide-body` centres content when it fits. Do not pad a sparse slide to
look busy — a deliberate single-point slide is a strength.

**Same treatment, same meaning.** If amber means "watch" on slide 3, it cannot mean "in progress" on
slide 6. Inconsistent colour makes the reader re-learn the deck on every slide.

## Handing the file to someone at Solventum

The output is one `.html` file. It opens in any browser with no install, no network, and no
attachments. To hand over the *skill* rather than a deck, zip this folder and drop it in
`~/.snowflake/cortex/skills/` (or a project's `.cortex/skills/`) — see `README.md`.
