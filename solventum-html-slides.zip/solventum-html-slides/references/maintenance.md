# Maintaining this skill

Everything here is for changing the skill itself — adding icons, regenerating the shipped assets,
verifying the gate script. None of it is needed to build a deck; `SKILL.md` covers that path and
deliberately does not carry this detail, so an agent building a deck does not read it.

Paths below use `<SKILL_DIR>` for this skill's directory, e.g.
`~/.snowflake/cortex/skills/solventum-html-slides`. Use absolute paths.

---

## What is generated and what is hand-maintained

This matters more than anything else here, because editing the wrong file means your change is
silently reverted the next time someone regenerates.

| File | Status | Source of truth |
|---|---|---|
| `assets/shell.html` | **hand-maintained** | itself — this is where CSS and JS changes go |
| `assets/onepager.html` | generated | `assets/shell.html`, via `scripts/build_onepager.py` |
| `examples/example-deck.html` | generated | `assets/shell.html` + slide content in `scripts/build_example.py` |
| `assets/icons/*` (50 line icons) | generated | `BODIES` in `scripts/build_icons.py` |
| `assets/icons/*` (276 solid icons) | **imported artwork** | the files themselves |
| `assets/partner/*` | **imported artwork** | the files themselves |

So a CSS or JS fix belongs in `shell.html`, followed by:

```bash
python3 <SKILL_DIR>/scripts/build_onepager.py
python3 <SKILL_DIR>/scripts/build_example.py
```

Both derive their CSS from the shell, so the fix propagates and cannot drift. Never hand-edit
`onepager.html` or `example-deck.html`.

`build_icons.py` writes only its own 50 named files and **does not clear the directory**, so
re-running it is safe with the solid family present. It will overwrite the ten names that exist in
both families (`calendar`, `cloud`, `code`, `database`, `flag`, `refresh`, `search`, `server`,
`target`, `users`) with the line versions — which is the intended precedence, not a bug.

---

## Verifying the gate script

`scripts/check_deck.py` is the skill's main quality mechanism, so it needs its own test:

```bash
python3 <SKILL_DIR>/scripts/test_gates.py
```

Each control is a defect that was actually measured. Some mutate `assets/shell.html` so a gate
**must** fire; others apply a legitimate variation that must stay **quiet**. Then all three shipped
fixtures (`assets/shell.html`, `assets/onepager.html`, `examples/example-deck.html`) must come back
with zero errors. Exit code is non-zero if any control misbehaves.

**Run it after every edit to `check_deck.py`.** The false positives are the more damaging half: a
gate that cries wolf gets skimmed past, and then it hides the real defect. Two measured examples
from building this version:

- The `flex-shrink` gate fired on `assets/onepager.html` for all ten components — a file with no
  `.slide-body` at all, so it cannot have the bug the gate describes. Ten confident warnings for an
  impossible defect.
- The foreign-brand gate fired on every file, because the skill's own CSS comment names the file
  `snowflake_trail`. A gate that reads its own documentation is worse than no gate.

Both are why `_strip_comments` and `_prose_only` exist, and why `check_scroll` returns early unless
a flex `.slide-body` is actually present.

When a control fails, **suspect the control first.** A needle that matches the mutation's own
filename, or a brace match that walks forward from a literal `@media print` inside the comment
documenting it, will "prove" a defect that never existed.

### Why headless rendering is not bundled

Every gate reads source text. The defects that actually reach recipients are runtime ones —
per-slide clipping, a blank first PDF page, navigation dying in a sandboxed iframe — and a regex can
only approximate those. So layout, print and sandbox verification stay **author checks in a real
browser**; see the quality-gate checklist in `SKILL.md`. If you revisit this, make a missing
renderer a distinct exit code rather than a pass.

---

## Adding or refreshing icons

Two families, two normalizers, and using the wrong one destroys the artwork. See
`references/icon-index.md` → *Adding your own* for the author-facing version.

```bash
# line family — 24-grid, stroke:currentColor, fill:none, stroke-width 1.6
python3 <SKILL_DIR>/scripts/normalize_icon.py <input.svg> --name my-icon

# solid family — fill:currentColor, per-file namespaced classes and ids
python3 <SKILL_DIR>/scripts/normalize_solid_icon.py <input.svg> --out <SKILL_DIR>/assets/icons
```

Note the interfaces differ: the line normalizer takes a `--name` stem and writes one file; the solid
normalizer takes an `--out` directory and also accepts a whole input directory plus `--index`.

`normalize_icon.py` rewrites the wrapper attributes, rescales a non-24 viewBox, filters the art to
an allowlist of shape elements, and refuses a non-square viewBox on purpose. It requires a
lowercase-hyphen name, matching the line family's convention.

`normalize_solid_icon.py` keeps fill-based rendering, maps the source palette to `currentColor`,
preserves white knockouts, strips Illustrator's embedded base64 PGF payload (which made four icons
~400 KB each), and namespaces every internal class and `id` to `ic-<name>-*`. That namespacing is
not cosmetic: an inlined SVG's `<style>` block is **document-scoped**, so with generic `.cls-1` names
the last icon on a page redefines the fill for every earlier one. `check_deck.py` fails the build if
generic names return.

**Re-running the solid normalizer over `assets/icons` is a verified no-op for the solid family** —
measured: all 276 come back byte-identical — so that folder is the source of truth once an icon has
been added by hand. But it is *not* harmless for the line family: it rewrites the 17 hyphenated
line-icon filenames to underscores (`alert-triangle` → `alert_triangle`), silently breaking every
reference, and strips the artwork the other normalizer expects. Point each script at its own family
only.

Update `references/icon-index.md` in the same commit as any icon change, and regenerate its
*Full lists* section from the directory rather than typing names, so the index cannot drift from
what is on disk.

### Partner marks

`assets/partner/` holds third-party cloud marks. Their colour *is* the mark — the AWS S3 Data
Protection glyph uses four reds — so flattening them to `currentColor` makes them unrecognisable.
Keep them out of both normalizers, and do not set `color` on the wrapper.

### Farming an icon out of a deck

Not bundled here. The `snowflake-html-deck` skill ships `scripts/pdf_icons.py`, which extracts
vector artwork from a PDF export by walking the content stream and clustering paths by proximity.
Use it there and copy the normalized result across.

---

## Keeping the docs honest

The recurring defect in a skill like this is documentation quoting values that drift from
`assets/shell.html`.

So: **do not restate shell CSS in the references.** Name the selectors, say what the shell does, and
point at it. `references/components.md` should carry CSS only for components the shell does not
ship. When you add a component to the shell, delete any copy of its CSS from the docs.

The same rule applies to counts. `SKILL.md` and `references/icon-index.md` both state icon totals;
those are checked against the directory by `test_gates.py`, so a claim that drifts fails the build
rather than quietly misleading the next author.
