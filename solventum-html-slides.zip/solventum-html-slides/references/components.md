# Component Gallery

Copy-paste HTML for every component. **All CSS for everything here already ships in
`assets/shell.html` and `assets/onepager.html`** — you paste markup only, never CSS. The
"Shell" column tells you where a component is at home.

| Component | Shell |
|---|---|
| Title slide, slide header, slide footer, nav, PDF button | deck only |
| Brand bar, meta strip, section head | one-pager only |
| Everything else | both |

Inside a deck, components are direct children of `.slide-body`; its `gap` handles the spacing, so
do not add margins. Inside a one-pager they are children of a `<section>` in `.doc`.

---

## 1. Title slide (deck)

```html
<section class="slide title active">
  <div class="slide-body">
    <!-- paste assets/brand/solventum-logo-horz-white.svg here, class="title-logo" -->
    <div class="eyebrow">Quarterly business review</div>
    <h1>Automation is now the cheapest capacity we have</h1>
    <div class="rule"></div>
    <div class="sub">Where the programme stands, what it returned, and the two decisions we need.</div>
    <div class="title-meta">Prepared for the IT Leadership Team &middot; March 2026</div>
  </div>
</section>
```

The same markup with a different eyebrow makes a **section divider** — a full-bleed green slide
between chapters. In a long deck, dividers are what let someone re-orient after looking away.

## 2. Slide header (numbered content slide)

```html
<div class="slide-header">
  <div class="sh-num">3</div>
  <div>
    <div class="sh-title">Where the time actually goes</div>
    <div class="sh-sub">Ticket volume by category, trailing 90 days</div>
  </div>
  <div class="sh-pg">Section 2 of 5</div>
</div>
```

Use *either* `.slide-header` or the `.eyebrow` + `<h2>` pair on a slide, not both.

## 3. Slide footer (deck)

```html
<div class="slide-footer">
  <span class="fnote">Automation programme review &middot; March 2026</span>
</div>
```

The Solventum lockup is drawn by `.slide-footer::before` from the `--logo-dark` token — you do not
paste a logo here. Put the footer on every content slide but not on title/divider slides.

## 4. Callouts

```html
<div class="callout">
  Neutral emphasis. Use for the sentence you want quoted back to you.
</div>

<div class="callout positive">
  <b>Result:</b> 41% of tier-1 tickets now resolve without a human touch.
</div>

<div class="callout warn">
  <b>Risk:</b> two of the four data feeds are still manual, so the numbers lag by a day.
</div>

<div class="callout inverse">
  <b>The ask:</b> approve two engineers for one quarter to close the remaining feeds.
</div>
```

`.inverse` is the strongest treatment in the system — dark panel, green bold. Use it once per deck,
on the ask or the closing statement. Two inverse callouts and neither reads as important.

## 5. Card grid

```html
<div class="cards">
  <div class="card">
    <span class="tag live">Live</span>
    <h3>Intake triage</h3>
    <p>Classifies and routes inbound requests. Running against production since January.</p>
  </div>
  <div class="card">
    <span class="tag next">Next</span>
    <h3>Knowledge answers</h3>
    <p>Answers from approved documentation with citations back to the source page.</p>
  </div>
  <div class="card">
    <span class="tag vision">Vision</span>
    <h3>Closed-loop remediation</h3>
    <p>Executes the fix and reports back, with an approval step for anything destructive.</p>
  </div>
</div>
```

`.cards` is 3-up. Add `.two` for 2-up (more room for prose) or `.four` for 4-up (labels only —
4-up cards cannot hold a sentence at a readable size). For a coloured top rule, use
`<div class="card accent" style="--c:var(--amber)">`.

Tag variants: `live` `now` `next` `later` `vision` `neutral`.

## 6. Tier / horizon cards

```html
<div class="tier-grid">
  <div class="tier-card" style="--c:var(--green)">
    <div class="tier-label">Now &middot; 0-3 months</div>
    <p>Finish the two manual feeds and retire the spreadsheet handoff.</p>
    <p>Owner: Platform team</p>
  </div>
  <div class="tier-card" style="--c:var(--amber)">
    <div class="tier-label">Next &middot; 3-9 months</div>
    <p>Extend triage to the clinical support queue.</p>
  </div>
  <div class="tier-card" style="--c:var(--indigo)">
    <div class="tier-label">Later &middot; 9+ months</div>
    <p>Closed-loop remediation with human approval gates.</p>
  </div>
</div>
```

Set `--c` per card. Use `--green` / `--amber` / `--indigo` for time horizons — reserve `--red` for
things that are genuinely at risk, or a horizon chart will read as three alarms.

## 7. Steps

```html
<div class="steps-grid">
  <div class="step-item">
    <div class="step-num">1</div>
    <div class="step-text">Inventory the queues and agree what "tier 1" means.</div>
  </div>
  <div class="step-item">
    <div class="step-num">2</div>
    <div class="step-text">Instrument the handoffs so the baseline is measured, not estimated.</div>
  </div>
</div>
```

Two columns. Above six steps, switch to `.scenes` — a step grid with eight cells reads as a wall.

## 8. Scenes / storyboard rows

```html
<div class="scenes">
  <div class="scene">
    <div class="n">1</div>
    <div class="b">
      <div class="t">Request arrives <span class="tag live">Live</span></div>
      <div class="d">Email or portal. Classified in under a second, routed with a confidence score.</div>
    </div>
  </div>
  <div class="scene">
    <div class="n vision">2</div>
    <div class="b">
      <div class="t">Draft resolution <span class="tag vision">Vision</span></div>
      <div class="d">Proposes the fix with citations; an engineer approves before anything executes.</div>
    </div>
  </div>
</div>
```

The densest way to show a sequence. Fits 8-9 rows on one slide.

## 9. Lists and columns

```html
<ul class="clean">
  <li>Green dot bullets. Good for three to six parallel points.</li>
  <li>Each item should be a claim, not a fragment.</li>
</ul>

<ul class="clean check">
  <li>Check bullets. Use only for things that are genuinely done.</li>
</ul>

<div class="two-col">
  <div>
    <div class="col-label">Today</div>
    <ul class="clean"><li>Manual triage, 4-hour median.</li></ul>
  </div>
  <div>
    <div class="col-label">After</div>
    <ul class="clean check"><li>Auto-routed, 6-minute median.</li></ul>
  </div>
</div>
```

`.three-col` exists for three parallel columns. Beyond three, use `.cards.four`.

## 10. Data table

```html
<table class="dtable">
  <thead>
    <tr><th>Workstream</th><th>Owner</th><th class="num">Hours saved / mo</th><th>Effort</th><th>Status</th></tr>
  </thead>
  <tbody>
    <tr>
      <td><strong>Intake triage</strong></td><td>Platform</td>
      <td class="num">640</td><td><span class="pill low">Low</span></td>
      <td><span class="badge shipped">Shipped</span></td>
    </tr>
    <tr>
      <td><strong>Knowledge answers</strong></td><td>Service desk</td>
      <td class="num">310</td><td><span class="pill med">Medium</span></td>
      <td><span class="badge build">In build</span></td>
    </tr>
  </tbody>
</table>
```

- `.num` right-aligns and applies tabular figures, so digits line up column-wise.
- Pills: `low` `med` `high` `info` — for a rating or a magnitude.
- Badges: `shipped` `build` `planned` `gray` — for delivery state.
- Above roughly 8 rows or 6 columns, add `dense` to the `.slide` or split the slide.

## 11. Q&A grid

```html
<div class="qa-grid">
  <div class="qa-row">
    <div class="qa-q">How do we know the numbers are real?</div>
    <div class="qa-a">Every figure comes from the ticketing export; the query is in the appendix.</div>
  </div>
  <div class="qa-row">
    <div class="qa-q">What happens if the model is wrong?</div>
    <div class="qa-a">Low-confidence items route to a human queue. Nothing executes unreviewed.</div>
  </div>
</div>
```

Write the objections you expect to be challenged on, in the words the room will use. A pre-answered
objection lands very differently from one you handle live.

## 12. Big stats

```html
<div class="stat-grid">
  <div class="stat">
    <div class="stat-num">41%</div>
    <div class="stat-label">Tier-1 tickets auto-resolved</div>
    <div class="stat-note">Jan-Mar 2026</div>
  </div>
  <div class="stat">
    <div class="stat-num">6 min</div>
    <div class="stat-label">Median time to route</div>
    <div class="stat-note">was 4 h 10 m</div>
  </div>
</div>
```

Four across maximum. Every `.stat-num` needs a `.stat-note` giving the period or the source —
a bare number invites the question you least want.

## 13. Bar comparison

```html
<div class="bars">
  <div class="bar-row">
    <div class="bar-head"><span class="bar-label">Manual triage</span><span class="bar-value">4h 10m</span></div>
    <div class="bar-track"><div class="bar-fill" style="width:100%"></div></div>
  </div>
  <div class="bar-row hero">
    <div class="bar-head"><span class="bar-label">Automated triage</span><span class="bar-value">6m</span></div>
    <div class="bar-track"><div class="bar-fill" style="width:2.4%"></div></div>
  </div>
</div>
```

**Bar widths must be proportional to the values.** 6 minutes against 4h10m is 2.4%, so the fill is
2.4% — a sliver. If a true-to-scale bar is invisible, that *is* the finding; label it rather than
inflating it. A chart whose geometry disagrees with its own numbers will be spotted, and then
nothing else on the slide is trusted.

## 14. Architecture / flow diagram

```html
<div class="arch-box">
  <div class="arch-title">Request path</div>
  Portal &middot; Email &middot; Phone
  <br />&nbsp;&nbsp;&#8595;
  <br /><span class="hl">Classifier</span> &#8594; confidence score
  <br />&nbsp;&nbsp;&#8595;
  <br /><span class="hl2">Auto-resolve</span> &nbsp;|&nbsp; <span class="hl3">Human queue</span>
  <br />&nbsp;&nbsp;&#8595;
  <br /><span class="dim">Audit log (every decision, retained 7 years)</span>
</div>
```

Monospace on a dark panel. `.hl` green, `.hl2` blue, `.hl3` violet, `.dim` for supporting detail.
Deliberately ASCII: it renders identically everywhere and prints cleanly, which a diagram library
cannot promise in a single offline file.

## 15. Mini cards

```html
<div class="two-col">
  <div class="mini-card" style="--c:var(--green)">
    <div class="mini-title">Data residency</div>
    <div class="mini-text">All processing stays in the existing tenancy. No new data movement.</div>
  </div>
  <div class="mini-card" style="--c:var(--amber)">
    <div class="mini-title">Open question</div>
    <div class="mini-text">Retention for rejected drafts is not yet agreed with Legal.</div>
  </div>
</div>
```

Compact left-accent cards. Good for 4-6 supporting facts that do not each deserve a full card.

## 16. Icons

```html
<!-- line family (24-grid outline) -->
<div class="card">
  <div class="icon-chip">
    <span class="icon"><!-- paste assets/icons/shield-check.svg --></span>
  </div>
  <h3>Reviewed before it acts</h3>
  <p>Nothing destructive executes without a named approver.</p>
</div>

<!-- solid family (64-grid filled) — note the `solid` class -->
<div class="card">
  <div class="icon-chip">
    <span class="icon solid"><!-- paste assets/icons/security_governance.svg --></span>
  </div>
  <h3>Governed by default</h3>
  <p>Policy is applied at the source, not per report.</p>
</div>
```

326 icons ship in **two families** that must not be mixed inside one grid. `references/icon-index.md`
has the names, the *Pick by concept* table, the five non-square cases, and the 45 icons whose white
interior detail needs `.icon-chip deep`.

## 17. Legend

```html
<div class="legend">
  <div class="legend-item"><span class="legend-swatch" style="--c:var(--green)"></span> On target</div>
  <div class="legend-item"><span class="legend-swatch" style="--c:var(--amber)"></span> Watch</div>
  <div class="legend-item"><span class="legend-swatch" style="--c:var(--red)"></span> At risk</div>
</div>
```

A legend must list exactly what is on the slide — no more. A legend entry with nothing rendered
against it makes the reader hunt for something that is not there.

## 18. Hover tooltip

```html
<span class="ipill">
  confidence score
  <span class="pop">
    The classifier's own probability that the routing is correct. Below 0.8 the item
    goes to the human queue.
  </span>
</span>

<span class="ipill link">
  method
  <span class="pop pleft">
    Median of per-ticket wall-clock time, tier-1 only.
    <a href="#appendix">See appendix</a>
  </span>
</span>
```

Add `.pleft` when the trigger is near the left edge, or the popover clips. Add `.link` to the
trigger when the popover contains a link, which keeps it open while the pointer travels into it.
Tooltips are hidden in print, so nothing inside one may be load-bearing for the PDF reader.

## 19. Source note

```html
<div class="source-note">
  Source: ServiceNow export, tickets closed 2026-01-01 to 2026-03-31 (n=18,442).
  Excludes P1 incidents.
</div>
```

Any slide carrying hard numbers gets one. It is the cheapest credibility in the deck.

## 20. One-pager section head

```html
<section>
  <div class="sec-head">
    <span class="sec-num">02</span>
    <span class="sec-title">What we recommend</span>
    <span class="sec-note">Decision needed by 15 April</span>
  </div>
  <p class="lede">One-sentence summary of the recommendation.</p>
  <!-- any component from this gallery -->
</section>
```

---

## White space and overflow

`.slide-body` uses `margin:auto` with `max-height:100%; overflow-y:auto`. When content fits it is
vertically centred; when it overflows the autos collapse and it top-aligns and scrolls internally.

So a slide never clips — but a slide that *scrolls* is a slide the room cannot read. If the body
scrolls, the content is too much: split it, or add `dense` to the `.slide` (tighter gaps, smaller
table type). `dense` buys about 20% more room. Past that, split.

Conversely, do not fight empty space with padding. If a slide looks sparse, either it is a
deliberate single-point slide (good) or it should be merged with its neighbour.

## Slide budget

At a readable projected size, one slide holds roughly:

| Component | Comfortable | Maximum |
|---|---|---|
| `.cards` (3-up) | 3 | 6 (two rows) |
| `.cards.four` | 4 | 8 (two rows, labels only) |
| `.dtable` rows | 6 | 10 with `dense` |
| `ul.clean` items | 4 | 7 |
| `.scenes` rows | 6 | 9 |
| `.steps-grid` items | 4 | 6 |
| `.stat-grid` | 3 | 4 |
| `.qa-row` | 3 | 5 |

Headline plus one component is the strongest slide in the system. Headline plus three components is
usually two slides that have not been separated yet.
