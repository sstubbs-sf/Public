# Icon Index

326 icons in `assets/icons/`, in **two families that are not interchangeable**, plus 4 partner
marks in `assets/partner/`. Reference every icon by filename without the `.svg`.

| | Line family | Solid family |
|---|---|---|
| Count | 50 | 276 |
| `viewBox` | `0 0 24 24` | `0 0 64 64` (5 exceptions below) |
| Rendering | `stroke="currentColor"`, `fill="none"`, stroke-width 1.6, round caps | `fill: currentColor` declared in a `<style>` block inside the file |
| Wrapper class | `.icon` | `.icon.solid` |
| Weight on the page | light outline | noticeably heavier, more graphic |

**Do not mix the two inside one card grid, tier row, or step list.** Each looks correct in
isolation, so this is a defect you will not see while writing markup — but a row of 1.6px
outlines with one filled icon in it reads as two decks spliced together. `check_deck.py` warns
when it finds both `viewBox`es inside one grid. Across a deck, one family per slide is fine;
within a component, pick one.

## How to use one

Open the `.svg`, copy its contents, and paste it inline inside a wrapper. Never
reference the file with `<img src>` — an external reference breaks the single-file guarantee.

```html
<!-- line family -->
<span class="icon"><!-- paste assets/icons/shield-check.svg here --></span>

<!-- solid family -->
<span class="icon solid"><!-- paste assets/icons/security_governance.svg here --></span>

<!-- in a chip, the usual treatment beside a card heading -->
<div class="icon-chip"><span class="icon"><!-- icon svg --></span></div>
```

**Recolour on the icon element itself, not on a parent.** `.icon` declares its own `color`, and a
declaration beats inheritance — so `color` on the surrounding card has no effect at all. Use
`<span class="icon" style="color:var(--amber)">`, or set `color:inherit` on `.icon` if you want
container-driven tinting. Both families follow `color`, so never set `fill` or `stroke` by hand.

**Do not rename the internal class names when you paste a solid icon.** They look redundant
(`.ic-cost_savings-cls-1`), but an SVG's `<style>` block becomes **document-scoped** the moment it
is inlined. With the vendor's original generic `.cls-1` names, the last icon on the page silently
redefines the fill for every earlier one — measured on the source deck: an icon whose `.cls-1` was
`currentColor` rendered a hardcoded blue because a later icon defined `.cls-1` as `#5ab2e3`. The
`ic-<name>-` prefix is the only thing preventing that, and `check_deck.py` fails the build if
generic names come back.

## Two gotchas that bite silently

**Five icons are not square.** A square box distorts them badly. Constrain **height** and let width
follow — for both orientations. Sizing a landscape lockup by *width* is the trap: `marketplace` is
226x64, so `width:26px` renders it **26 x 7.36px** (measured in the browser) — the correct aspect
ratio and a useless faint smudge. Height-driven also keeps every icon in a row at the same optical
size.

| Icon | Aspect | Use | Renders about |
|---|---|---|---|
| `marketplace` | 226x64, landscape | `.icon wide` | 92 x 26px |
| `warehouse_adaptive` | 43.58x52.45, portrait | `.icon tall` | 22 x 26px |
| `warehouse_data` | 43.58x52.44, portrait | `.icon tall` | 22 x 26px |
| `warehouse_gen2` | 43.58x52.45, portrait | `.icon tall` | 22 x 26px |
| `warehouse_snowpark` | 43.58x52.45, portrait | `.icon tall` | 22 x 26px |

`marketplace` is not an icon at all — it is a full lockup (mark plus wordmark). Never use it as a
tile icon in a card grid, and give it more height than 26px if it needs to be read.

**45 icons carry hardcoded white interior detail** (`fill: #fff`) rather than knocking through to
the background: all 44 `ra_*` icons plus `snowflake_trail`. That detail disappears on a white slide
or on the pale `.icon-chip`. Put those on `.icon-chip deep`, which is dark enough for the knockout
to read as detail instead of a hole:

```html
<div class="icon-chip deep"><span class="icon solid"><!-- ra_table.svg --></span></div>
```

## Before you use the solid family in a client-facing deck

The solid family is **official Snowflake artwork**. Most of it is generic concept iconography
(`cost_savings`, `security_governance`, `data_engineering`) that carries no vendor identity and is
safe anywhere. Some of it is not, and will read as a Snowflake product slide to anyone who knows
the platform:

- **Named products**: `cortex`, `copilot`, `snowpark`, `snowpark_containers`, `snowconvert_ai`,
  `streamlit_in_snowflake`, `snowflake_trail`, `openflow`, `horizon`, `marketplace`,
  `iceberg_tables`, `dynamic_tables`, `hybrid_tables`, `native_app`, `operating_snowflake`,
  `warehouse_*`, `sno_database`, `sno_databases`
- **All 60 `ra_*`**: these depict Snowflake objects specifically — schemas, virtual warehouses,
  account roles, masking policies. Use them for a Snowflake architecture diagram, not as decoration.
- **All 16 `workloads_*`**: these are Snowflake's own workload-pillar marks.

None of this is blocked — pick what serves the slide. But `check_deck.py` will warn if a vendor
name reaches the reader as *prose*, and that warning is worth reading rather than clearing.

## Pick by concept

Start here rather than scanning 326 filenames. First entry in each row is the safe default.
Names in **bold** are from the line family; everything else is solid.

| Slide is about | Use |
|---|---|
| Status / outcome | **`check-circle`**, **`x-circle`**, **`alert-triangle`**, **`flag`**, `check`, `no`, `results`, `faster_insights`, `eliminate_delays` |
| Risk / watch items | **`alert-triangle`**, **`eye`**, **`gauge`**, **`clock`**, `alert`, `integrity` |
| Trend / metrics | **`trending-up`**, **`trending-down`**, **`bar-chart`**, **`pie-chart`**, **`percent`**, `analytics`, `data_analytics`, `accelerated_analytics` |
| Cost / value | **`dollar`**, `cost_savings`, `pricing`, `optimization`, `profit`, `economy_scale`, `capacity` |
| Time horizons / plan | **`calendar`**, **`clock`**, **`target`**, **`flag`**, `time`, `launch`, `process` |
| Pipelines / integration | **`workflow`**, **`link`**, **`refresh`**, `data_engineering`, `simplify_pipelines`, `kafka_connectors`, `spark_connect` |
| Data stores / formats | **`database`**, **`layers`**, **`grid`**, `structured_data`, `semi_structured_data`, `unstructured_data`, `storage_compute`, `external_tables` |
| Compute / performance | **`gauge`**, **`zap`**, `concurrency`, `instant_elasticity`, `performance_scale`, `scale` |
| Governance / security | **`shield-check`**, **`shield`**, **`lock`**, **`key`**, `security_governance`, `security`, `secure_data`, `access`, `tag`, `trusted`, `metadata` |
| Automation / systems | **`terminal`**, **`code`**, **`server`**, **`settings`**, `dev`, `sql`, `web_app`, `application`, `tools` |
| Monitoring / operations | **`eye`**, **`gauge`**, `log`, `management`, `easy_management`, `simplify_admin`, `alert` |
| Consolidation / migration | **`layers`**, `consolidate`, `easy_consolidate`, `easily_onboard`, `all_your_data`, `integrated_data`, `single_source_truth`, `hadoop_replace` |
| Sharing / collaboration | **`link`**, **`message-square`**, `sharing_collaboration`, `application_collaboration`, `private_data_exchange` |
| People / organisation | **`user`**, **`users`**, **`message-square`**, **`mail`**, `corporate`, `enterprise`, `self_service`, `users_multiple` |
| Clinical / care | **`heart-pulse`**, **`stethoscope`**, **`hospital`**, `industry_healthcare`, `industry_patient_data`, `industry_provider`, `industry_digital_health` |
| Life sciences / regulated | `industry_life_sciences`, `industry_pharma`, `industry_health_payers_insurance`, `industry_insurance` |
| Manufacturing / supply | `industry_manufacturing`, `industry_transport`, `industry_cpg`, `industry_retail`, `industry_fulfilment_partner` |
| Documents / evidence | **`file-text`**, **`folder`**, **`book`**, **`clipboard-check`**, **`search`**, **`filter`**, `documentation`, `case_study`, `data_sheet` |
| AI | `cortex`, `ai_star`, `document_ai`, `ai_star_triple` — see the client-facing note above |
| File types | **`file-text`**, `csv`, `json`, `xml`, `xls`, `generic_file`, `spreadsheet_1`, `video` |
| Ideas / enablement | **`lightbulb`**, `idea`, `think_big`, `webinar`, `workshop`, `event`, `blog` |

For a vertical, use `industry_<name>`. For a diagram of Snowflake objects, `ra_<object>` on a
`.icon-chip deep`.

## Ten names resolve to the line family

These names exist in both sets. The **line icon won** in every case, so `database` is the 24-grid
outline, not the 64-grid solid version — which means a card grid using them stays visually
consistent with the rest of the line family by default:

`calendar`, `cloud`, `code`, `database`, `flag`, `refresh`, `search`, `server`, `target`, `users`

## Watch the spelling

The solid set ships three of its own misspellings. They are the real filenames — do not "correct"
them, or the reference breaks:

`comunicate` (one m), `mulitmedia` (transposed), `workloads_data_engeneering` (and
`workloads_data_engeneering_highlight`)

## Choosing an icon at all

Icons carry meaning; they do not decorate. A slide where every card has an icon and none of them
mean anything is worse than a slide with none, because the reader spends attention decoding them
and gets nothing back.

- Use an icon when it labels a **category** the reader will scan for (a security item vs a data item).
- Skip icons on slides already dense with numbers or tags.
- One icon per card, one size, one colour family per slide.
- Never use an emoji instead. There are 326 SVGs here; an emoji renders from a different font on
  every OS, ignores the theme, and lands in the PDF at whatever size the system font gives it.
  `check_deck.py` warns on emoji inside slide content.

## Adding your own

Two families, two normalizers. Using the wrong one damages the icon.

```bash
# line family: 24-grid, stroke, fill:none. Takes a --name stem.
python3 scripts/normalize_icon.py my-icon.svg --name pipeline

# solid family: fill:currentColor, namespaced per-file classes. Takes an --out dir.
python3 scripts/normalize_solid_icon.py my-icon.svg --out assets/icons
```

`normalize_icon.py` rewrites the wrapper attributes, rescales a non-24 viewBox, and filters the art
down to an allowlist of shape elements. It refuses a non-square viewBox on purpose, and requires a
lowercase-and-hyphen name.

`normalize_solid_icon.py` keeps the fill-based rendering, maps the source palette to `currentColor`,
preserves white knockouts, and namespaces every internal class and `id` to `ic-<name>-*` — which is
what stops inlined icons from restyling each other.

**Do not point either one at the other family's artwork.** Measured on the shipped set: running the
solid normalizer over `assets/icons` leaves all 276 solid icons byte-identical (it is correctly a
no-op), but it rewrites the 17 hyphenated line-icon names to underscores — `alert-triangle` becomes
`alert_triangle` — which silently breaks every reference to them, on top of stripping the `<style>`
block. The damage is a rename, not an error message.

**Always run one of them on art from the internet.** An SVG inlined into HTML executes in the
page's origin, so a downloaded icon can carry an `onload` handler, a `javascript:` link, or a
`<foreignObject>` that runs when someone opens the deck. Both normalizers drop all of that and
print what they removed. Anything stripped that you actually needed was not an icon.

## Partner marks (4) — `assets/partner/`

`aws_s3_bucket`, `aws_s3_data_protection`, `azure_blob_storage`, `google_cloud_storage`

**These keep their original colours and are deliberately NOT theme-adaptive.** They are third-party
trademarks (AWS, Microsoft, Google) whose colour is part of the mark — recolouring them to
`currentColor` would flatten a multi-tone logo into one tone and make it unrecognisable. Inline them
the same way, but do not set `color` on the wrapper and do not run them through either normalizer.
Use them only to label a cloud storage source in an architecture diagram, never as decorative tiles.
`check_deck.py` will warn about the vendor names; that warning is correct and expected here.

## Full lists

### Line family (50)

`alert-triangle`, `arrow-right`, `arrow-up-right`, `bar-chart`, `book`, `calendar`, `check-circle`, `clipboard-check`, `clock`, `cloud`, `code`, `database`, `dollar`, `eye`, `file-text`, `filter`, `flag`, `folder`, `gauge`, `grid`, `heart-pulse`, `hospital`, `key`, `layers`, `lightbulb`, `link`, `lock`, `mail`, `map-pin`, `message-square`, `minus-circle`, `percent`, `pie-chart`, `plus-circle`, `refresh`, `search`, `server`, `settings`, `shield-check`, `shield`, `stethoscope`, `target`, `terminal`, `trending-down`, `trending-up`, `user`, `users`, `workflow`, `x-circle`, `zap`

### Solid — general (162)

`3rd_party`, `3rd_party_app_2`, `accelerated_analytics`, `access`, `ai_star`, `ai_star_triple`, `alert`, `all_your_data`, `analytics`, `application`, `application_collaboration`, `architecture`, `backup`, `be_excellent`, `blog`, `blog_report`, `capacity`, `case_study`, `check`, `comunicate`, `concurrency`, `connected`, `consolidate`, `contact_sales`, `copilot`, `copy`, `corporate`, `cortex`, `cost_savings`, `csv`, `cube`, `data`, `data_analytics`, `data_engineering`, `data_monetization`, `data_sheet`, `desktop`, `dev`, `document_ai`, `documentation`, `dynamic_tables`, `easily_onboard`, `easy_consolidate`, `easy_management`, `economy_scale`, `edit`, `eliminate_complexity`, `eliminate_delays`, `email`, `embedded_analytics`, `enterprise`, `event`, `expand`, `external_tables`, `faster_insights`, `finance_option`, `flexibility`, `free_trial`, `generic_file`, `generic_file_1`, `geospatial_analytics`, `hadoop`, `hadoop_replace`, `happy_hour`, `horizon`, `hybrid_tables`, `iceberg_tables`, `idea`, `industry`, `information`, `instant_elasticity`, `integrated_data`, `integrity`, `iot`, `javascript`, `json`, `kafka_connectors`, `laptop`, `launch`, `location`, `log`, `make_each_other_best`, `management`, `marketplace`, `metadata`, `mobile`, `mulitmedia`, `native_app`, `no`, `on_demand`, `openflow`, `operating_snowflake`, `optimization`, `optimize`, `own_it`, `pay_to_play`, `performance_scale`, `platform`, `play`, `pricing`, `private_data_exchange`, `process`, `process_1`, `processes`, `profit`, `proxy`, `public_data_exchange`, `put_customers_first`, `results`, `scale`, `secure_data`, `security`, `security_governance`, `self_service`, `semi_structured_data`, `servers`, `services`, `sharing_collaboration`, `simplify_admin`, `simplify_pipelines`, `single_source_truth`, `sno_database`, `sno_databases`, `snowconvert_ai`, `snowflake_trail`, `snowpark`, `snowpark_containers`, `social`, `spark_connect`, `speed_1`, `speed_2`, `spreadsheet_1`, `spreadsheet_2`, `sql`, `sql_1`, `storage_compute`, `streamlit_in_snowflake`, `structured_data`, `tag`, `think_big`, `time`, `tlog`, `tools`, `transactions`, `trusted`, `universal_search`, `unstructured_data`, `user_1`, `user_2`, `users_multiple`, `video`, `warehouse_adaptive`, `warehouse_data`, `warehouse_gen2`, `warehouse_snowpark`, `web_app`, `web_search`, `webinar`, `workshop`, `world`, `xls`, `xml`

### Solid — industry verticals (38)

`industry_advertising`, `industry_automotive`, `industry_banking`, `industry_cpg`, `industry_data_providers`, `industry_digital_health`, `industry_ecommerce`, `industry_education_higher`, `industry_education_k_12`, `industry_federal`, `industry_fin_tech`, `industry_financial_services`, `industry_fulfilment_partner`, `industry_gambling`, `industry_gaming`, `industry_hardware_semiconductors`, `industry_health_payers_insurance`, `industry_healthcare`, `industry_industry`, `industry_insurance`, `industry_investments`, `industry_life_sciences`, `industry_manufacturing`, `industry_media_platforms`, `industry_media_publishers`, `industry_mining`, `industry_patient_data`, `industry_pharma`, `industry_provider`, `industry_public_sector`, `industry_retail`, `industry_software`, `industry_sports_leagues_teams`, `industry_state`, `industry_storefront`, `industry_technology`, `industry_telecommunications`, `industry_transport`

### Solid — ra_* reference-architecture objects (60)

`ra_data`, `ra_failover_group`, `ra_failover_group_data_science`, `ra_failover_group_finance`, `ra_failover_group_it`, `ra_failover_group_sales`, `ra_file`, `ra_file_audio`, `ra_file_avro`, `ra_file_csv`, `ra_file_image`, `ra_file_json`, `ra_file_parquet`, `ra_file_text`, `ra_file_video`, `ra_file_xlw`, `ra_file_xml`, `ra_function`, `ra_function_aggregate`, `ra_function_external`, `ra_function_scalar`, `ra_function_stored_procedure`, `ra_function_system`, `ra_function_table`, `ra_function_user_defined_java`, `ra_function_user_defined_javascript`, `ra_function_user_defined_sql`, `ra_function_user_defined_table`, `ra_function_window`, `ra_pipe`, `ra_policy`, `ra_policy_masking`, `ra_policy_network`, `ra_policy_row`, `ra_policy_session`, `ra_role`, `ra_role_account_admin`, `ra_role_org_admin`, `ra_role_public`, `ra_role_security_admin`, `ra_role_sys_admin`, `ra_role_user_admin`, `ra_schema`, `ra_snowflake_database`, `ra_stage`, `ra_stage_external`, `ra_stream`, `ra_table`, `ra_table_directory`, `ra_table_dynamic`, `ra_table_external`, `ra_table_hybrid`, `ra_table_iceberg`, `ra_tag`, `ra_task`, `ra_view`, `ra_view_materialized`, `ra_view_secure`, `ra_virtual_warehouse`, `ra_volume`

### Solid — workloads_* pillars (16)

`workloads_ai`, `workloads_ai_highlight`, `workloads_collaboration`, `workloads_collaboration_highlight`, `workloads_cybersecurity`, `workloads_cybersecurity_highlight`, `workloads_data_applications`, `workloads_data_applications_highlight`, `workloads_data_engeneering`, `workloads_data_engeneering_highlight`, `workloads_data_lake`, `workloads_data_lake_highlight`, `workloads_data_warehouse`, `workloads_data_warehouse_highlight`, `workloads_unistore`, `workloads_unistore_highlight`
