# IT Operations Scorecard — Deploy This App

A complete, self-contained bundle to stand up the **IT Operations Scorecard** — a
Next.js app on Snowflake App Runtime with a Cortex Agent, semantic view, tables, and
seed data — in a **fresh Snowflake account**. Footprint: **1 role + 2 users**.

If you are a person: open this folder in **Cortex Code (CoCo) Desktop** and say
*"review the README in this folder and build and deploy this app end to end."*
CoCo will ask you a few questions, then do the rest.

---

## Prerequisites — have these ready before you start

**On your machine (the person deploying):**
- **Cortex Code Desktop**, signed in to the **target** Snowflake account, model set to **Opus 4.8**.
- **Snowflake CLI 3.19 or later** — check with `snow --version`, and confirm App Runtime commands
  exist with `snow app setup --help`. Install/upgrade: https://docs.snowflake.com/en/developer-guide/snowflake-cli/installation/installation
- **A Snowflake CLI connection** pointing at the target account — list with `snow connection list`.
  If none exists, create one with `snow connection add` (you'll need account/user/auth details).
- **Node.js 22+** — **only if you want to test the app locally**. Not needed for the deploy
  (the app image is built remotely inside Snowflake).

**In the Snowflake account:**
- A **paid Snowflake account** — App Runtime is not available on trial accounts.
- A role with **`ACCOUNTADMIN`** (or equivalent rights to create databases/warehouses/roles,
  grant privileges, and deploy an Application Service).
- **Cortex enabled** and **`claude-opus-4-8` available in the account's region** — or enable
  cross-region inference: `ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';`
- A **CPU compute pool** for the app service — `SYSTEM_COMPUTE_POOL_CPU` (Snowflake-provided) is
  used by default; if your account lacks it, create a small pool and set `COMPUTE_POOL` in `config.env`.
- **(Only if enabling Web Search)** ability to toggle Web Search once in Snowsight (ACCOUNTADMIN):
  **AI & ML » Agents » Settings » Web search**.

> No Docker, no CI/CD, and no external secrets are required. `snow app deploy` builds the image
> remotely; npm + Google Fonts egress is allowed by default, and `01_prereqs.sql` adds npm/GitHub
> egress explicitly so the build is self-sufficient.

CoCo verifies the machine-side items automatically in Phase 0 and the account-side items in Phase 2.

---

# ⭐ IF YOU ARE CORTEX CODE — START HERE (deployment runbook)

You are deploying this bundle into the **user's own Snowflake account**, which is
**different from where it was built**. Follow these phases in order. **Run autonomously
and stop only if a step errors**; when something fails, show the error and the fix, then
continue after it's resolved.

**Ground rules**
- **This file is the only deployment procedure.** Ignore `app/README.md` and `app/AGENTS.md`
  — those are app-development notes, not deploy instructions.
- Run all SQL through your Snowflake connection **as the deploy role** (default `ACCOUNTADMIN`).
- Run `snow` CLI commands with the chosen connection and role.
- Never invent values. Everything configurable lives in `config.env`.

### Phase 0 — Gather the few things you need (ask the user)
First, verify the machine-side prerequisites (see **Prerequisites** above): run `snow --version`
(need **3.19+**) and `snow app setup --help` (must succeed), and `snow connection list` (a
connection to the target account must exist). If any is missing, stop and tell the user exactly
how to fix it before continuing.

Then ask the user these questions (use your question UI), and write the answers into `config.env`:
1. **The two app users** — their Snowflake login names (`USER1`, `USER2`). For each, check
   `SHOW USERS LIKE '<login>'`. If a user does **not** exist, ask whether to **create** it and how:
   (a) password with forced reset on first login, or (b) they'll use SSO / an existing identity
   (create with no password). Record what you'll do.
2. **Deploy connection** — run `snow connection list`; confirm which connection points at the
   target account (`DEPLOY_CONNECTION`) and the role to use (`DEPLOY_ROLE`, default `ACCOUNTADMIN`).
3. **Web search** — the agent can use a Web Search tool, which needs a one-time Snowsight toggle.
   Ask: enable it (you'll guide them through the toggle) or deploy **analyst-only**? Set `ENABLE_WEB_SEARCH`.

Everything else in `config.env` (database, role, warehouse, agent names) has safe defaults —
**do not ask about these** unless the user brings them up.

### Phase 1 — Confirm object names (no substitution needed)
The SQL in `snowflake_setup/*.sql`, `app/service-spec.yml`, and `app/snowflake.yml` already
reference the final object names (single-namespace `ITSCORECARD` build) — there are **no tokens
to substitute**. Just confirm the names in `config.env` match what you want. Everything lives in
one schema: **`ITSCORECARD.ITSCORECARD_DEMO`**.

> **If (and only if) you rename `DATABASE`/`SCHEMA`** from the defaults `ITSCORECARD` /
> `ITSCORECARD_DEMO`: update the `image:` line in `app/service-spec.yml` to the **lowercased**
> path (e.g. `/mydb/myschema/app_images/scorecard-app:latest`) and the identifiers across the
> SQL + `snowflake.yml`. With the defaults, everything shipped is already correct.

### Phase 2 — Preflight (read-only)
Run `snowflake_setup/00_preflight.sql` and interpret the output:
- **Compute pool**: if `SYSTEM_COMPUTE_POOL_CPU` (default `SYSTEM_COMPUTE_POOL_CPU`) is absent, tell the
  user and either create a small pool or set a different one in `config.env` (see note in `01`).
- **Cortex region**: if `claude-opus-4-8` may not be in the account's region, run
  `ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';` (confirm with the user first).
- **Existing database**: if `ITSCORECARD` already exists, this is a re-deploy — confirm before proceeding.

### Phase 3 — Create data + objects (stop on error)
Run in order, as the deploy role: `01_prereqs.sql`, `02_schema.sql`, `03_seed_data.sql`,
`04_semantic_view.sql`. Each prints a `... complete` status. Fix any error before continuing.

### Phase 4 — Create the agent
- If `ENABLE_WEB_SEARCH=true`: **pause** and ask the user to enable web search once in Snowsight:
  **AI & ML » Agents » Settings » toggle "Web search" on** (requires ACCOUNTADMIN).
  Wait for their confirmation, then run `05_cortex_agent.sql`.
- If `ENABLE_WEB_SEARCH=false`: run `05_cortex_agent_analyst_only.sql` instead.

### Phase 5 — Roles, users, grants
- If Phase 0 flagged missing users, create them now (using the chosen auth). Templates are in
  `06_role_and_users.sql` (commented) — uncomment/fill the ones you need.
- Run `06_role_and_users.sql` (creates the role, grants the full bundle, grants role to both users).

### Phase 6 — Deploy the app
```
cd app
snow app deploy -c <DEPLOY_CONNECTION> --role <DEPLOY_ROLE>
```
This uploads the code, builds the image remotely (uses the npm integration from `01`), creates the
Application Service, and prints **`App ready at https://…`**. Capture that URL.
- Deploying as `ACCOUNTADMIN` with this bundle's explicit `snowflake.yml` identifier lands the app
  in the standard database `ITSCORECARD.ITSCORECARD_DEMO` (shareable). You do **not** need `snow app setup`.
- If the CLI still deploys to a personal `USER$<login>` database, have an admin complete Snowsight
  **Account admin setup for App Runtime** (or set account defaults), then re-deploy.

### Phase 7 — Grant access + verify, then report
- Run `07_grant_app_access.sql` (grants the app URL to `ITSCORECARD_DEMO_USERS`).
- Run `08_verify.sql` and confirm: 21 metrics · 273 monthly · 21 initiatives · 135 links, the agent
  exists, and the grants are present.
- Report to the user: the **app URL**, the **role** and **two users** granted, and that they can sign
  in with their Snowflake credentials. Remind them (if web search enabled) it only works after the toggle.

---

## What's in this bundle
```
it-scorecard-handoff/
├── README.md                 ← this runbook (the only deploy procedure)
├── AGENTS.md                 ← tells CoCo to follow README.md
├── config.env                ← the variables (edit USER1/USER2; rest defaults)
├── snowflake_setup/          ← ordered SQL (run as the deploy role)
│   ├── 00_preflight.sql          read-only environment checks
│   ├── 01_prereqs.sql            Medium Gen2 (1-10) warehouse + database/single schema + npm build integration
│   ├── 02_schema.sql             6 tables (incl. USER_PREFS), 2 sequences, chat-uploads stage
│   ├── 03_seed_data.sql          21 metrics · 273 monthly · 21 initiatives · 135 links
│   ├── 04_semantic_view.sql      Cortex Analyst semantic view (backs the agent)
│   ├── 05_cortex_agent.sql             agent WITH Web Search (claude-opus-4-8)
│   ├── 05_cortex_agent_analyst_only.sql  agent WITHOUT Web Search (fallback)
│   ├── 06_role_and_users.sql     ONE full-rights role + users
│   ├── 07_grant_app_access.sql   RUN AFTER deploy — grants the app URL to the role
│   └── 08_verify.sql             post-deploy verification queries
├── app/                      ← the Next.js application (`snow app deploy`)
└── data_export/              ← CSV copies of the seeded data (reference/backup)
```

## How it works (architecture)
- **Frontend/API:** Next.js (App Router) as a Snowflake App Runtime service. API routes use the
  Snowflake SQL REST API; long file operations use the `snowflake-sdk` driver.
- **Data:** all in one schema `ITSCORECARD.ITSCORECARD_DEMO`: `{METRICS, METRIC_MONTHLY_DATA, INITIATIVES, INITIATIVE_KPI_LINKS, COMMENTS}` + ID sequences for new rows, plus `USER_PREFS` (per-user UI settings, e.g. saved table column order).
- **AI chat:** Cortex Agent (orchestrates on **claude-opus-4-8**) with an **Analyst** tool over the
  semantic view + optional **Web Search**. Threads use the native Cortex Threads API (no extra tables).
- **Identity:** users are identified by the Snowflake ingress header on the app endpoint — no separate
  auth, no PATs. Object names are read from `SF_*` env vars in `service-spec.yml` (default to `config.env`).

## Security model (1 role, 2 users)
- **`ITSCORECARD_DEMO_USERS`** has **FULL rights** on `ITSCORECARD` + `ITSCORECARD_DEMO_WH`: ALL privileges on the database, schema,
  and warehouse (existing + future objects), `SNOWFLAKE.CORTEX_USER`, Cortex agent USAGE, compute-pool +
  npm-EAI usage, app-service create/deploy, and (post-deploy) app-service USAGE — app usage, data CRUD,
  and semantic-model creation all included.
- **The users** get that role as their default role. Email notifications stay disabled.

## Troubleshooting
| Symptom | Fix |
|---|---|
| `snow app deploy` can't fetch npm | Ensure `01_prereqs.sql` ran (network rule + `ITSCORECARD_DEMO_NPM_ACCESS_INTEGRATION`); `snowflake.yml` `build_eai` must match `EAI`. |
| Deploy landed in `USER$<login>` / can't share | Complete Snowsight Account admin setup for App Runtime (or set account defaults), then re-deploy. |
| Users get "not authorized" at the URL | Run `07_grant_app_access.sql`; confirm each user has `ITSCORECARD_DEMO_USERS`. |
| Agent/chat errors | Confirm Cortex enabled + `claude-opus-4-8` available (or set `CORTEX_ENABLED_CROSS_REGION`); `06` grants `SNOWFLAKE.CORTEX_USER` + agent USAGE. |
| Web search returns nothing | Enable it in Snowsight (AI & ML » Agents » Settings » Web search). |
| Compute pool not found | Create a small pool and set `COMPUTE_POOL` in `config.env` (see `01_prereqs.sql`). |
