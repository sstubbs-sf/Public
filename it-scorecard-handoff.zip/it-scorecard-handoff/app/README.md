This app deploys as part of the IT Operations Scorecard bundle.

**To build and deploy, follow `../README.md`** (the deployment runbook), not this file.
Do not deploy this to Vercel — it runs on Snowflake App Runtime via `snow app deploy`.

For local development only: `npm ci`, set `.env` with `SNOWFLAKE_ACCOUNT_URL` + `SF_PAT`,
then `npm run build && node .next/standalone/server.js`.
