import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  output: 'standalone',
  // snowflake-sdk is a native/dynamic-require driver; keep it out of the webpack
  // bundle so PUT-to-stage works in the standalone SPCS build.
  serverExternalPackages: ['snowflake-sdk'],
  webpack: (config) => {
    // vega-canvas optionally requires the native `canvas` module for server-side
    // rendering; charts render client-side only, so stub it to silence the
    // "Can't resolve 'canvas'" build warning.
    config.resolve.alias = { ...config.resolve.alias, canvas: false };
    return config;
  },
};

export default nextConfig;
