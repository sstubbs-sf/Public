'use client';

import { useMemo, useState } from 'react';
import { useInitiatives, useDeleteInitiative } from '@/hooks/use-initiatives';
import { useMetrics } from '@/hooks/use-metrics';
import { useComments } from '@/hooks/use-comments';
import { CommentThread } from '@/components/comments/CommentThread';
import { InitiativeEditor } from '@/components/initiatives/InitiativeEditor';
import { Header, TabNav } from '@/components/layout/Header';
import { Initiative } from '@/types';
import { statusOf } from '@/lib/utils';
import { useUIStore } from '@/stores/ui-store';
import { useRouter } from 'next/navigation';
import { ContextPinButton } from '@/components/chat/ContextPinButton';
import { initiativeToContextItem } from '@/lib/artifact-context';

const PILLAR_ICONS: Record<string, string> = {
  'Trusted Partner': '🛡️',
  'Top Quartile Performer': '🏆',
  'Best/ Preferred Place to Work': '🤝',
};

export default function InitiativesPage() {
  const { data: initiatives, isLoading, error } = useInitiatives();
  const [editorOpen, setEditorOpen] = useState(false);
  const [editorMode, setEditorMode] = useState<'create' | 'edit'>('create');
  const [editTarget, setEditTarget] = useState<Initiative | null>(null);

  const knownPillars = useMemo(() => [...new Set((initiatives || []).map(i => i.pillar))], [initiatives]);
  const knownPriorities = useMemo(() => [...new Set((initiatives || []).map(i => i.priority))], [initiatives]);

  const openNew = () => { setEditorMode('create'); setEditTarget(null); setEditorOpen(true); };
  const openEdit = (item: Initiative) => { setEditorMode('edit'); setEditTarget(item); setEditorOpen(true); };

  if (isLoading) {
    return (<><Header /><TabNav /><main><div style={{ color: 'var(--muted)' }}>Loading initiatives...</div></main></>);
  }
  if (error || !initiatives) {
    return (<><Header /><TabNav /><main><div style={{ color: 'var(--red)' }}>Failed to load initiatives.</div></main></>);
  }

  const pillars = [...new Set(initiatives.map(i => i.pillar))];

  return (
    <>
      <Header />
      <TabNav />
      <main>
        <div className="init-toolbar">
          <div className="section-label" style={{ margin: 0 }}>Strategic Initiatives — by pillar</div>
          <button className="init-new-btn" onClick={openNew}>+ New Initiative</button>
        </div>
        {pillars.length === 0 ? (
          <div className="sc-empty">
            No initiatives yet. <button className="sc-empty-clear" onClick={openNew}>Add the first one</button>
          </div>
        ) : (
          pillars.map((pillar, pi) => (
            <PillarAccordion
              key={pillar}
              pillar={pillar}
              items={initiatives.filter(i => i.pillar === pillar)}
              defaultOpen={pi === 0}
              onEdit={openEdit}
            />
          ))
        )}
      </main>

      <InitiativeEditor
        open={editorOpen}
        mode={editorMode}
        initiative={editTarget}
        knownPillars={knownPillars}
        knownPriorities={knownPriorities}
        onClose={() => setEditorOpen(false)}
      />
    </>
  );
}

function PillarAccordion({ pillar, items, defaultOpen, onEdit }: { pillar: string; items: Initiative[]; defaultOpen: boolean; onEdit: (i: Initiative) => void }) {
  const [collapsed, setCollapsed] = useState(!defaultOpen);
  const priorities = [...new Set(items.map(i => i.priority))];

  return (
    <div className={`pillar${collapsed ? ' collapsed' : ''}`}>
      <div className="pillar-hdr" onClick={() => setCollapsed(!collapsed)}>
        <div className="pillar-icon">{PILLAR_ICONS[pillar] || '★'}</div>
        <div>
          <div className="pillar-title">{pillar}</div>
          <div className="pillar-count">{items.length} initiatives · {priorities.length} priorities</div>
        </div>
        <div className="pillar-chevron">▾</div>
      </div>
      <div className="pillar-body">
        {priorities.map(pr => (
          <div key={pr} className="priority-group">
            <div className="priority-title">{pr}</div>
            {items.filter(i => i.priority === pr).map(item => (
              <InitiativeCard key={item.initiativeId} item={item} onEdit={onEdit} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function InitiativeCard({ item, onEdit }: { item: Initiative; onEdit: (i: Initiative) => void }) {
  const { data: metrics } = useMetrics();
  const { openDrawer } = useUIStore();
  const router = useRouter();
  const deleteInit = useDeleteInitiative();

  // Real linked KPIs from the join table (preserve stored id order).
  const byId = new Map((metrics || []).map(m => [m.metricId, m]));
  const allLinked = item.linkedMetricIds.map(id => byId.get(id)).filter(Boolean) as NonNullable<ReturnType<typeof byId.get>>[];
  const linkedMetrics = allLinked.slice(0, 2);
  const moreCount = allLinked.length - linkedMetrics.length;

  const handleKpiClick = (metricId: number) => {
    router.push('/scorecard');
    setTimeout(() => openDrawer(metricId), 100);
  };

  const handleDelete = () => {
    if (confirm(`Delete this initiative?\n\n"${item.activity}"\n\nThis also removes its KPI links and cannot be undone.`)) {
      deleteInit.mutate(item.initiativeId);
    }
  };

  return (
    <div className="init-card">
      <div>
        <div className="ic-activity-hdr">
          <span className="ic-label">Activity</span>
          <ContextPinButton item={initiativeToContextItem(item)} size={15} />
        </div>
        <div className="ic-text">{item.activity}</div>
      </div>
      <div>
        <div className="ic-label">Measurable Outcome</div>
        <div className="ic-text">{item.measurableOutcome}</div>
        {/* Linked KPI chips */}
        {allLinked.length > 0 ? (
          <div style={{ marginTop: '8px' }}>
            <span className="ic-label">Linked KPIs</span>
            {linkedMetrics.map(m => {
              const st = statusOf(m);
              return (
                <span
                  key={m.metricId}
                  className="kpi-ref-chip"
                  onClick={(e) => { e.stopPropagation(); handleKpiClick(m.metricId); }}
                >
                  {m.name.length > 25 ? m.name.substring(0, 25) + '…' : m.name}
                  <span className={`kpi-ref-dot ${st}`} />
                </span>
              );
            })}
            {moreCount > 0 && (
              <span
                className="kpi-ref-chip kpi-ref-more"
                onClick={(e) => { e.stopPropagation(); onEdit(item); }}
                title="Manage linked KPIs"
              >
                +{moreCount} more
              </span>
            )}
          </div>
        ) : (
          <div style={{ marginTop: '8px' }}>
            <span
              className="kpi-ref-chip kpi-ref-more"
              onClick={(e) => { e.stopPropagation(); onEdit(item); }}
              title="Link KPIs to this initiative"
            >
              + Link KPIs
            </span>
          </div>
        )}
      </div>
      <div className="init-owner">
        <div className="ic-label">Owner</div>
        <span className="owner-chip">{item.owner || '—'}</span>
        {item.partner && (
          <><br /><span className="partner-chip">{item.partner}</span></>
        )}
        <div className="ic-actions">
          <button className="ic-act-btn" onClick={(e) => { e.stopPropagation(); onEdit(item); }} title="Edit initiative">✎ Edit</button>
          <button className="ic-act-btn danger" onClick={(e) => { e.stopPropagation(); handleDelete(); }} disabled={deleteInit.isPending} title="Delete initiative">🗑</button>
        </div>
      </div>
      {/* Initiative comments row */}
      <InitiativeCommentRow initiativeId={item.initiativeId} owner={item.owner} activity={item.activity} />
    </div>
  );
}

function InitiativeCommentRow({ initiativeId, owner, activity }: { initiativeId: number; owner: string; activity: string }) {
  const [open, setOpen] = useState(false);
  const { data: comments } = useComments('initiative', initiativeId);
  const count = comments?.length || 0;

  return (
    <div style={{ gridColumn: '1 / -1', marginTop: '8px', borderTop: '1px solid var(--border)', paddingTop: '8px' }}>
      <span
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', cursor: 'pointer', fontSize: '12px', color: count > 0 ? 'var(--green)' : 'var(--muted)', border: `1px solid ${count > 0 ? 'var(--green)' : 'var(--border)'}`, borderRadius: '12px', padding: '2px 8px' }}
      >
        <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" /></svg>
        {count || '+'}
      </span>

      {open && (
        <div style={{ marginTop: '10px' }}>
          <CommentThread
            entityType="initiative"
            entityId={initiativeId}
            notify={{ entityName: activity, owner, section: 'Strategic Initiatives' }}
            placeholder="Add a comment about this initiative..."
            emptyText="No comments yet."
          />
        </div>
      )}
    </div>
  );
}
