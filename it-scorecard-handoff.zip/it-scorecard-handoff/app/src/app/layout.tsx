import type { Metadata } from 'next';
import './globals.css';
import { Providers } from './providers';
import { GlobalChat } from '@/components/chat/GlobalChat';
import { MetricDrawer } from '@/components/drawer/MetricDrawer';
import { AppShell } from '@/components/layout/AppShell';

export const metadata: Metadata = {
  title: 'IT Operations Scorecard',
  description: 'IT Operations Scorecard — performance metrics and strategic initiatives',
};

// Set the brand attribute + title before first paint to avoid a flash.
const brandInitScript = `(function(){try{document.documentElement.dataset.brand='solventum';document.title='Solventum IT Scorecard';}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: brandInitScript }} />
      </head>
      <body>
        <Providers>
          <AppShell>{children}</AppShell>
        </Providers>
      </body>
    </html>
  );
}
