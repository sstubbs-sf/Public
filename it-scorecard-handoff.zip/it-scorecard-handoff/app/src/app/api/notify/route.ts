import { querySnowflake } from '@/lib/snowflake';
import { NotifySchema } from '@/lib/schemas';
import { escapeHtml } from '@/lib/utils';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = NotifySchema.safeParse(body);
    if (!parsed.success) {
      return Response.json({ error: parsed.error.flatten(), sent: false }, { status: 400 });
    }

    const { metricName, commentText, commenter, ownerEmail, ownerName, month, section, brandName } = parsed.data;
    const appUrl = process.env.APP_URL || 'http://localhost:3000';
    const brandLabel = brandName ? `${brandName} IT Scorecard` : 'IT Operations Scorecard';

    const subject = `Action Required: New comment on "${escapeHtml(metricName)}"`;
    const htmlBody = buildEmailHtml({
      metricName: escapeHtml(metricName),
      commentText: escapeHtml(commentText),
      commenter: escapeHtml(commenter),
      ownerName: escapeHtml(ownerName),
      month: month ? escapeHtml(month) : undefined,
      section: section ? escapeHtml(section) : undefined,
      appUrl,
      brandLabel: escapeHtml(brandLabel),
    });

    await querySnowflake(
      `CALL SYSTEM$SEND_EMAIL(?, ?, ?, ?, 'text/html')`,
      {
        '1': { type: 'TEXT', value: 'scorecard_email_int' },
        '2': { type: 'TEXT', value: ownerEmail },
        '3': { type: 'TEXT', value: subject },
        '4': { type: 'TEXT', value: htmlBody },
      }
    );

    return Response.json({ sent: true });
  } catch (e) {
    console.error('Notify API error:', e);
    return Response.json({ error: 'Failed to send notification', sent: false }, { status: 500 });
  }
}

interface EmailParams {
  metricName: string;
  commentText: string;
  commenter: string;
  ownerName: string;
  month?: string;
  section?: string;
  appUrl: string;
  brandLabel: string;
}

function buildEmailHtml(p: EmailParams): string {
  const date = new Date().toLocaleDateString('en-US', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });

  return `<div style="font-family:Arial,sans-serif;max-width:620px;margin:0 auto;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden">
  <div style="background:#166534;padding:16px 24px;color:#fff">
    <h2 style="margin:0;font-size:18px">${p.brandLabel}</h2>
    <p style="margin:4px 0 0;font-size:13px;opacity:0.85">New comment requires your attention</p>
  </div>
  <div style="padding:24px">
    <table style="font-size:14px;border-collapse:collapse;width:100%;margin-bottom:16px">
      <tr><td style="padding:6px 12px 6px 0;font-weight:bold;color:#555;white-space:nowrap">Metric / Item:</td><td style="padding:6px 0">${p.metricName || 'N/A'}</td></tr>
      ${p.section ? `<tr><td style="padding:6px 12px 6px 0;font-weight:bold;color:#555;white-space:nowrap">Section:</td><td style="padding:6px 0">${p.section}</td></tr>` : ''}
      ${p.month ? `<tr><td style="padding:6px 12px 6px 0;font-weight:bold;color:#555;white-space:nowrap">Month:</td><td style="padding:6px 0">${p.month}</td></tr>` : ''}
      <tr><td style="padding:6px 12px 6px 0;font-weight:bold;color:#555;white-space:nowrap">Assigned Owner:</td><td style="padding:6px 0">${p.ownerName || 'N/A'}</td></tr>
      <tr><td style="padding:6px 12px 6px 0;font-weight:bold;color:#555;white-space:nowrap">Comment by:</td><td style="padding:6px 0">${p.commenter || 'Anonymous'}</td></tr>
      <tr><td style="padding:6px 12px 6px 0;font-weight:bold;color:#555;white-space:nowrap">Date:</td><td style="padding:6px 0">${date}</td></tr>
    </table>
    <div style="border-left:4px solid #22c55e;padding:12px 16px;margin:16px 0;background:#f0fdf4;border-radius:0 6px 6px 0">
      <p style="margin:0 0 4px;font-size:11px;font-weight:bold;color:#555;text-transform:uppercase">Comment</p>
      <p style="margin:0;font-size:14px;color:#1f2937;line-height:1.5">${p.commentText}</p>
    </div>
    <div style="margin-top:24px;text-align:center">
      <a href="${p.appUrl}" style="display:inline-block;background:#166534;color:#fff;padding:10px 24px;border-radius:6px;text-decoration:none;font-size:14px;font-weight:600">View in Scorecard</a>
    </div>
    <p style="color:#9ca3af;font-size:11px;margin-top:20px;text-align:center">This notification was sent from the ${p.brandLabel}.</p>
  </div>
</div>`;
}
