import { AgentMessageSchema } from '@/lib/schemas';
import { getAccountUrl, getAuth, getCallerToken } from '@/lib/cortex-threads';
import { AGENT_PATH } from '@/lib/config';

// Streams the agent response to the client as NDJSON lines:
//   {"type":"text","delta":"…"}         - incremental answer text
//   {"type":"chart","spec":{…}}         - a Vega-Lite chart spec
//   {"type":"meta","threadId":n,"assistantMessageId":n}
//   {"type":"error","message":"…"}
//   {"type":"done"}
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = AgentMessageSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const { message, context, threadId, parentMessageId } = parsed.data;
  const fullMessage = context ? `${context}\n\n${message}` : message;

  const accountUrl = getAccountUrl();
  const { token, tokenType } = getAuth(getCallerToken(req));
  if (!token) {
    return Response.json({ error: 'No auth token available' }, { status: 401 });
  }

  // When a thread is provided, Snowflake maintains context server-side and we send
  // only the current user message plus the thread pointers. Otherwise, a stateless turn.
  const runBody: Record<string, unknown> = {
    messages: [{ role: 'user', content: [{ type: 'text', text: fullMessage }] }],
  };
  if (typeof threadId === 'number') {
    runBody.thread_id = threadId;
    runBody.parent_message_id = typeof parentMessageId === 'number' ? parentMessageId : 0;
  }

  let agentResp: Response;
  try {
    agentResp = await fetch(
      `${accountUrl}/api/v2/${AGENT_PATH}:run`,
      {
        method: 'POST',
        signal: AbortSignal.timeout(120000),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'text/event-stream',
          'Authorization': `Bearer ${token}`,
          'X-Snowflake-Authorization-Token-Type': tokenType,
        },
        body: JSON.stringify(runBody),
      }
    );
  } catch (e) {
    console.error('Agent fetch failed:', e);
    return Response.json({ error: 'Agent request failed' }, { status: 502 });
  }

  if (!agentResp.ok || !agentResp.body) {
    const errBody = await agentResp.text().catch(() => '');
    return Response.json(
      { error: `Agent returned ${agentResp.status}: ${errBody.substring(0, 200)}` },
      { status: agentResp.status || 502 }
    );
  }

  const upstream = agentResp.body;
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  const stream = new ReadableStream({
    async start(controller) {
      const emit = (obj: unknown) => controller.enqueue(encoder.encode(JSON.stringify(obj) + '\n'));

      let buffer = '';
      let currentEvent = '';
      let respThreadId: number | undefined;
      let assistantMessageId: number | undefined;
      let gotText = false;

      // Parse one complete SSE record ("event:" + "data:" lines) and emit NDJSON.
      const handleRecord = (record: string) => {
        for (const line of record.split('\n')) {
          if (line.startsWith('event:')) {
            currentEvent = line.slice(6).trim();
          } else if (line.startsWith('data:')) {
            const raw = line.slice(5).trim();
            if (!raw || raw === '[DONE]') continue;
            let data: Record<string, unknown>;
            try {
              data = JSON.parse(raw);
            } catch {
              continue;
            }
            if (currentEvent === 'response.text.delta') {
              const t = data.text;
              if (typeof t === 'string' && t) {
                gotText = true;
                emit({ type: 'text', delta: t });
              }
            } else if (currentEvent === 'response.chart') {
              const spec = data.chart_spec;
              if (spec) emit({ type: 'chart', spec });
            } else if (currentEvent === 'metadata') {
              const meta = (data.metadata as Record<string, unknown>) || data;
              if (meta?.role === 'assistant' && typeof meta.message_id === 'number') {
                assistantMessageId = meta.message_id as number;
              }
            } else if (currentEvent === 'response') {
              const meta = data.metadata as Record<string, unknown> | undefined;
              if (meta) {
                if (typeof meta.assistant_message_id === 'number') {
                  assistantMessageId = meta.assistant_message_id as number;
                }
                if (typeof meta.thread_id === 'number') respThreadId = meta.thread_id as number;
              }
            }
          }
        }
      };

      try {
        const reader = upstream.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          // SSE records are separated by a blank line.
          let sep: number;
          while ((sep = buffer.indexOf('\n\n')) !== -1) {
            const record = buffer.slice(0, sep);
            buffer = buffer.slice(sep + 2);
            handleRecord(record);
          }
        }
        if (buffer.trim()) handleRecord(buffer);

        if (!gotText) emit({ type: 'text', delta: 'No response from agent.' });
        emit({ type: 'meta', threadId: respThreadId ?? threadId, assistantMessageId });
        emit({ type: 'done' });
      } catch (e) {
        console.error('Agent stream error:', e);
        emit({ type: 'error', message: 'Agent stream failed' });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'application/x-ndjson; charset=utf-8',
      'Cache-Control': 'no-store, no-transform',
      'X-Accel-Buffering': 'no',
      Connection: 'keep-alive',
    },
  });
}
