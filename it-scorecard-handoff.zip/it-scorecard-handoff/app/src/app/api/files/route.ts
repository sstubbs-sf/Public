import { NextRequest } from 'next/server';
import { writeFile, unlink, mkdtemp } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { randomUUID } from 'crypto';
import { classify } from '@/lib/file-types';
import { extractBinaryFile } from '@/lib/file-extract';

export const runtime = 'nodejs';
export const maxDuration = 120;

const MAX_BYTES = 25 * 1024 * 1024; // 25 MB

// Keep only safe path characters; collapse everything else to underscore.
function safeName(name: string): string {
  const base = name.replace(/^.*[\\/]/, '');
  return base.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 128) || 'upload';
}

export async function POST(req: NextRequest) {
  let tmpDir: string | null = null;
  let localPath: string | null = null;
  try {
    const form = await req.formData();
    const file = form.get('file');
    if (!(file instanceof File)) {
      return Response.json({ error: 'No file provided' }, { status: 400 });
    }

    const cls = classify(file.name);
    if (!cls.supported) {
      return Response.json({ error: cls.reason }, { status: 415 });
    }
    // Text + spreadsheet are handled entirely client-side; this route is only for
    // binary files that must be staged for Cortex.
    if (cls.category === 'text' || cls.category === 'spreadsheet') {
      return Response.json(
        { error: 'Text and spreadsheet files are processed client-side.' },
        { status: 400 }
      );
    }

    if (file.size > MAX_BYTES) {
      return Response.json(
        { error: `File exceeds ${Math.round(MAX_BYTES / 1024 / 1024)} MB limit.` },
        { status: 413 }
      );
    }
    if (file.size === 0) {
      return Response.json({ error: 'File is empty.' }, { status: 400 });
    }

    const threadIdRaw = form.get('threadId');
    const threadId =
      typeof threadIdRaw === 'string' && /^\d+$/.test(threadIdRaw) ? threadIdRaw : 'anon';
    const subdir = `${threadId}/${randomUUID()}`;
    const basename = safeName(file.name);

    // Write to a private temp file, then PUT + extract on one driver connection.
    tmpDir = await mkdtemp(join(tmpdir(), 'chatupload-'));
    localPath = join(tmpDir, basename);
    const bytes = Buffer.from(await file.arrayBuffer());
    await writeFile(localPath, bytes);

    const extractedText = await extractBinaryFile(
      cls.category as 'document' | 'image' | 'audio',
      localPath,
      subdir,
      basename
    );

    if (!extractedText) {
      return Response.json(
        { error: 'No content could be extracted from this file.' },
        { status: 422 }
      );
    }

    return Response.json({
      name: file.name,
      category: cls.category,
      sizeBytes: file.size,
      extractedText,
    });
  } catch (e) {
    console.error('File upload/extract error:', e);
    const msg = e instanceof Error ? e.message : 'File processing failed';
    return Response.json({ error: msg.substring(0, 300) }, { status: 500 });
  } finally {
    if (localPath) await unlink(localPath).catch(() => {});
  }
}
