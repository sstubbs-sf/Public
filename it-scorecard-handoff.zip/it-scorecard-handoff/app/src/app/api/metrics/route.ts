import { querySnowflake, getCallerToken, getCurrentUser } from '@/lib/snowflake';
import { MetricWriteSchema } from '@/lib/schemas';
import { Metric, MonthData, Status } from '@/types';
import { computeStatus } from '@/lib/utils';
import { OBJ } from '@/lib/config';
import { NextRequest } from 'next/server';

interface MetricRow {
  METRIC_ID: string;
  METRIC_NAME: string;
  SECTION: string;
  TARGET_DESCRIPTION: string;
  OWNER: string;
  DIRECTION: string;
  IS_PERCENT: string;
}

interface MonthlyRow {
  METRIC_ID: string;
  MONTH_INDEX: string;
  MONTH_NAME: string;
  MONTH_YEAR: string;
  PLAN_VALUE: string | null;
  ACTUAL_VALUE: string | null;
  STATUS: string | null;
}

const T_MET = OBJ.METRICS;
const T_MON = OBJ.METRIC_MONTHLY_DATA;
const T_LINK = OBJ.INITIATIVE_KPI_LINKS;
const T_CMT = OBJ.COMMENTS;
const SEQ = OBJ.METRIC_ID_SEQ;

type WriteOpts = { callersRights: true; callerToken: string | undefined };

interface CanonMonth { index: number; name: string; year: string; }

async function getCanonicalMonths(opts: WriteOpts): Promise<CanonMonth[]> {
  const rows = await querySnowflake<{ MONTH_INDEX: string; MONTH_NAME: string; MONTH_YEAR: string }[]>(
    `SELECT DISTINCT MONTH_INDEX, MONTH_NAME, MONTH_YEAR FROM ${T_MON} ORDER BY MONTH_INDEX`,
    undefined,
    opts
  );
  return rows.map(r => ({ index: Number(r.MONTH_INDEX), name: r.MONTH_NAME, year: r.MONTH_YEAR }));
}

// Replace the full monthly row set for a metric: delete all, then insert one row per
// canonical month with plan/actual from the payload (keyed by monthIndex) and a
// server-computed STATUS. One bulk INSERT via FLATTEN over a JSON array of rows.
async function writeMonthly(
  metricId: number,
  monthly: { monthIndex: number; plan: number | null; actual: number | null }[],
  direction: 'high' | 'low',
  opts: WriteOpts
) {
  const months = await getCanonicalMonths(opts);
  const byIndex = new Map(monthly.map(m => [m.monthIndex, m]));

  await querySnowflake(`DELETE FROM ${T_MON} WHERE METRIC_ID = ?`, { '1': { type: 'FIXED', value: String(metricId) } }, opts);

  const rows = months.map(mo => {
    const v = byIndex.get(mo.index);
    const plan = v && v.plan !== undefined ? v.plan : null;
    const actual = v && v.actual !== undefined ? v.actual : null;
    return { mi: mo.index, mn: mo.name, my: mo.year, pv: plan, av: actual, st: computeStatus(actual, plan, direction) };
  });
  if (rows.length === 0) return;

  await querySnowflake(
    `INSERT INTO ${T_MON} (METRIC_ID, MONTH_INDEX, MONTH_NAME, MONTH_YEAR, PLAN_VALUE, ACTUAL_VALUE, STATUS)
     SELECT ?, f.value:mi::NUMBER, f.value:mn::STRING, f.value:my::STRING, f.value:pv::FLOAT, f.value:av::FLOAT, f.value:st::STRING
     FROM TABLE(FLATTEN(input => PARSE_JSON(?))) f`,
    {
      '1': { type: 'FIXED', value: String(metricId) },
      '2': { type: 'TEXT', value: JSON.stringify(rows) },
    },
    opts
  );
}

export async function GET(req: NextRequest) {
  try {
    const opts: WriteOpts = { callersRights: true, callerToken: getCallerToken(req) };
    const [metricsRaw, monthlyRaw] = await Promise.all([
      querySnowflake<MetricRow[]>(
        `SELECT METRIC_ID, METRIC_NAME, SECTION, TARGET_DESCRIPTION, OWNER, DIRECTION, IS_PERCENT FROM ${T_MET} ORDER BY METRIC_ID`,
        undefined,
        opts
      ),
      querySnowflake<MonthlyRow[]>(`SELECT * FROM ${T_MON} ORDER BY METRIC_ID, MONTH_INDEX`, undefined, opts),
    ]);

    const monthlyByMetric = new Map<number, MonthData[]>();
    for (const row of monthlyRaw) {
      const id = Number(row.METRIC_ID);
      if (!monthlyByMetric.has(id)) monthlyByMetric.set(id, []);
      monthlyByMetric.get(id)!.push({
        monthIndex: Number(row.MONTH_INDEX),
        monthName: row.MONTH_NAME,
        monthYear: row.MONTH_YEAR,
        plan: row.PLAN_VALUE !== null ? Number(row.PLAN_VALUE) : null,
        actual: row.ACTUAL_VALUE !== null ? Number(row.ACTUAL_VALUE) : null,
        status: (row.STATUS || 'gray') as Status,
      });
    }

    const metrics: Metric[] = metricsRaw.map((row) => ({
      metricId: Number(row.METRIC_ID),
      name: row.METRIC_NAME,
      section: row.SECTION,
      targetDescription: row.TARGET_DESCRIPTION,
      owner: row.OWNER,
      direction: (row.DIRECTION || 'high') as 'high' | 'low',
      isPercent: row.IS_PERCENT === 'true' || row.IS_PERCENT === '1',
      monthly: monthlyByMetric.get(Number(row.METRIC_ID)) || [],
    }));

    return Response.json(metrics);
  } catch (e) {
    console.error('Metrics GET error:', e);
    return Response.json({ error: 'Failed to fetch metrics' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const parsed = MetricWriteSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
    const { name, section, targetDescription, owner, direction, isPercent, monthly } = parsed.data;
    const { username } = await getCurrentUser(req);
    const opts: WriteOpts = { callersRights: true, callerToken: getCallerToken(req) };

    const idRows = await querySnowflake<{ ID: string }[]>(`SELECT ${SEQ}.NEXTVAL AS ID`, undefined, opts);
    const newId = Number(idRows[0]?.ID);
    if (!Number.isFinite(newId)) throw new Error('Failed to allocate metric id');

    await querySnowflake(
      `INSERT INTO ${T_MET} (METRIC_ID, METRIC_NAME, SECTION, TARGET_DESCRIPTION, OWNER, DIRECTION, IS_PERCENT, CREATED_BY, UPDATED_BY, UPDATED_AT)
       SELECT ?, ?, ?, ?, ?, ?, TO_BOOLEAN(?), ?, ?, CURRENT_TIMESTAMP()`,
      {
        '1': { type: 'FIXED', value: String(newId) },
        '2': { type: 'TEXT', value: name },
        '3': { type: 'TEXT', value: section },
        '4': { type: 'TEXT', value: targetDescription },
        '5': { type: 'TEXT', value: owner },
        '6': { type: 'TEXT', value: direction },
        '7': { type: 'TEXT', value: isPercent ? 'true' : 'false' },
        '8': { type: 'TEXT', value: username },
        '9': { type: 'TEXT', value: username },
      },
      opts
    );

    await writeMonthly(newId, monthly, direction, opts);

    return Response.json({ success: true, metricId: newId }, { status: 201 });
  } catch (e) {
    console.error('Metrics POST error:', e);
    return Response.json({ error: 'Failed to create metric' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get('id');
    if (!id || !/^\d+$/.test(id)) return Response.json({ error: 'Invalid id' }, { status: 400 });
    const parsed = MetricWriteSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
    const { name, section, targetDescription, owner, direction, isPercent, monthly } = parsed.data;
    const { username } = await getCurrentUser(req);
    const opts: WriteOpts = { callersRights: true, callerToken: getCallerToken(req) };

    const exists = await querySnowflake<{ METRIC_ID: string }[]>(
      `SELECT METRIC_ID FROM ${T_MET} WHERE METRIC_ID = ?`,
      { '1': { type: 'FIXED', value: id } },
      opts
    );
    if (exists.length === 0) return Response.json({ error: 'Metric not found' }, { status: 404 });

    await querySnowflake(
      `UPDATE ${T_MET}
          SET METRIC_NAME = ?, SECTION = ?, TARGET_DESCRIPTION = ?, OWNER = ?, DIRECTION = ?, IS_PERCENT = TO_BOOLEAN(?),
              UPDATED_BY = ?, UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE METRIC_ID = ?`,
      {
        '1': { type: 'TEXT', value: name },
        '2': { type: 'TEXT', value: section },
        '3': { type: 'TEXT', value: targetDescription },
        '4': { type: 'TEXT', value: owner },
        '5': { type: 'TEXT', value: direction },
        '6': { type: 'TEXT', value: isPercent ? 'true' : 'false' },
        '7': { type: 'TEXT', value: username },
        '8': { type: 'FIXED', value: id },
      },
      opts
    );

    await writeMonthly(Number(id), monthly, direction, opts);

    return Response.json({ success: true, metricId: Number(id) }, { status: 200 });
  } catch (e) {
    console.error('Metrics PATCH error:', e);
    return Response.json({ error: 'Failed to update metric' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get('id');
    if (!id || !/^\d+$/.test(id)) return Response.json({ error: 'Invalid id' }, { status: 400 });
    const opts: WriteOpts = { callersRights: true, callerToken: getCallerToken(req) };

    const exists = await querySnowflake<{ METRIC_ID: string }[]>(
      `SELECT METRIC_ID FROM ${T_MET} WHERE METRIC_ID = ?`,
      { '1': { type: 'FIXED', value: id } },
      opts
    );
    if (exists.length === 0) return Response.json({ error: 'Metric not found' }, { status: 404 });

    // Cascade: monthly rows, initiative KPI links, and comments referencing this metric.
    await querySnowflake(`DELETE FROM ${T_MON} WHERE METRIC_ID = ?`, { '1': { type: 'FIXED', value: id } }, opts);
    await querySnowflake(`DELETE FROM ${T_LINK} WHERE METRIC_ID = ?`, { '1': { type: 'FIXED', value: id } }, opts);
    await querySnowflake(
      `DELETE FROM ${T_CMT} WHERE ENTITY_ID = ? AND ENTITY_TYPE IN ('metric', 'metric_month')`,
      { '1': { type: 'FIXED', value: id } },
      opts
    );
    await querySnowflake(`DELETE FROM ${T_MET} WHERE METRIC_ID = ?`, { '1': { type: 'FIXED', value: id } }, opts);

    return Response.json({ success: true }, { status: 200 });
  } catch (e) {
    console.error('Metrics DELETE error:', e);
    return Response.json({ error: 'Failed to delete metric' }, { status: 500 });
  }
}
