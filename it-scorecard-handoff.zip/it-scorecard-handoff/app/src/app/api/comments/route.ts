import { querySnowflake, getCallerToken, getCurrentUser, getCurrentUserLogin } from '@/lib/snowflake';
import { CommentCreateSchema } from '@/lib/schemas';
import { Comment } from '@/types';
import { OBJ } from '@/lib/config';
import { NextRequest } from 'next/server';

interface CommentRow {
  COMMENT_ID: string;
  ENTITY_TYPE: string;
  ENTITY_ID: string;
  MONTH_INDEX: string | null;
  COMMENT_TEXT: string;
  COMMENTER: string;
  COMMENTER_USERNAME: string | null;
  CREATED_AT: string;
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;
    const entityType = searchParams.get('entityType');
    const entityId = searchParams.get('entityId');

    let sql = `SELECT COMMENT_ID, ENTITY_TYPE, ENTITY_ID, MONTH_INDEX, COMMENT_TEXT, COMMENTER, COMMENTER_USERNAME, CREATED_AT FROM ${OBJ.COMMENTS}`;
    const bindings: Record<string, { type: string; value: string }> = {};
    const conditions: string[] = [];

    if (entityType) {
      conditions.push('ENTITY_TYPE = ?');
      bindings[String(Object.keys(bindings).length + 1)] = { type: 'TEXT', value: entityType };
    }
    if (entityId) {
      conditions.push('ENTITY_ID = ?');
      bindings[String(Object.keys(bindings).length + 1)] = { type: 'FIXED', value: entityId };
    }

    if (conditions.length > 0) {
      sql += ' WHERE ' + conditions.join(' AND ');
    }
    sql += ' ORDER BY CREATED_AT DESC';

    const rows = await querySnowflake<CommentRow[]>(
      sql,
      Object.keys(bindings).length > 0 ? bindings : undefined,
      { callersRights: true, callerToken: getCallerToken(req) }
    );

    const comments: Comment[] = rows.map((row) => ({
      commentId: Number(row.COMMENT_ID),
      entityType: row.ENTITY_TYPE as Comment['entityType'],
      entityId: Number(row.ENTITY_ID),
      monthIndex: row.MONTH_INDEX !== null ? Number(row.MONTH_INDEX) : null,
      commentText: row.COMMENT_TEXT,
      commenter: row.COMMENTER,
      commenterUsername: row.COMMENTER_USERNAME,
      createdAt: row.CREATED_AT,
    }));

    return Response.json(comments);
  } catch (e) {
    console.error('Comments GET error:', e);
    return Response.json({ error: 'Failed to fetch comments' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = CommentCreateSchema.safeParse(body);
    if (!parsed.success) {
      return Response.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const { entityType, entityId, monthIndex, text } = parsed.data;

    // Identity is captured server-side from the authenticated accessing user —
    // NEVER trusted from the client. COMMENTER = friendly name (display),
    // COMMENTER_USERNAME = stable login (used for delete-own ownership checks).
    const { username, displayName } = await getCurrentUser(req);

    const hasMonth = monthIndex !== null && monthIndex !== undefined;
    const sql = hasMonth
      ? `INSERT INTO ${OBJ.COMMENTS} (ENTITY_TYPE, ENTITY_ID, MONTH_INDEX, COMMENT_TEXT, COMMENTER, COMMENTER_USERNAME)
         VALUES (?, ?, ?, ?, ?, ?)`
      : `INSERT INTO ${OBJ.COMMENTS} (ENTITY_TYPE, ENTITY_ID, COMMENT_TEXT, COMMENTER, COMMENTER_USERNAME)
         VALUES (?, ?, ?, ?, ?)`;

    const bindings: Record<string, { type: string; value: string }> = hasMonth
      ? {
          '1': { type: 'TEXT', value: entityType },
          '2': { type: 'FIXED', value: String(entityId) },
          '3': { type: 'FIXED', value: String(monthIndex) },
          '4': { type: 'TEXT', value: text },
          '5': { type: 'TEXT', value: displayName },
          '6': { type: 'TEXT', value: username },
        }
      : {
          '1': { type: 'TEXT', value: entityType },
          '2': { type: 'FIXED', value: String(entityId) },
          '3': { type: 'TEXT', value: text },
          '4': { type: 'TEXT', value: displayName },
          '5': { type: 'TEXT', value: username },
        };

    await querySnowflake(sql, bindings, { callersRights: true, callerToken: getCallerToken(req) });

    return Response.json({ success: true, commenter: displayName, commenterUsername: username }, { status: 201 });
  } catch (e) {
    console.error('Comments POST error:', e);
    return Response.json({ error: 'Failed to create comment' }, { status: 500 });
  }
}

// Delete-own: a user may only delete a comment they authored. Ownership is
// checked against the stable COMMENTER_USERNAME (login), matched to the
// authenticated accessing user. Legacy rows (username NULL) are not deletable.
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;
    const commentId = searchParams.get('commentId');
    if (!commentId || !/^\d+$/.test(commentId)) {
      return Response.json({ error: 'Invalid commentId' }, { status: 400 });
    }

    const login = getCurrentUserLogin(req) ?? (await getCurrentUser(req)).username;
    if (!login || login === 'unknown') {
      return Response.json({ error: 'Not authenticated' }, { status: 401 });
    }

    // Verify ownership before deleting.
    const owner = await querySnowflake<{ COMMENTER_USERNAME: string | null }[]>(
      `SELECT COMMENTER_USERNAME FROM ${OBJ.COMMENTS} WHERE COMMENT_ID = ?`,
      { '1': { type: 'FIXED', value: commentId } },
      { callersRights: true, callerToken: getCallerToken(req) }
    );
    if (owner.length === 0) {
      return Response.json({ error: 'Comment not found' }, { status: 404 });
    }
    const ownerUser = owner[0].COMMENTER_USERNAME;
    if (!ownerUser || ownerUser.toUpperCase() !== login.toUpperCase()) {
      return Response.json({ error: 'You can only delete your own comments' }, { status: 403 });
    }

    await querySnowflake(
      `DELETE FROM ${OBJ.COMMENTS} WHERE COMMENT_ID = ? AND UPPER(COMMENTER_USERNAME) = UPPER(?)`,
      {
        '1': { type: 'FIXED', value: commentId },
        '2': { type: 'TEXT', value: login },
      },
      { callersRights: true, callerToken: getCallerToken(req) }
    );

    return Response.json({ success: true }, { status: 200 });
  } catch (e) {
    console.error('Comments DELETE error:', e);
    return Response.json({ error: 'Failed to delete comment' }, { status: 500 });
  }
}
