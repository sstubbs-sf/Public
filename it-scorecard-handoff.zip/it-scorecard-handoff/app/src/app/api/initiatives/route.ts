import { querySnowflake, getCallerToken, getCurrentUser } from '@/lib/snowflake';
import { InitiativeWriteSchema } from '@/lib/schemas';
import { Initiative } from '@/types';
import { OBJ } from '@/lib/config';
import { NextRequest } from 'next/server';

interface InitiativeRow {
  INITIATIVE_ID: string;
  PILLAR: string;
  PRIORITY: string;
  ACTIVITY: string;
  MEASURABLE_OUTCOME: string;
  OWNER: string;
  PARTNER: string;
}

interface LinkRow {
  INITIATIVE_ID: string;
  METRIC_ID: string;
}

const T_INIT = OBJ.INITIATIVES;
const T_LINK = OBJ.INITIATIVE_KPI_LINKS;
const SEQ = OBJ.INITIATIVE_ID_SEQ;

type Bindings = Record<string, { type: string; value: string }>;

// Replace the full set of KPI links for an initiative (delete-all then bulk insert).
async function replaceLinks(initiativeId: number, metricIds: number[], req: NextRequest) {
  const opts = { callersRights: true, callerToken: getCallerToken(req) };
  await querySnowflake(
    `DELETE FROM ${T_LINK} WHERE INITIATIVE_ID = ?`,
    { '1': { type: 'FIXED', value: String(initiativeId) } },
    opts
  );
  const unique = [...new Set(metricIds.filter(n => Number.isInteger(n)))];
  if (unique.length === 0) return;
  // Bulk insert a variable-length list via FLATTEN over a JSON array.
  await querySnowflake(
    `INSERT INTO ${T_LINK} (INITIATIVE_ID, METRIC_ID)
     SELECT ?, f.value::NUMBER
     FROM TABLE(FLATTEN(input => PARSE_JSON(?))) f`,
    {
      '1': { type: 'FIXED', value: String(initiativeId) },
      '2': { type: 'TEXT', value: JSON.stringify(unique) },
    },
    opts
  );
}

export async function GET(req: NextRequest) {
  try {
    const opts = { callersRights: true, callerToken: getCallerToken(req) };
    const [rows, links] = await Promise.all([
      querySnowflake<InitiativeRow[]>(
        `SELECT INITIATIVE_ID, PILLAR, PRIORITY, ACTIVITY, MEASURABLE_OUTCOME, OWNER, PARTNER
           FROM ${T_INIT} ORDER BY INITIATIVE_ID`,
        undefined,
        opts
      ),
      querySnowflake<LinkRow[]>(`SELECT INITIATIVE_ID, METRIC_ID FROM ${T_LINK}`, undefined, opts),
    ]);

    const linksByInit = new Map<number, number[]>();
    for (const l of links) {
      const id = Number(l.INITIATIVE_ID);
      if (!linksByInit.has(id)) linksByInit.set(id, []);
      linksByInit.get(id)!.push(Number(l.METRIC_ID));
    }

    const initiatives: Initiative[] = rows.map((row) => ({
      initiativeId: Number(row.INITIATIVE_ID),
      pillar: row.PILLAR,
      priority: row.PRIORITY,
      activity: row.ACTIVITY,
      measurableOutcome: row.MEASURABLE_OUTCOME,
      owner: row.OWNER,
      partner: row.PARTNER,
      linkedMetricIds: (linksByInit.get(Number(row.INITIATIVE_ID)) || []).sort((a, b) => a - b),
    }));

    return Response.json(initiatives);
  } catch (e) {
    console.error('Initiatives GET error:', e);
    return Response.json({ error: 'Failed to fetch initiatives' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const parsed = InitiativeWriteSchema.safeParse(await req.json());
    if (!parsed.success) {
      return Response.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const { pillar, priority, activity, measurableOutcome, owner, partner, linkedMetricIds } = parsed.data;
    const { username } = await getCurrentUser(req);
    const opts = { callersRights: true, callerToken: getCallerToken(req) };

    // Deterministic new id from the sequence (INITIATIVE_ID has no IDENTITY).
    const idRows = await querySnowflake<{ ID: string }[]>(`SELECT ${SEQ}.NEXTVAL AS ID`, undefined, opts);
    const newId = Number(idRows[0]?.ID);
    if (!Number.isFinite(newId)) throw new Error('Failed to allocate initiative id');

    const bindings: Bindings = {
      '1': { type: 'FIXED', value: String(newId) },
      '2': { type: 'TEXT', value: pillar },
      '3': { type: 'TEXT', value: priority },
      '4': { type: 'TEXT', value: activity },
      '5': { type: 'TEXT', value: measurableOutcome },
      '6': { type: 'TEXT', value: owner },
      '7': { type: 'TEXT', value: partner },
      '8': { type: 'TEXT', value: username },
    };
    await querySnowflake(
      `INSERT INTO ${T_INIT} (INITIATIVE_ID, PILLAR, PRIORITY, ACTIVITY, MEASURABLE_OUTCOME, OWNER, PARTNER, CREATED_BY, UPDATED_BY, UPDATED_AT)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP())`,
      { ...bindings, '9': { type: 'TEXT', value: username } },
      opts
    );

    await replaceLinks(newId, linkedMetricIds, req);

    return Response.json({ success: true, initiativeId: newId }, { status: 201 });
  } catch (e) {
    console.error('Initiatives POST error:', e);
    return Response.json({ error: 'Failed to create initiative' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get('id');
    if (!id || !/^\d+$/.test(id)) {
      return Response.json({ error: 'Invalid id' }, { status: 400 });
    }
    const parsed = InitiativeWriteSchema.safeParse(await req.json());
    if (!parsed.success) {
      return Response.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const { pillar, priority, activity, measurableOutcome, owner, partner, linkedMetricIds } = parsed.data;
    const { username } = await getCurrentUser(req);
    const opts = { callersRights: true, callerToken: getCallerToken(req) };

    const exists = await querySnowflake<{ INITIATIVE_ID: string }[]>(
      `SELECT INITIATIVE_ID FROM ${T_INIT} WHERE INITIATIVE_ID = ?`,
      { '1': { type: 'FIXED', value: id } },
      opts
    );
    if (exists.length === 0) {
      return Response.json({ error: 'Initiative not found' }, { status: 404 });
    }

    await querySnowflake(
      `UPDATE ${T_INIT}
          SET PILLAR = ?, PRIORITY = ?, ACTIVITY = ?, MEASURABLE_OUTCOME = ?, OWNER = ?, PARTNER = ?,
              UPDATED_BY = ?, UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE INITIATIVE_ID = ?`,
      {
        '1': { type: 'TEXT', value: pillar },
        '2': { type: 'TEXT', value: priority },
        '3': { type: 'TEXT', value: activity },
        '4': { type: 'TEXT', value: measurableOutcome },
        '5': { type: 'TEXT', value: owner },
        '6': { type: 'TEXT', value: partner },
        '7': { type: 'TEXT', value: username },
        '8': { type: 'FIXED', value: id },
      },
      opts
    );

    await replaceLinks(Number(id), linkedMetricIds, req);

    return Response.json({ success: true, initiativeId: Number(id) }, { status: 200 });
  } catch (e) {
    console.error('Initiatives PATCH error:', e);
    return Response.json({ error: 'Failed to update initiative' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const id = req.nextUrl.searchParams.get('id');
    if (!id || !/^\d+$/.test(id)) {
      return Response.json({ error: 'Invalid id' }, { status: 400 });
    }
    const opts = { callersRights: true, callerToken: getCallerToken(req) };

    const exists = await querySnowflake<{ INITIATIVE_ID: string }[]>(
      `SELECT INITIATIVE_ID FROM ${T_INIT} WHERE INITIATIVE_ID = ?`,
      { '1': { type: 'FIXED', value: id } },
      opts
    );
    if (exists.length === 0) {
      return Response.json({ error: 'Initiative not found' }, { status: 404 });
    }

    await querySnowflake(`DELETE FROM ${T_LINK} WHERE INITIATIVE_ID = ?`, { '1': { type: 'FIXED', value: id } }, opts);
    await querySnowflake(`DELETE FROM ${T_INIT} WHERE INITIATIVE_ID = ?`, { '1': { type: 'FIXED', value: id } }, opts);

    return Response.json({ success: true }, { status: 200 });
  } catch (e) {
    console.error('Initiatives DELETE error:', e);
    return Response.json({ error: 'Failed to delete initiative' }, { status: 500 });
  }
}
