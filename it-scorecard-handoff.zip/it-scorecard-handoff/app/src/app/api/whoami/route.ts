import { getCurrentUser } from '@/lib/snowflake';
import { NextRequest } from 'next/server';

// Returns the authenticated accessing user (login + friendly display name).
// Used by the client to show "Commenting as ..." and to enable delete-own.
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser(req);
    return Response.json(user);
  } catch (e) {
    console.error('whoami error:', e);
    return Response.json({ username: 'unknown', displayName: 'Unknown User' }, { status: 200 });
  }
}
