// SPCS readiness probe target. Hit directly by the platform (no ingress auth),
// so it must always return 200 without touching Snowflake.
export const dynamic = 'force-dynamic';

export function GET() {
  return new Response('ok', { status: 200 });
}
