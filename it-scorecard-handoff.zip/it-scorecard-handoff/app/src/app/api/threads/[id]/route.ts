import { describeThread, updateThread, deleteThread, getCallerToken } from '@/lib/cortex-threads';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const threadId = Number(id);
    if (!Number.isFinite(threadId)) {
      return Response.json({ error: 'Invalid thread id' }, { status: 400 });
    }
    const data = await describeThread(threadId, getCallerToken(_req));
    // Thread message_ids are not guaranteed chronological in this account — order by created_on
    const ordered = [...(data.messages || [])].sort(
      (a, b) => (a.created_on ?? 0) - (b.created_on ?? 0)
    );

    // message_payload is a JSON string; pull out the human-readable text blocks
    const extractText = (payload: string): string => {
      try {
        const parsed = JSON.parse(payload);
        const content = parsed?.content;
        if (Array.isArray(content)) {
          return content
            .filter((c: { type?: string; text?: string }) => c?.type === 'text' && c.text)
            .map((c: { text: string }) => c.text)
            .join('\n')
            .trim();
        }
        if (typeof parsed?.text === 'string') return parsed.text;
      } catch {
        return payload;
      }
      return '';
    };

    const messages = ordered
      .map((m) => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: extractText(m.message_payload),
        created_on: m.created_on,
        message_id: m.message_id,
      }))
      .filter((m) => m.content); // drop pure thinking/tool_use messages with no text

    // Last assistant message (by creation) is the parent for the next turn
    let parentMessageId = 0;
    for (const m of ordered) {
      if (m.role === 'assistant' && typeof m.message_id === 'number') parentMessageId = m.message_id;
    }
    return Response.json({ metadata: data.metadata, messages, parentMessageId });
  } catch (e) {
    console.error('Thread GET error:', e);
    return Response.json({ error: 'Failed to describe thread' }, { status: 500 });
  }
}

export async function POST(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const threadId = Number(id);
    if (!Number.isFinite(threadId)) {
      return Response.json({ error: 'Invalid thread id' }, { status: 400 });
    }
    const body = await req.json();
    const threadName = typeof body?.threadName === 'string' ? body.threadName : '';
    if (!threadName.trim()) {
      return Response.json({ error: 'threadName is required' }, { status: 400 });
    }
    await updateThread(threadId, threadName.slice(0, 200), getCallerToken(req));
    return Response.json({ success: true });
  } catch (e) {
    console.error('Thread POST error:', e);
    return Response.json({ error: 'Failed to update thread' }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const threadId = Number(id);
    if (!Number.isFinite(threadId)) {
      return Response.json({ error: 'Invalid thread id' }, { status: 400 });
    }
    await deleteThread(threadId, getCallerToken(_req));
    return Response.json({ success: true });
  } catch (e) {
    console.error('Thread DELETE error:', e);
    return Response.json({ error: 'Failed to delete thread' }, { status: 500 });
  }
}
