import { createThread, listThreads, getCallerToken } from '@/lib/cortex-threads';

export async function GET(req: Request) {
  try {
    const threads = await listThreads(getCallerToken(req));
    // Newest activity first
    threads.sort((a, b) => (b.updated_on ?? 0) - (a.updated_on ?? 0));
    return Response.json(threads);
  } catch (e) {
    console.error('Threads GET error:', e);
    return Response.json({ error: 'Failed to list threads' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const thread = await createThread(getCallerToken(req));
    return Response.json(thread, { status: 201 });
  } catch (e) {
    console.error('Threads POST error:', e);
    return Response.json({ error: 'Failed to create thread' }, { status: 500 });
  }
}
