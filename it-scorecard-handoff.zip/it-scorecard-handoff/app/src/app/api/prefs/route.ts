import { querySnowflake, getCallerToken, getCurrentUser } from '@/lib/snowflake';
import { OBJ } from '@/lib/config';
import { PrefWriteSchema } from '@/lib/schemas';
import { NextRequest } from 'next/server';

// Per-user UI preferences (e.g. saved table column order). Rows are keyed by the
// authenticated accessing user (Sf-Context-Current-User), so each user gets their own.
const T = OBJ.USER_PREFS;
type Bind = Record<string, { type: string; value: string }>;

export async function GET(req: NextRequest) {
  try {
    const key = req.nextUrl.searchParams.get('key');
    if (!key) return Response.json({ error: 'Missing key' }, { status: 400 });
    const { username } = await getCurrentUser(req);
    const bindings: Bind = { '1': { type: 'TEXT', value: username }, '2': { type: 'TEXT', value: key } };
    const rows = await querySnowflake<{ PREF_VALUE: string | null }[]>(
      `SELECT PREF_VALUE FROM ${T} WHERE USERNAME = ? AND PREF_KEY = ?`,
      bindings,
      { callersRights: true, callerToken: getCallerToken(req) }
    );
    return Response.json({ value: rows.length ? rows[0].PREF_VALUE : null });
  } catch (e) {
    console.error('prefs GET error:', e);
    return Response.json({ error: 'Failed to load preference' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const parsed = PrefWriteSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
    const { key, value } = parsed.data;
    const { username } = await getCurrentUser(req);
    const opts = { callersRights: true as const, callerToken: getCallerToken(req) };
    // Upsert: delete-then-insert (avoids MERGE for a single row).
    await querySnowflake(
      `DELETE FROM ${T} WHERE USERNAME = ? AND PREF_KEY = ?`,
      { '1': { type: 'TEXT', value: username }, '2': { type: 'TEXT', value: key } },
      opts
    );
    await querySnowflake(
      `INSERT INTO ${T} (USERNAME, PREF_KEY, PREF_VALUE) VALUES (?, ?, ?)`,
      { '1': { type: 'TEXT', value: username }, '2': { type: 'TEXT', value: key }, '3': { type: 'TEXT', value } },
      opts
    );
    return Response.json({ success: true }, { status: 200 });
  } catch (e) {
    console.error('prefs PUT error:', e);
    return Response.json({ error: 'Failed to save preference' }, { status: 500 });
  }
}
