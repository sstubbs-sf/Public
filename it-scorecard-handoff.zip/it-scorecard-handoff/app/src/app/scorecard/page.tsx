'use client';

import { useMetrics } from '@/hooks/use-metrics';
import { useUIStore } from '@/stores/ui-store';
import { KpiCard } from '@/components/scorecard/KpiCard';
import { DataTable } from '@/components/scorecard/DataTable';
import { ScorecardSummary } from '@/components/scorecard/ScorecardSummary';
import { Header, TabNav } from '@/components/layout/Header';
import { Metric } from '@/types';
import { statusOf, statusRank, sectionLabel, globalDataAsOf } from '@/lib/utils';
import { useColumnOrder } from '@/hooks/use-column-order';

export default function ScorecardPage() {
  const { data: metrics, isLoading, error } = useMetrics();
  const { viewMode, setViewMode, openDrawer, statusFilter, toggleStatusFilter, setStatusFilter, sortMode, toggleSortMode, openMetricEditor, openManager, trendTimeframe, setTrendTimeframe } = useUIStore();
  const { order: columnOrder, reorder: reorderColumns, reset: resetColumns } = useColumnOrder();

  if (isLoading) {
    return (
      <>
        <Header />
        <TabNav />
        <main>
          <div style={{ color: 'var(--muted)' }}>Loading metrics...</div>
        </main>
      </>
    );
  }

  if (error || !metrics) {
    return (
      <>
        <Header />
        <TabNav />
        <main>
          <div style={{ color: 'var(--red)' }}>Failed to load metrics. Check server connection.</div>
        </main>
      </>
    );
  }

  const sections = [...new Set(metrics.map(m => m.section))];
  const dataAsOf = globalDataAsOf(metrics);

  // Filter + sort applied per-section at render time.
  const prepare = (list: Metric[]): Metric[] => {
    let out = statusFilter === 'all' ? list : list.filter(m => statusOf(m) === statusFilter);
    if (sortMode === 'worst') {
      out = [...out].sort((a, b) => statusRank(statusOf(a)) - statusRank(statusOf(b)));
    }
    return out;
  };

  const visibleCount = metrics.filter(m => statusFilter === 'all' || statusOf(m) === statusFilter).length;

  return (
    <>
      <Header />
      <TabNav />
      <main>
        <div data-tour="summary">
          <ScorecardSummary metrics={metrics} activeFilter={statusFilter} onFilter={setStatusFilter} />
        </div>

        <div className="sc-toolbar">
          <div className="sc-toolbar-left">
            <span className="section-label" style={{ marginBottom: 0 }}>
              {viewMode === 'cards' ? 'Key Performance Indicators — click any card to drill down' : 'Metrics Table — click any row to drill down'}
            </span>
            {dataAsOf && <span className="sc-asof">Data as of {dataAsOf}</span>}
          </div>
          <div className="sc-toolbar-right">
            <button className="init-new-btn" data-tour="new-metric" onClick={() => openMetricEditor('create')}>+ New Metric</button>
            <button className="filter-btn" data-tour="manage" onClick={openManager} title="Manage all metrics">Manage Metrics</button>
            <span className="sc-toolbar-sep" aria-hidden="true" />
            <button
              className={`filter-btn${sortMode === 'worst' ? ' active' : ''}`}
              data-tour="sort"
              onClick={toggleSortMode}
              title="Sort worst-performing metrics first"
            >
              {sortMode === 'worst' ? '↓ Worst first' : '↕ Sort'}
            </button>
            <span className="sc-toolbar-sep" aria-hidden="true" />
            <span data-tour="views" style={{ display: 'inline-flex', gap: '6px' }}>
              <button className={`filter-btn${viewMode === 'cards' ? ' active' : ''}`} onClick={() => setViewMode('cards')}>Cards</button>
              <button className={`filter-btn${viewMode === 'table' ? ' active' : ''}`} onClick={() => setViewMode('table')}>Table</button>
            </span>
            {viewMode === 'table' && (
              <>
                <span className="sc-toolbar-sep" aria-hidden="true" />
                <span className="sc-tf-label" data-tour="timeframe" title="Trend window for the Trend column">Trend:</span>
                <button className={`filter-btn${trendTimeframe === 'month' ? ' active' : ''}`} onClick={() => setTrendTimeframe('month')}>Month</button>
                <button className={`filter-btn${trendTimeframe === 'quarter' ? ' active' : ''}`} onClick={() => setTrendTimeframe('quarter')}>Quarter</button>
                <button className={`filter-btn${trendTimeframe === 'annual' ? ' active' : ''}`} onClick={() => setTrendTimeframe('annual')}>Annual</button>
                <span className="sc-toolbar-sep" aria-hidden="true" />
                <button className="filter-btn" onClick={resetColumns} title="Reset column order to default">Reset columns</button>
              </>
            )}
          </div>
        </div>

        {statusFilter !== 'all' && visibleCount === 0 ? (
          <div className="sc-empty">
            No metrics match this filter.{' '}
            <button className="sc-empty-clear" onClick={() => setStatusFilter('all')}>Show all</button>
          </div>
        ) : viewMode === 'cards' ? (
          <div className="kpi-grid">
            {sections.map((sec, si) => {
              const secMetrics = prepare(metrics.filter(m => m.section === sec));
              if (secMetrics.length === 0) return null;
              return <SectionCards key={sec} title={sectionLabel(sec)} metrics={secMetrics} onCardClick={openDrawer} isFirst={si === 0} />;
            })}
          </div>
        ) : (
          sections.map(sec => {
            const secMetrics = prepare(metrics.filter(m => m.section === sec));
            if (secMetrics.length === 0) return null;
            return <DataTable key={sec} sectionTitle={sectionLabel(sec)} metrics={secMetrics} onRowClick={openDrawer} timeframe={trendTimeframe} order={columnOrder} onReorder={reorderColumns} />;
          })
        )}
      </main>
    </>
  );
}

function SectionCards({ title, metrics, onCardClick, isFirst }: { title: string; metrics: Metric[]; onCardClick: (id: number) => void; isFirst: boolean }) {
  return (
    <>
      <div className={`section-label${!isFirst ? ' mt' : ''}`} style={{ gridColumn: '1 / -1' }}>{title}</div>
      {metrics.map((metric) => (
        <KpiCard key={metric.metricId} metric={metric} onClick={() => onCardClick(metric.metricId)} />
      ))}
    </>
  );
}
