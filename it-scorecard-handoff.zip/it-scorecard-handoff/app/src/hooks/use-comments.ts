import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Comment } from '@/types';
import { CommentCreate } from '@/lib/schemas';

export interface CurrentUser {
  username: string;
  displayName: string;
}

// The authenticated accessing user (captured server-side from SPCS ingress).
// Long cache: identity doesn't change within a session.
export function useCurrentUser() {
  return useQuery<CurrentUser>({
    queryKey: ['whoami'],
    queryFn: async () => {
      const resp = await fetch('/api/whoami');
      if (!resp.ok) throw new Error('Failed to resolve current user');
      return resp.json();
    },
    staleTime: 60 * 60 * 1000,
    gcTime: 60 * 60 * 1000,
  });
}

export function useComments(entityType?: string, entityId?: number) {
  return useQuery<Comment[]>({
    queryKey: ['comments', entityType, entityId],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (entityType) params.set('entityType', entityType);
      if (entityId !== undefined) params.set('entityId', String(entityId));
      const resp = await fetch(`/api/comments?${params}`);
      if (!resp.ok) throw new Error('Failed to fetch comments');
      return resp.json();
    },
    enabled: !!entityType && entityId !== undefined,
    staleTime: 30 * 1000,
  });
}

export function useCreateComment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (comment: CommentCreate) => {
      const resp = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(comment),
      });
      if (!resp.ok) throw new Error('Failed to post comment');
      return resp.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({
        queryKey: ['comments', variables.entityType, variables.entityId],
      });
    },
  });
}

export function useDeleteComment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ commentId }: { commentId: number; entityType: string; entityId: number }) => {
      const resp = await fetch(`/api/comments?commentId=${commentId}`, { method: 'DELETE' });
      if (!resp.ok) {
        const data = await resp.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to delete comment');
      }
      return resp.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({
        queryKey: ['comments', variables.entityType, variables.entityId],
      });
    },
  });
}
