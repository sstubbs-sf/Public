import { useQuery, useQueryClient } from '@tanstack/react-query';

// Reorderable table columns (Metric is pinned first and not included here).
export type ColId = 'latest' | 'target' | 'trend' | 'status' | 'owner';
export const DEFAULT_COLUMN_ORDER: ColId[] = ['latest', 'target', 'trend', 'status', 'owner'];
const PREF_KEY = 'tableColumnOrder';

// Repair a stored order against the current column set: drop unknown/duplicate
// ids and append any newly-added columns, so schema changes never corrupt prefs.
function repair(stored: unknown): ColId[] {
  const all = DEFAULT_COLUMN_ORDER as string[];
  const arr = Array.isArray(stored) ? stored : [];
  const valid = arr.filter((x, i): x is ColId => all.includes(x) && arr.indexOf(x) === i);
  const missing = DEFAULT_COLUMN_ORDER.filter(c => !valid.includes(c));
  return [...valid, ...missing];
}

// Per-user column order, loaded from and saved to /api/prefs (keyed by the
// authenticated user server-side). Falls back to the default while loading.
export function useColumnOrder() {
  const qc = useQueryClient();
  const query = useQuery<ColId[]>({
    queryKey: ['prefs', PREF_KEY],
    queryFn: async () => {
      const resp = await fetch(`/api/prefs?key=${PREF_KEY}`);
      if (!resp.ok) return DEFAULT_COLUMN_ORDER;
      const data = await resp.json();
      if (!data?.value) return DEFAULT_COLUMN_ORDER;
      try { return repair(JSON.parse(data.value)); } catch { return DEFAULT_COLUMN_ORDER; }
    },
    staleTime: 60 * 60 * 1000,
    gcTime: 60 * 60 * 1000,
  });

  const order = query.data ?? DEFAULT_COLUMN_ORDER;

  const persist = (next: ColId[]) => {
    const repaired = repair(next);
    qc.setQueryData(['prefs', PREF_KEY], repaired); // optimistic; shared across tables
    fetch('/api/prefs', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: PREF_KEY, value: JSON.stringify(repaired) }),
    }).catch(() => {});
  };

  return { order, reorder: persist, reset: () => persist(DEFAULT_COLUMN_ORDER) };
}
