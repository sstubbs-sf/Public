import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Initiative } from '@/types';
import { InitiativeWrite } from '@/lib/schemas';

export function useInitiatives() {
  return useQuery<Initiative[]>({
    queryKey: ['initiatives'],
    queryFn: async () => {
      const resp = await fetch('/api/initiatives');
      if (!resp.ok) throw new Error('Failed to fetch initiatives');
      return resp.json();
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useCreateInitiative() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InitiativeWrite) => {
      const resp = await fetch('/api/initiatives', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!resp.ok) {
        const j = await resp.json().catch(() => ({}));
        throw new Error(j.error || 'Failed to create initiative');
      }
      return resp.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['initiatives'] }),
  });
}

export function useUpdateInitiative() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InitiativeWrite }) => {
      const resp = await fetch(`/api/initiatives?id=${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!resp.ok) {
        const j = await resp.json().catch(() => ({}));
        throw new Error(j.error || 'Failed to update initiative');
      }
      return resp.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['initiatives'] }),
  });
}

export function useDeleteInitiative() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const resp = await fetch(`/api/initiatives?id=${id}`, { method: 'DELETE' });
      if (!resp.ok) {
        const j = await resp.json().catch(() => ({}));
        throw new Error(j.error || 'Failed to delete initiative');
      }
      return resp.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['initiatives'] }),
  });
}
