import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Metric } from '@/types';
import { MetricWrite } from '@/lib/schemas';

export function useMetrics() {
  return useQuery<Metric[]>({
    queryKey: ['metrics'],
    queryFn: async () => {
      const resp = await fetch('/api/metrics');
      if (!resp.ok) throw new Error('Failed to fetch metrics');
      return resp.json();
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useMetricById(metricId: number | null) {
  const { data: metrics } = useMetrics();
  if (!metrics || metricId === null) return null;
  return metrics.find(m => m.metricId === metricId) || null;
}

export function useCreateMetric() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: MetricWrite) => {
      const resp = await fetch('/api/metrics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!resp.ok) {
        const j = await resp.json().catch(() => ({}));
        throw new Error(j.error || 'Failed to create metric');
      }
      return resp.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['metrics'] }),
  });
}

export function useUpdateMetric() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: MetricWrite }) => {
      const resp = await fetch(`/api/metrics?id=${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!resp.ok) {
        const j = await resp.json().catch(() => ({}));
        throw new Error(j.error || 'Failed to update metric');
      }
      return resp.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['metrics'] }),
  });
}

export function useDeleteMetric() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const resp = await fetch(`/api/metrics?id=${id}`, { method: 'DELETE' });
      if (!resp.ok) {
        const j = await resp.json().catch(() => ({}));
        throw new Error(j.error || 'Failed to delete metric');
      }
      return resp.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['metrics'] }),
  });
}
