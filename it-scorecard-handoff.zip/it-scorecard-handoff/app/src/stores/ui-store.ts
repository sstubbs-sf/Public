import { create } from 'zustand';
import { BrandMode, BRANDS, BRAND_KEY, readStoredBrand } from '@/lib/brand';
import { Status } from '@/types';
import { TrendTimeframe } from '@/lib/utils';

type ViewMode = 'cards' | 'table';
export type StatusFilter = Status | 'all';
export type SortMode = 'default' | 'worst';

// Apply the brand to the document: data-brand attribute (drives CSS theme) + tab title.
function applyBrand(brand: BrandMode) {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.brand = brand;
  document.title = `${BRANDS[brand].name} IT Scorecard`;
}

interface UIState {
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  statusFilter: StatusFilter;
  setStatusFilter: (f: StatusFilter) => void;
  toggleStatusFilter: (f: StatusFilter) => void;
  sortMode: SortMode;
  setSortMode: (m: SortMode) => void;
  toggleSortMode: () => void;
  trendTimeframe: TrendTimeframe;
  setTrendTimeframe: (t: TrendTimeframe) => void;
  drawerOpen: boolean;
  activeMetricId: number | null;
  openDrawer: (metricId: number) => void;
  closeDrawer: () => void;
  chatOpen: boolean;
  chatExpanded: boolean;
  toggleChat: () => void;
  closeChatPanel: () => void;
  toggleChatExpand: () => void;
  helpOpen: boolean;
  toggleHelp: () => void;
  managerOpen: boolean;
  openManager: () => void;
  closeManager: () => void;
  metricEditorOpen: boolean;
  metricEditorMode: 'create' | 'edit';
  metricEditorId: number | null;
  openMetricEditor: (mode: 'create' | 'edit', metricId?: number) => void;
  closeMetricEditor: () => void;
  tourOpen: boolean;
  startTour: () => void;
  endTour: () => void;
  brand: BrandMode;
  setBrand: (brand: BrandMode) => void;
  syncBrand: () => void;
}

export const useUIStore = create<UIState>((set, get) => ({
  viewMode: (typeof window !== 'undefined' ? sessionStorage.getItem('scorecardView') as ViewMode : null) || 'cards',
  setViewMode: (mode) => {
    if (typeof window !== 'undefined') sessionStorage.setItem('scorecardView', mode);
    set({ viewMode: mode });
  },
  statusFilter: 'all',
  setStatusFilter: (f) => set({ statusFilter: f }),
  toggleStatusFilter: (f) => set((s) => ({ statusFilter: s.statusFilter === f ? 'all' : f })),
  sortMode: 'default',
  setSortMode: (m) => set({ sortMode: m }),
  toggleSortMode: () => set((s) => ({ sortMode: s.sortMode === 'worst' ? 'default' : 'worst' })),
  trendTimeframe: (typeof window !== 'undefined' ? sessionStorage.getItem('scorecardTrendTf') as TrendTimeframe : null) || 'quarter',
  setTrendTimeframe: (t) => {
    if (typeof window !== 'undefined') sessionStorage.setItem('scorecardTrendTf', t);
    set({ trendTimeframe: t });
  },
  drawerOpen: false,
  activeMetricId: null,
  openDrawer: (metricId) => set({ drawerOpen: true, activeMetricId: metricId }),
  closeDrawer: () => set({ drawerOpen: false, activeMetricId: null }),
  chatOpen: true,
  chatExpanded: false,
  toggleChat: () => set((s) => ({ chatOpen: !s.chatOpen, chatExpanded: s.chatOpen ? false : s.chatExpanded })),
  closeChatPanel: () => set({ chatOpen: false, chatExpanded: false }),
  toggleChatExpand: () => set((s) => ({ chatExpanded: !s.chatExpanded })),
  helpOpen: false,
  toggleHelp: () => set((s) => ({ helpOpen: !s.helpOpen })),
  managerOpen: false,
  openManager: () => set({ managerOpen: true }),
  closeManager: () => set({ managerOpen: false }),
  metricEditorOpen: false,
  metricEditorMode: 'create',
  metricEditorId: null,
  openMetricEditor: (mode, metricId) => set({ metricEditorOpen: true, metricEditorMode: mode, metricEditorId: metricId ?? null }),
  closeMetricEditor: () => set({ metricEditorOpen: false, metricEditorId: null }),
  tourOpen: false,
  startTour: () => set({ tourOpen: true }),
  endTour: () => set({ tourOpen: false }),
  brand: readStoredBrand(),
  setBrand: (brand) => {
    if (typeof window !== 'undefined') window.localStorage.setItem(BRAND_KEY, brand);
    applyBrand(brand);
    set({ brand });
  },
  // Re-assert the persisted brand onto the document after client mount. Guards against
  // React hydration reconciling <html> and dropping the data-brand set by the no-FOUC
  // head script, which would otherwise revert the theme to the default while the
  // store-driven logo stays on the persisted brand.
  syncBrand: () => {
    const stored = readStoredBrand();
    if (stored !== get().brand) set({ brand: stored });
    applyBrand(stored);
  },
}));
