'use client';

import { create } from 'zustand';
import { AgentMessage, Attachment, ContextItem } from '@/types';
import { classify, truncate } from '@/lib/file-types';
import { buildCoworkPrompt, buildCoworkUrl } from '@/lib/cowork-handoff';

// Total character budget for uploaded-file context injected on each turn.
const CONTEXT_BUDGET = 24_000;
// Separate budget for pinned on-screen artifacts (metrics / initiatives).
const ARTIFACT_BUDGET = 12_000;

export interface ThreadSummary {
  threadId: number;
  name: string;
  updatedOn: number;
}

interface RawThread {
  thread_id: number;
  thread_name: string;
  updated_on: number;
}

interface ChatState {
  threads: ThreadSummary[];
  activeThreadId: number | null;
  parentMessageId: number;
  messages: AgentMessage[];
  attachments: Attachment[];
  contextItems: ContextItem[];
  isStreaming: boolean;
  threadsLoading: boolean;

  loadThreads: () => Promise<void>;
  newThread: () => Promise<void>;
  switchThread: (id: number) => Promise<void>;
  renameThread: (id: number, name: string) => Promise<void>;
  deleteThread: (id: number) => Promise<void>;
  uploadFiles: (files: File[]) => Promise<void>;
  removeAttachment: (id: string) => void;
  toggleContextItem: (item: ContextItem) => void;
  removeContextItem: (id: string) => void;
  isContextItemActive: (id: string) => boolean;
  continueInCowork: () => Promise<{ opened: boolean; copied: boolean; empty: boolean }>;
  send: (message: string, context?: string) => Promise<void>;
}

function toSummary(t: RawThread): ThreadSummary {
  return {
    threadId: t.thread_id,
    name: (t.thread_name && t.thread_name.trim()) || 'New chat',
    updatedOn: t.updated_on ?? Date.now(),
  };
}

// Read a text-like file in the browser (no server round-trip).
function readAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result ?? ''));
    r.onerror = () => reject(r.error ?? new Error('Failed to read file'));
    r.readAsText(file);
  });
}

// Convert a spreadsheet to CSV text (all sheets) using SheetJS, in the browser.
async function readSpreadsheet(file: File): Promise<string> {
  const XLSX = await import('xlsx');
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array' });
  return wb.SheetNames.map((name) => {
    const csv = XLSX.utils.sheet_to_csv(wb.Sheets[name]);
    return `# Sheet: ${name}\n${csv}`;
  })
    .join('\n\n')
    .trim();
}

// Build the bounded context block from ready attachments, injected each turn so
// files can be referenced at will. Largest files are truncated first to fit budget.
function buildAttachmentContext(attachments: Attachment[]): string | undefined {
  const ready = attachments.filter((a) => a.status === 'ready' && a.extractedText);
  if (!ready.length) return undefined;

  let budget = CONTEXT_BUDGET;
  const ordered = [...ready].sort(
    (a, b) => (a.extractedText?.length ?? 0) - (b.extractedText?.length ?? 0)
  );
  const blocks: string[] = [];
  ordered.forEach((a, i) => {
    const remainingFiles = ordered.length - i;
    const share = Math.max(500, Math.floor(budget / remainingFiles));
    const body = truncate(a.extractedText ?? '', share);
    budget -= body.length;
    blocks.push(`--- FILE: ${a.name} (${a.category}) ---\n${body}`);
  });
  return (
    'The user attached these files for reference. Use them to answer questions:\n\n' +
    blocks.join('\n\n')
  );
}

// Build context from pinned on-screen artifacts (metrics / initiatives).
function buildArtifactContext(items: ContextItem[]): string | undefined {
  if (!items.length) return undefined;
  let budget = ARTIFACT_BUDGET;
  const blocks: string[] = [];
  for (const item of items) {
    if (budget <= 0) break;
    const body = truncate(item.text, Math.max(400, budget));
    budget -= body.length;
    blocks.push(`--- ${item.kind.toUpperCase()}: ${item.label} ---\n${body}`);
  }
  return (
    'The user pinned these scorecard items as context. Use them to answer questions:\n\n' +
    blocks.join('\n\n')
  );
}

export const useChatStore = create<ChatState>((set, get) => ({
  threads: [],
  activeThreadId: null,
  parentMessageId: 0,
  messages: [],
  attachments: [],
  contextItems: [],
  isStreaming: false,
  threadsLoading: false,

  loadThreads: async () => {
    set({ threadsLoading: true });
    try {
      const resp = await fetch('/api/threads');
      if (!resp.ok) throw new Error('Failed to load threads');
      const raw: RawThread[] = await resp.json();
      set({ threads: raw.map(toSummary) });
    } catch (e) {
      console.error(e);
    } finally {
      set({ threadsLoading: false });
    }
  },

  newThread: async () => {
    try {
      const resp = await fetch('/api/threads', { method: 'POST' });
      if (!resp.ok) throw new Error('Failed to create thread');
      const t: RawThread = await resp.json();
      set((s) => ({
        threads: [toSummary(t), ...s.threads],
        activeThreadId: t.thread_id,
        parentMessageId: 0,
        messages: [],
        attachments: [],
      }));
    } catch (e) {
      console.error(e);
    }
  },

  switchThread: async (id) => {
    if (get().activeThreadId === id) return;
    set({ activeThreadId: id, messages: [], parentMessageId: 0, attachments: [] });
    try {
      const resp = await fetch(`/api/threads/${id}`);
      if (!resp.ok) throw new Error('Failed to open thread');
      const data = await resp.json();
      const messages: AgentMessage[] = (data.messages || []).map(
        (m: { role: string; content: string; created_on: number }) => ({
          role: m.role === 'assistant' ? 'assistant' : 'user',
          content: m.content,
          timestamp: m.created_on ? new Date(m.created_on) : undefined,
        })
      );
      // Only apply if still the active thread (avoid race with rapid switching)
      if (get().activeThreadId === id) {
        set({ messages, parentMessageId: data.parentMessageId ?? 0 });
      }
    } catch (e) {
      console.error(e);
    }
  },

  renameThread: async (id, name) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    set((s) => ({
      threads: s.threads.map((t) => (t.threadId === id ? { ...t, name: trimmed } : t)),
    }));
    try {
      await fetch(`/api/threads/${id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ threadName: trimmed }),
      });
    } catch (e) {
      console.error(e);
    }
  },

  deleteThread: async (id) => {
    try {
      await fetch(`/api/threads/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.error(e);
    }
    set((s) => {
      const threads = s.threads.filter((t) => t.threadId !== id);
      if (s.activeThreadId === id) {
        return { threads, activeThreadId: null, messages: [], parentMessageId: 0, attachments: [] };
      }
      return { threads };
    });
  },

  uploadFiles: async (files) => {
    for (const file of files) {
      const cls = classify(file.name);
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

      if (!cls.supported) {
        set((s) => ({
          attachments: [
            ...s.attachments,
            {
              id,
              name: file.name,
              category: 'document',
              status: 'error',
              sizeBytes: file.size,
              error: cls.reason,
            },
          ],
        }));
        continue;
      }

      // Optimistic "uploading" chip
      set((s) => ({
        attachments: [
          ...s.attachments,
          { id, name: file.name, category: cls.category, status: 'uploading', sizeBytes: file.size },
        ],
      }));

      const finish = (patch: Partial<Attachment>) =>
        set((s) => ({
          attachments: s.attachments.map((a) => (a.id === id ? { ...a, ...patch } : a)),
        }));

      try {
        if (cls.category === 'text' || cls.category === 'spreadsheet') {
          // Handled entirely in the browser.
          const raw =
            cls.category === 'spreadsheet' ? await readSpreadsheet(file) : await readAsText(file);
          const text = truncate(raw.trim());
          if (!text) {
            finish({ status: 'error', error: 'File is empty.' });
          } else {
            finish({ status: 'ready', extractedText: text });
          }
        } else {
          // Binary → server stages it and runs the right Cortex extraction.
          const fd = new FormData();
          fd.append('file', file);
          const threadId = get().activeThreadId;
          if (threadId != null) fd.append('threadId', String(threadId));
          const resp = await fetch('/api/files', { method: 'POST', body: fd });
          const data = await resp.json();
          if (!resp.ok) {
            finish({ status: 'error', error: data.error || 'Processing failed' });
          } else {
            finish({ status: 'ready', extractedText: data.extractedText });
          }
        }
      } catch (e) {
        finish({ status: 'error', error: e instanceof Error ? e.message : 'Upload failed' });
      }
    }
  },

  removeAttachment: (id) => {
    set((s) => ({ attachments: s.attachments.filter((a) => a.id !== id) }));
  },

  // Pinned artifacts persist across threads (they're app data, not session uploads).
  toggleContextItem: (item) => {
    set((s) =>
      s.contextItems.some((c) => c.id === item.id)
        ? { contextItems: s.contextItems.filter((c) => c.id !== item.id) }
        : { contextItems: [...s.contextItems, item] }
    );
  },

  removeContextItem: (id) => {
    set((s) => ({ contextItems: s.contextItems.filter((c) => c.id !== id) }));
  },

  isContextItemActive: (id) => get().contextItems.some((c) => c.id === id),

  // Hand off the pinned tiles + session-discussed context to Snowflake CoWork on
  // the same agent. Copies the prompt to the clipboard (guaranteed) and opens the
  // CoWork direct link with a best-effort prompt param.
  continueInCowork: async () => {
    const { messages, contextItems, attachments } = get();
    const hasContent = contextItems.length > 0 || messages.some((m) => m.content?.trim());
    if (!hasContent) return { opened: false, copied: false, empty: true };

    const prompt = buildCoworkPrompt({ messages, contextItems, attachments });
    const url = buildCoworkUrl(prompt);

    let copied = false;
    try {
      await navigator.clipboard.writeText(prompt);
      copied = true;
    } catch {
      /* clipboard may be blocked; URL param still carries the prompt */
    }
    const win = url ? window.open(url, '_blank', 'noopener,noreferrer') : null;
    return { opened: !!win, copied, empty: false };
  },

  send: async (message, context) => {
    // Ensure a thread exists before sending so context is retained server-side
    let threadId = get().activeThreadId;
    let isFirstMessage = false;
    if (threadId == null) {
      try {
        const resp = await fetch('/api/threads', { method: 'POST' });
        if (!resp.ok) throw new Error('Failed to create thread');
        const t: RawThread = await resp.json();
        threadId = t.thread_id;
        isFirstMessage = true;
        set((s) => ({
          threads: [toSummary(t), ...s.threads],
          activeThreadId: t.thread_id,
          parentMessageId: 0,
          messages: [],
        }));
      } catch (e) {
        console.error(e);
      }
    } else {
      isFirstMessage = get().messages.length === 0;
    }

    const userMsg: AgentMessage = { role: 'user', content: message, timestamp: new Date() };
    // Push the user message plus a live-updating placeholder assistant message so
    // tokens render as they stream in.
    set((s) => ({
      messages: [
        ...s.messages,
        userMsg,
        { role: 'assistant', content: '', timestamp: new Date(), streaming: true },
      ],
      isStreaming: true,
    }));

    // Auto-title a fresh thread from its first user message
    if (isFirstMessage && threadId != null) {
      const title = message.length > 48 ? message.slice(0, 48) + '…' : message;
      get().renameThread(threadId, title);
    }

    // Mutate the trailing (streaming) assistant message in place.
    const patchLast = (patch: (m: AgentMessage) => AgentMessage) =>
      set((s) => {
        const msgs = s.messages.slice();
        for (let i = msgs.length - 1; i >= 0; i--) {
          if (msgs[i].role === 'assistant') {
            msgs[i] = patch(msgs[i]);
            break;
          }
        }
        return { messages: msgs };
      });

    try {
      const attachmentContext = buildAttachmentContext(get().attachments);
      const artifactContext = buildArtifactContext(get().contextItems);
      const combinedContext =
        [context, artifactContext, attachmentContext].filter(Boolean).join('\n\n') || undefined;
      const resp = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          context: combinedContext,
          threadId: threadId ?? undefined,
          parentMessageId: get().parentMessageId,
        }),
      });
      if (!resp.ok || !resp.body) {
        let msg = 'Agent request failed';
        try {
          const err = await resp.json();
          msg = err.error ? (typeof err.error === 'string' ? err.error : msg) : msg;
        } catch { /* non-JSON error body */ }
        throw new Error(msg);
      }

      // Consume the NDJSON stream line by line.
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let acc = '';
      const charts: string[] = [];
      let finalThreadId: number | undefined;
      let finalAssistantId: number | undefined;
      let streamError: string | undefined;

      const handleLine = (line: string) => {
        const trimmed = line.trim();
        if (!trimmed) return;
        let evt: Record<string, unknown>;
        try {
          evt = JSON.parse(trimmed);
        } catch {
          return;
        }
        switch (evt.type) {
          case 'text':
            acc += (evt.delta as string) || '';
            patchLast((m) => ({ ...m, content: acc }));
            break;
          case 'chart':
            if (evt.spec != null) {
              charts.push(typeof evt.spec === 'string' ? evt.spec : JSON.stringify(evt.spec));
              patchLast((m) => ({ ...m, charts: [...charts] }));
            }
            break;
          case 'meta':
            if (typeof evt.threadId === 'number') finalThreadId = evt.threadId;
            if (typeof evt.assistantMessageId === 'number') finalAssistantId = evt.assistantMessageId;
            break;
          case 'error':
            streamError = (evt.message as string) || 'Agent stream failed';
            break;
        }
      };

      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let nl: number;
        while ((nl = buffer.indexOf('\n')) !== -1) {
          handleLine(buffer.slice(0, nl));
          buffer = buffer.slice(nl + 1);
        }
      }
      if (buffer) handleLine(buffer);

      if (streamError && !acc) throw new Error(streamError);

      patchLast((m) => ({ ...m, content: acc || 'No response from agent.', streaming: false }));
      set((s) => ({
        parentMessageId:
          typeof finalAssistantId === 'number' ? finalAssistantId : s.parentMessageId,
        threads: s.threads
          .map((t) =>
            t.threadId === (finalThreadId ?? threadId) ? { ...t, updatedOn: Date.now() } : t
          )
          .sort((a, b) => b.updatedOn - a.updatedOn),
      }));
    } catch (e) {
      const errText = `Error: ${e instanceof Error ? e.message : 'Unknown error'}`;
      patchLast((m) => ({ ...m, content: errText, streaming: false }));
    } finally {
      set({ isStreaming: false });
    }
  },
}));
