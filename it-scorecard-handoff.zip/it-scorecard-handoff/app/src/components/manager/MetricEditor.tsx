'use client';

import { useEffect, useMemo, useState } from 'react';
import { useMetrics, useCreateMetric, useUpdateMetric } from '@/hooks/use-metrics';
import { useUIStore } from '@/stores/ui-store';
import { computeStatus } from '@/lib/utils';

interface MonthCell { plan: number | null; actual: number | null; }

// Percent metrics store decimals (0.93 = 93%); the grid shows/accepts percentages.
function rawToDisplay(raw: number | null, isPercent: boolean): string {
  if (raw === null) return '';
  if (isPercent) {
    const pct = Math.round(raw * 1000) / 10;
    return String(pct);
  }
  return String(raw);
}
function displayToRaw(str: string, isPercent: boolean): number | null {
  const t = str.trim();
  if (t === '') return null;
  const n = Number(t);
  if (!Number.isFinite(n)) return null;
  return isPercent ? n / 100 : n;
}

export function MetricEditor() {
  const { metricEditorOpen: open, metricEditorMode: mode, metricEditorId, closeMetricEditor } = useUIStore();
  const { data: metrics } = useMetrics();
  const createMetric = useCreateMetric();
  const updateMetric = useUpdateMetric();

  const target = mode === 'edit' && metricEditorId !== null ? (metrics || []).find(m => m.metricId === metricEditorId) : null;

  const [name, setName] = useState('');
  const [section, setSection] = useState('');
  const [target_, setTargetDesc] = useState('');
  const [owner, setOwner] = useState('');
  const [direction, setDirection] = useState<'high' | 'low'>('high');
  const [isPercent, setIsPercent] = useState(false);
  const [cells, setCells] = useState<Map<number, MonthCell>>(new Map());
  const [err, setErr] = useState('');

  // Canonical month set (index/name/year) — all metrics share it; derive from any metric.
  const months = useMemo(() => {
    const src = (metrics || []).find(m => m.monthly.length > 0);
    return src ? src.monthly.map(mo => ({ index: mo.monthIndex, name: mo.monthName, year: mo.monthYear })) : [];
  }, [metrics]);

  const knownSections = useMemo(() => [...new Set((metrics || []).map(m => m.section))], [metrics]);

  useEffect(() => {
    if (!open) return;
    setName(target?.name || '');
    setSection(target?.section || '');
    setTargetDesc(target?.targetDescription || '');
    setOwner(target?.owner || '');
    setDirection(target?.direction || 'high');
    setIsPercent(target?.isPercent || false);
    const m = new Map<number, MonthCell>();
    if (target) {
      for (const mo of target.monthly) m.set(mo.monthIndex, { plan: mo.plan, actual: mo.actual });
    }
    setCells(m);
    setErr('');
  }, [open, target]);

  const setCell = (idx: number, key: 'plan' | 'actual', raw: number | null) => {
    setCells(prev => {
      const next = new Map(prev);
      const cur = next.get(idx) || { plan: null, actual: null };
      next.set(idx, { ...cur, [key]: raw });
      return next;
    });
  };

  const saving = createMetric.isPending || updateMetric.isPending;
  const canSave = name.trim() && section.trim() && !saving;

  const handleSave = async () => {
    if (!canSave) return;
    setErr('');
    const monthly = months.map(mo => {
      const c = cells.get(mo.index) || { plan: null, actual: null };
      return { monthIndex: mo.index, plan: c.plan, actual: c.actual };
    });
    const payload = {
      name: name.trim(),
      section: section.trim(),
      targetDescription: target_.trim(),
      owner: owner.trim(),
      direction,
      isPercent,
      monthly,
    };
    try {
      if (mode === 'edit' && target) {
        await updateMetric.mutateAsync({ id: target.metricId, data: payload });
      } else {
        await createMetric.mutateAsync(payload);
      }
      closeMetricEditor();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Save failed');
    }
  };

  return (
    <>
      <div className={`drawer-overlay ie-elevated${open ? ' open' : ''}`} onClick={closeMetricEditor} />
      <div className={`drawer ie-elevated${open ? ' open' : ''}`} role="dialog" aria-label={mode === 'edit' ? 'Edit metric' : 'New metric'}>
        <div className="drawer-header" style={{ position: 'relative' }}>
          <div style={{ fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--muted)' }}>
            {mode === 'edit' ? 'Edit Metric' : 'New Metric'}
          </div>
          <div style={{ fontSize: '16px', fontWeight: 700, marginTop: '2px' }}>
            {mode === 'edit' ? (target?.name || 'Metric') : 'Add a KPI'}
          </div>
          <button className="close-btn" onClick={closeMetricEditor} aria-label="Close">✕</button>
        </div>

        <div className="drawer-body">
          <div className="ie-field">
            <label className="ie-label">Metric Name <span className="ie-req">*</span></label>
            <input className="ie-input" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Customer Satisfaction (CSAT)" />
          </div>

          <div className="ie-field">
            <label className="ie-label">Section <span className="ie-req">*</span></label>
            <input className="ie-input" list="me-sections" value={section} onChange={e => setSection(e.target.value)} placeholder="Select or type a section" />
            <datalist id="me-sections">{knownSections.map(s => <option key={s} value={s} />)}</datalist>
          </div>

          <div className="ie-field">
            <label className="ie-label">Target Description</label>
            <input className="ie-input" value={target_} onChange={e => setTargetDesc(e.target.value)} placeholder="e.g. ≥ 95% on target" />
          </div>

          <div className="ie-field">
            <label className="ie-label">Owner</label>
            <input className="ie-input" value={owner} onChange={e => setOwner(e.target.value)} placeholder="Owner" />
          </div>

          <div style={{ display: 'flex', gap: '18px', flexWrap: 'wrap' }}>
            <div className="ie-field" style={{ marginBottom: '10px' }}>
              <label className="ie-label">Scoring Direction</label>
              <div className="me-toggle">
                <button type="button" className={`me-toggle-btn${direction === 'high' ? ' active' : ''}`} onClick={() => setDirection('high')}>↑ Higher is better</button>
                <button type="button" className={`me-toggle-btn${direction === 'low' ? ' active' : ''}`} onClick={() => setDirection('low')}>↓ Lower is better</button>
              </div>
            </div>
            <div className="ie-field" style={{ marginBottom: '10px' }}>
              <label className="ie-label">Value Format</label>
              <div className="me-toggle">
                <button type="button" className={`me-toggle-btn${!isPercent ? ' active' : ''}`} onClick={() => setIsPercent(false)}>Number</button>
                <button type="button" className={`me-toggle-btn${isPercent ? ' active' : ''}`} onClick={() => setIsPercent(true)}>Percent %</button>
              </div>
            </div>
          </div>

          <div className="ie-field">
            <label className="ie-label">Monthly Values {isPercent && <span className="ie-count">enter as %</span>}</label>
            <div className="ie-hint" style={{ marginTop: 0, marginBottom: '6px' }}>Status is auto-computed from Plan vs Actual and direction.</div>
            <div className="me-grid" key={`${open ? 'o' : 'c'}-${target?.metricId ?? 'new'}`}>
              <div className="me-grid-head">
                <span>Month</span><span>Plan</span><span>Actual</span><span>Status</span>
              </div>
              {months.map(mo => {
                const c = cells.get(mo.index) || { plan: null, actual: null };
                const st = computeStatus(c.actual, c.plan, direction);
                return (
                  <div key={mo.index} className="me-grid-row">
                    <span className="me-mon">{mo.name} <span className="me-yr">'{mo.year.slice(2)}</span></span>
                    <input
                      className="me-cell" inputMode="decimal"
                      defaultValue={rawToDisplay(c.plan, isPercent)}
                      onChange={e => setCell(mo.index, 'plan', displayToRaw(e.target.value, isPercent))}
                    />
                    <input
                      className="me-cell" inputMode="decimal"
                      defaultValue={rawToDisplay(c.actual, isPercent)}
                      onChange={e => setCell(mo.index, 'actual', displayToRaw(e.target.value, isPercent))}
                    />
                    <span className={`kpi-ref-dot ${st}`} title={st} />
                  </div>
                );
              })}
            </div>
          </div>

          {err && <div className="ie-error">{err}</div>}
        </div>

        <div className="ie-footer">
          <button className="ie-btn ghost" onClick={closeMetricEditor} disabled={saving}>Cancel</button>
          <button className="ie-btn primary" onClick={handleSave} disabled={!canSave}>
            {saving ? 'Saving…' : mode === 'edit' ? 'Save Changes' : 'Create Metric'}
          </button>
        </div>
      </div>
    </>
  );
}
