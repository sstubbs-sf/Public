'use client';

import { useMetrics, useDeleteMetric } from '@/hooks/use-metrics';
import { useUIStore } from '@/stores/ui-store';
import { statusOf, sectionLabel, formatValue, getLatestMonth, formatTarget } from '@/lib/utils';
import { Metric } from '@/types';

export function MetricManager({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { data: metrics } = useMetrics();
  const { openMetricEditor } = useUIStore();

  if (!open || !metrics) return null;

  const sections = [...new Set(metrics.map(m => m.section))];

  return (
    <div className="mm-overlay" onClick={onClose}>
      <div className="mm-panel" onClick={e => e.stopPropagation()}>
        <div className="mm-head">
          <span className="mm-title">Manage Metrics</span>
          <div className="mm-head-actions">
            <button className="mm-add" onClick={() => openMetricEditor('create')}>+ Add Metric</button>
            <button className="mm-close" onClick={onClose}>✕ Close</button>
          </div>
        </div>

        <div className="mm-colhead">
          <span></span><span>Metric</span><span>Target</span><span>Owner</span><span></span>
        </div>

        <div className="mm-body">
          {sections.map(sec => {
            const secMetrics = metrics.filter(m => m.section === sec);
            return (
              <div key={sec}>
                <div className="mm-sec">
                  <span>{sectionLabel(sec)}</span>
                  <span className="mm-sec-count">{secMetrics.length}</span>
                </div>
                {secMetrics.map(m => <MetricRow key={m.metricId} metric={m} />)}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function MetricRow({ metric }: { metric: Metric }) {
  const { openMetricEditor } = useUIStore();
  const deleteMetric = useDeleteMetric();
  const st = statusOf(metric);
  const latest = getLatestMonth(metric);

  const handleDelete = () => {
    if (confirm(`Delete metric "${metric.name}"?\n\nThis removes its monthly data, KPI links, and comments. This cannot be undone.`)) {
      deleteMetric.mutate(metric.metricId);
    }
  };

  return (
    <div className="mm-row">
      <span className={`kpi-ref-dot ${st}`} title={st} />
      <span className="mm-name">
        {metric.name}
        {latest && <span className="mm-latest">{formatValue(latest.actual, metric.isPercent)}</span>}
      </span>
      <span className="mm-target">{formatTarget(metric)}</span>
      <span className="mm-owner">{metric.owner || '—'}</span>
      <span className="mm-row-actions">
        <button className="ic-act-btn" onClick={() => openMetricEditor('edit', metric.metricId)}>✎ Edit</button>
        <button className="ic-act-btn danger" onClick={handleDelete} disabled={deleteMetric.isPending}>🗑</button>
      </span>
    </div>
  );
}
