'use client';

import { MonthData, Status } from '@/types';

interface SparklineProps {
  monthly: MonthData[];
}

const STATUS_COLORS: Record<Status, string> = {
  green: '#16a34a',
  yellow: '#ca8a04',
  red: '#dc2626',
  gray: '#9ca3af',
};

export function Sparkline({ monthly }: SparklineProps) {
  const points = monthly.filter(m => m.actual !== null);
  if (points.length < 2) return null;

  const W = 190, H = 28;
  const data = points.map(m => m.actual as number);
  const statuses = points.map(m => m.status);
  const planPts = points.map(m => m.plan);
  const hasPlan = planPts.filter(p => p !== null).length >= 2;

  // Include plan values in the range so the reference line stays in-frame.
  const scaleVals = [...data, ...(hasPlan ? (planPts.filter(p => p !== null) as number[]) : [])];
  const min = Math.min(...scaleVals);
  const max = Math.max(...scaleVals);
  const range = max - min || 1;
  const n = data.length - 1;

  const x = (i: number) => (i / n) * (W - 4) + 2;
  const y = (v: number) => H - 3 - ((v - min) / range) * (H - 6);

  // Draw each segment in the color of the destination point's status
  const segments: React.ReactElement[] = [];
  for (let i = 1; i < data.length; i++) {
    const color = STATUS_COLORS[statuses[i]];
    segments.push(
      <line
        key={i}
        x1={x(i - 1).toFixed(1)}
        y1={y(data[i - 1]).toFixed(1)}
        x2={x(i).toFixed(1)}
        y2={y(data[i]).toFixed(1)}
        stroke={color}
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    );
  }

  // Faint dashed plan/target reference line.
  let planPath = '';
  if (hasPlan) {
    let started = false;
    planPts.forEach((p, i) => {
      if (p === null) { started = false; return; }
      planPath += `${started ? 'L' : 'M'}${x(i).toFixed(1)},${y(p).toFixed(1)} `;
      started = true;
    });
  }

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: `${H}px` }} role="img" aria-hidden="true">
      {hasPlan && planPath && (
        <path d={planPath.trim()} fill="none" stroke="#94a3b8" strokeWidth="1" strokeDasharray="3 2" opacity="0.7" />
      )}
      {segments}
      {/* A dot at every plotted point, colored by that month's status. */}
      {data.map((v, i) => (
        <circle
          key={i}
          cx={x(i).toFixed(1)}
          cy={y(v).toFixed(1)}
          r={i === n ? '2.8' : '2.2'}
          fill={STATUS_COLORS[statuses[i]]}
        />
      ))}
    </svg>
  );
}
