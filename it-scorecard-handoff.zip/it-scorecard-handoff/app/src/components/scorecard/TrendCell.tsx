'use client';

import { Metric, Status } from '@/types';
import { windowedMonths, worstStatusInWindow, formatValue, TrendTimeframe } from '@/lib/utils';
import { Sparkline } from './Sparkline';

const WINDOW_LABEL: Record<TrendTimeframe, string> = {
  month: '1 month',
  quarter: '3 months',
  annual: '12 months',
};

const STATUS_LABELS: Record<Status, string> = {
  green: 'On Target',
  yellow: 'Watch',
  red: 'At Risk',
  gray: 'No Data',
};

interface TrendCellProps {
  metric: Metric;
  timeframe: TrendTimeframe;
}

export function TrendCell({ metric, timeframe }: TrendCellProps) {
  const win = windowedMonths(metric, timeframe);
  const worst = worstStatusInWindow(win);
  const last = win.length > 0 ? win[win.length - 1] : null;

  return (
    <span className="trend-cell">
      <span className="trend-spark">
        {win.length >= 2 ? (
          <Sparkline monthly={win} />
        ) : last ? (
          <span className="trend-single">
            <span className={`status-dot ${worst}`} aria-hidden="true" />
            {formatValue(last.actual, metric.isPercent)}
          </span>
        ) : (
          <span className="trend-empty">—</span>
        )}
      </span>
      <span className={`badge ${worst}`} title={`Worst status in the last ${WINDOW_LABEL[timeframe]}`}>
        {STATUS_LABELS[worst]}
      </span>
    </span>
  );
}
