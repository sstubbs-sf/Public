'use client';

import { Metric, Status } from '@/types';
import { getLatestMonth, formatValue, statusOf } from '@/lib/utils';

interface PvaBarProps {
  metric: Metric;
  compact?: boolean;
}

export function PvaBar({ metric, compact }: PvaBarProps) {
  const latest = getLatestMonth(metric);
  if (!latest || latest.actual === null) return <span>—</span>;

  const st = statusOf(metric);
  const actualFmt = formatValue(latest.actual, metric.isPercent);
  const planFmt = latest.plan !== null ? formatValue(latest.plan, metric.isPercent) : '—';
  const dir = metric.direction;

  // Compute bar zones based on direction
  let z1cls: Status, z2cls: Status, z3cls: Status;
  let z1w: string, z2w: string, z3w: string;
  let mk: number;

  const target = latest.plan ?? latest.actual;
  const scale = dir === 'high' ? target * 1.3 : target * 1.5;

  if (dir === 'high') {
    z1cls = 'red'; z2cls = 'yellow'; z3cls = 'green';
    z1w = '61.5'; z2w = '15.4'; z3w = '23.1';
  } else {
    z1cls = 'green'; z2cls = 'yellow'; z3cls = 'red';
    z1w = '66.7'; z2w = '13.3'; z3w = '20.0';
  }

  mk = Math.min((latest.actual / scale), 0.98) * 100;

  // Plan marker position (blue line)
  let planMk: number | null = null;
  if (latest.plan !== null) {
    planMk = Math.min((latest.plan / scale), 0.98) * 100;
  }

  return (
    <span className={`pva-cell${compact ? ' pva-compact' : ''}`}>
      <span className="pva-vals">
        <span className={`pva-actual-txt ${st}`}>{actualFmt}</span>
        <span className="pva-plan-txt"> / {planFmt}</span>
      </span>
      <span className="pva-bar">
        <span className="pva-track">
          <span className={`pva-zone ${z1cls}${st === z1cls ? ' active' : ''}`} style={{ width: `${z1w}%` }} />
          <span className={`pva-zone ${z2cls}${st === z2cls ? ' active' : ''}`} style={{ width: `${z2w}%` }} />
          <span className={`pva-zone ${z3cls}${st === z3cls ? ' active' : ''}`} style={{ width: `${z3w}%` }} />
          <span className="pva-mk" style={{ left: `${mk.toFixed(1)}%` }} />
          {planMk !== null && <span className="pva-plan-mk" style={{ left: `${planMk.toFixed(1)}%` }} />}
        </span>
      </span>
    </span>
  );
}
