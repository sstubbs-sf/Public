'use client';

import { Metric } from '@/types';
import { statusOf, formatValue, latestMonthLabel, statusLabel, priorDelta, formatTarget } from '@/lib/utils';
import { Sparkline } from './Sparkline';
import { PvaBar } from './PvaBar';
import { ContextPinButton } from '@/components/chat/ContextPinButton';
import { metricToContextItem } from '@/lib/artifact-context';

interface KpiCardProps {
  metric: Metric;
  onClick: () => void;
}

export function KpiCard({ metric, onClick }: KpiCardProps) {
  const status = statusOf(metric);
  const latestValue = formatValue(getLatestActual(metric), metric.isPercent);
  const delta = priorDelta(metric);
  const sparkMonths = metric.monthly.filter(m => m.actual !== null);
  const asOf = latestMonthLabel(metric);

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onClick();
    }
  };

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`${metric.name}: ${latestValue}, ${statusLabel(status)}. Open details.`}
      onClick={onClick}
      onKeyDown={handleKey}
      className={`kpi-card ${status}`}
      data-tour="drilldown"
    >
      <div className={`status-dot ${status}`} aria-hidden="true" />
      <div className="kpi-pin" data-tour="pin"><ContextPinButton item={metricToContextItem(metric)} /></div>
      <div className="label">{metric.name}</div>

      <div className="kpi-value-row">
        <div className="value" style={{ color: `var(--${status === 'gray' ? 'muted' : status})` }}>
          {latestValue}
        </div>
        {delta && (
          <span className={`kpi-delta ${delta.improved ? 'up' : 'down'}`} title="Change vs prior month">
            {delta.arrow} {delta.deltaText}
          </span>
        )}
      </div>

      <div className="kpi-meta">
        <span className={`badge ${status}`}>{statusLabel(status)}</span>
        {asOf && <span className="kpi-asof">as of {asOf}</span>}
      </div>

      <div className="kpi-target">Target: {formatTarget(metric)}</div>

      <div className="kpi-pva"><PvaBar metric={metric} compact /></div>

      {sparkMonths.length >= 2 && (
        <div className="spark">
          <Sparkline monthly={sparkMonths} />
        </div>
      )}
    </div>
  );
}

function getLatestActual(metric: Metric): number | null {
  const withActual = metric.monthly.filter(m => m.actual !== null);
  return withActual.length > 0 ? (withActual[withActual.length - 1].actual as number) : null;
}
