'use client';

import { ReactNode, useRef } from 'react';
import { Metric, Status } from '@/types';
import { statusOf, getLatestMonth, formatValue, formatTarget, TrendTimeframe } from '@/lib/utils';
import { TrendCell } from './TrendCell';
import { ContextPinButton } from '@/components/chat/ContextPinButton';
import { metricToContextItem } from '@/lib/artifact-context';
import { ColId } from '@/hooks/use-column-order';

interface DataTableProps {
  metrics: Metric[];
  sectionTitle: string;
  onRowClick: (metricId: number) => void;
  timeframe: TrendTimeframe;
  order: ColId[];
  onReorder: (order: ColId[]) => void;
}

const STATUS_LABELS: Record<Status, string> = {
  green: 'On Target', yellow: 'Watch', red: 'At Risk', gray: 'No Data',
};

interface ColDef {
  label: string;
  thClass: string;
  tdClass: string;
  cell: (metric: Metric, ctx: { timeframe: TrendTimeframe }) => ReactNode;
}

const COLUMNS: Record<ColId, ColDef> = {
  latest: {
    label: 'Latest', thClass: 'col-latest', tdClass: 'col-latest',
    cell: (m) => {
      const latest = getLatestMonth(m);
      return <strong>{latest ? formatValue(latest.actual, m.isPercent) : '—'}</strong>;
    },
  },
  target: {
    label: 'Target', thClass: 'col-target', tdClass: 'col-target',
    cell: (m) => formatTarget(m),
  },
  trend: {
    label: 'Trend', thClass: 'col-trend', tdClass: 'col-trend',
    cell: (m, { timeframe }) => <TrendCell metric={m} timeframe={timeframe} />,
  },
  status: {
    label: 'Status', thClass: 'col-status', tdClass: 'col-status',
    cell: (m) => { const st = statusOf(m); return <span className={`badge ${st}`}>{STATUS_LABELS[st]}</span>; },
  },
  owner: {
    label: 'Owner', thClass: 'col-owner', tdClass: 'col-owner owner-pill',
    cell: (m) => m.owner || '—',
  },
};

// Move `from` to occupy `to`'s slot, preserving the rest of the order.
function moveColumn(order: ColId[], from: ColId, to: ColId): ColId[] {
  const next = order.filter(c => c !== from);
  const idx = next.indexOf(to);
  next.splice(idx, 0, from);
  return next;
}

export function DataTable({ metrics, sectionTitle, onRowClick, timeframe, order, onReorder }: DataTableProps) {
  const dragId = useRef<ColId | null>(null);

  return (
    <>
      <div className="section-label mt">{sectionTitle}</div>
      <div className="data-table">
        <table>
          <thead>
            <tr>
              <th className="col-metric" style={{ width: '30%' }}>Metric</th>
              {order.map((id) => (
                <th
                  key={id}
                  className={`${COLUMNS[id].thClass} col-draggable`}
                  draggable
                  title="Drag to reorder"
                  onDragStart={(e) => { dragId.current = id; e.dataTransfer.effectAllowed = 'move'; }}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const from = dragId.current;
                    if (from && from !== id) onReorder(moveColumn(order, from, id));
                    dragId.current = null;
                  }}
                  onDragEnd={() => { dragId.current = null; }}
                >
                  {COLUMNS[id].label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {metrics.map((metric) => (
              <tr key={metric.metricId} className="metric-row" data-tour="drilldown" onClick={() => onRowClick(metric.metricId)}>
                <td className="col-metric">
                  <span className="col-metric-cell">
                    <span data-tour="pin" style={{ display: 'inline-flex' }}><ContextPinButton item={metricToContextItem(metric)} size={15} /></span>
                    {metric.name}
                  </span>
                </td>
                {order.map((id) => (
                  <td key={id} className={COLUMNS[id].tdClass}>
                    {COLUMNS[id].cell(metric, { timeframe })}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
