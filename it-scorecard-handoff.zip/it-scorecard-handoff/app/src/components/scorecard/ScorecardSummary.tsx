'use client';

import { Metric, Status } from '@/types';
import { statusCounts } from '@/lib/utils';
import { StatusFilter } from '@/stores/ui-store';

interface ScorecardSummaryProps {
  metrics: Metric[];
  activeFilter: StatusFilter;
  onFilter: (f: StatusFilter) => void;
}

interface Tile {
  key: StatusFilter;
  label: string;
  count: number;
  status?: Status;
}

export function ScorecardSummary({ metrics, activeFilter, onFilter }: ScorecardSummaryProps) {
  const c = statusCounts(metrics);

  const tiles: Tile[] = [
    { key: 'all', label: 'All Metrics', count: c.total },
    { key: 'red', label: 'At Risk', count: c.red, status: 'red' },
    { key: 'yellow', label: 'Watch', count: c.yellow, status: 'yellow' },
    { key: 'green', label: 'On Target', count: c.green, status: 'green' },
  ];
  if (c.gray > 0) tiles.push({ key: 'gray', label: 'No Data', count: c.gray, status: 'gray' });

  return (
    <div className="sc-summary" role="group" aria-label="Scorecard health summary and status filter">
      <div className="sc-summary-health">
        <div className="sc-summary-pct">{c.onTargetPct}%</div>
        <div className="sc-summary-pct-label">on target</div>
      </div>
      <div className="sc-summary-tiles">
        {tiles.map((t) => {
          const active = activeFilter === t.key;
          return (
            <button
              key={t.key}
              type="button"
              className={`sc-tile${t.status ? ' ' + t.status : ''}${active ? ' active' : ''}`}
              aria-pressed={active}
              onClick={() => onFilter(t.key === 'all' ? 'all' : (active ? 'all' : t.key))}
            >
              <span className="sc-tile-count">{t.count}</span>
              <span className="sc-tile-label">
                {t.status && <span className={`sc-tile-dot ${t.status}`} aria-hidden="true" />}
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
