'use client';

import { useState } from 'react';
import { useUIStore } from '@/stores/ui-store';
import { BRANDS } from '@/lib/brand';

const HELP_SECTIONS = [
  { title: '📊 Scorecard View', content: [
    'Switch between Card and Table view with the toggle at top-right',
    'Color-coded status: Green = On Target, Yellow = Watch, Red = At Risk, Gray = No Data',
    'The summary strip shows % on target — click a status tile to filter the scorecard',
    'Sort worst-performing metrics first with the Sort button',
    'Targets show as a uniform threshold, e.g. ">=90%" or "<=5%"',
    'Sparklines plot every month with a dot, colored by that month\'s status',
  ]},
  { title: '📋 Table & Columns', content: [
    'Columns: Current value, Target, Trend, Status, and Owner',
    'Trend column: pick a Month / Quarter / Annual window; the badge flags the worst status in that window',
    'Drag any column header to reorder — your layout is saved to your profile and follows you back',
    'Use "Reset columns" to restore the default order',
  ]},
  { title: '📈 Metric Detail Drawer', content: [
    'Click any card or table row to open the drawer',
    'Scoring band shows where the current value falls vs thresholds',
    'Plan vs Actual chart shows the full history with the target line',
    'Monthly grid shows every data point; Strategic Alignment lists linked initiatives',
    'Edit or Delete the metric right from the drawer header',
  ]},
  { title: '⚙️ Creating & Editing Metrics', content: [
    'Click "+ New Metric" to add a KPI, or "Manage Metrics" to edit/delete any of them',
    'You can also edit or delete from a metric\'s drawer',
    'The editor sets name, section, target, owner, scoring direction, percent format, and the monthly Plan/Actual grid',
    'Status (On Target / Watch / At Risk) is auto-computed from Plan vs Actual',
  ]},
  { title: '💬 Comments & Collaboration', content: [
    'Comment at the metric level, on any individual month, or on a strategic initiative',
    'When a monthly value changed, you\'ll be prompted to add a note explaining why',
    'Your name is captured automatically — no need to type it',
    'You can delete your own comments',
  ]},
  { title: '🎯 Strategic Initiatives', content: [
    'Initiatives are grouped by pillar with their linked KPIs (colored status dots)',
    'Click a KPI chip to jump to that metric in the scorecard',
    'Create, edit, link KPIs, and comment on initiatives',
  ]},
  { title: '🤖 AI Scorecard Agent', content: [
    'Click the chat bubble (bottom-right) to ask questions in natural language',
    'Get streaming answers with charts and tables over live scorecard data',
    'Attach files, and pin a metric (sparkle icon) to focus the conversation',
    'Keep multiple named sessions — search, group by date, rename, or delete them',
    'Use "Continue in CoWork" to hand a conversation off with its context',
    'Powered by AI — responses use live scorecard data',
  ]},
  { title: '✨ Take the tour', content: [
    'Click "Take a tour" in the header for a guided walkthrough of every feature',
    'It runs automatically the first time you open the app',
  ]},
];

export function HelpPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [expanded, setExpanded] = useState<number[]>([0]);
  const brand = useUIStore((s) => s.brand);

  const toggle = (i: number) => {
    setExpanded(prev => prev.includes(i) ? prev.filter(x => x !== i) : [...prev, i]);
  };

  return (
    <>
      <div className={`help-overlay${open ? ' active' : ''}`} onClick={onClose} style={{ display: open ? 'block' : 'none', position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.42)', zIndex: 149 }} />
      <div style={{
        position: 'fixed', top: 0, left: open ? 0 : '-360px', width: '340px', height: '100vh',
        background: 'var(--surface)', boxShadow: '4px 0 28px rgba(0,0,0,0.13)', zIndex: 150,
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
        transition: 'left 0.25s cubic-bezier(0.4,0,0.2,1)'
      }}>
        <div style={{ background: 'var(--header-grad)', color: '#fff', padding: '16px 18px 14px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: '15px', fontWeight: 700 }}>Getting Started</div>
            <div style={{ fontSize: '11px', opacity: 0.8, marginTop: '2px' }}>{BRANDS[brand].name} IT Scorecard</div>
          </div>
          <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.4)', borderRadius: '5px', color: '#fff', width: '26px', height: '26px', fontSize: '13px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: '12px 0 16px' }}>
          {HELP_SECTIONS.map((sec, i) => (
            <div key={i} style={{ borderBottom: '1px solid var(--border)' }}>
              <button
                onClick={() => toggle(i)}
                style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '11px 16px', background: 'none', border: 'none', textAlign: 'left', fontSize: '13px', fontWeight: 600, color: 'var(--text)', cursor: 'pointer' }}
              >
                {sec.title}
                <span style={{ marginLeft: 'auto', fontSize: '11px', color: 'var(--muted)', transition: 'transform 0.2s', transform: expanded.includes(i) ? 'rotate(0)' : 'rotate(-90deg)' }}>▾</span>
              </button>
              {expanded.includes(i) && (
                <div style={{ padding: '0 16px 14px 38px', fontSize: '12px', lineHeight: 1.55 }}>
                  <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '7px' }}>
                    {sec.content.map((item, j) => (
                      <li key={j} style={{ paddingLeft: '12px', position: 'relative' }}>
                        <span style={{ position: 'absolute', left: 0, color: 'var(--primary)', fontWeight: 700 }}>•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
