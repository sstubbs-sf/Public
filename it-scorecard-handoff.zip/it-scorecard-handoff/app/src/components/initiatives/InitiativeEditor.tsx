'use client';

import { useEffect, useMemo, useState } from 'react';
import { useMetrics } from '@/hooks/use-metrics';
import { useCreateInitiative, useUpdateInitiative } from '@/hooks/use-initiatives';
import { Initiative } from '@/types';
import { statusOf, sectionLabel } from '@/lib/utils';

const KNOWN_PILLARS = ['Trusted Partner', 'Top Quartile Performer', 'Best/ Preferred Place to Work'];

interface InitiativeEditorProps {
  open: boolean;
  mode: 'create' | 'edit';
  initiative?: Initiative | null;
  knownPillars: string[];
  knownPriorities: string[];
  onClose: () => void;
}

export function InitiativeEditor({ open, mode, initiative, knownPillars, knownPriorities, onClose }: InitiativeEditorProps) {
  const { data: metrics } = useMetrics();
  const createInit = useCreateInitiative();
  const updateInit = useUpdateInitiative();

  const [pillar, setPillar] = useState('');
  const [priority, setPriority] = useState('');
  const [activity, setActivity] = useState('');
  const [outcome, setOutcome] = useState('');
  const [owner, setOwner] = useState('');
  const [partner, setPartner] = useState('');
  const [linked, setLinked] = useState<Set<number>>(new Set());
  const [kpiFilter, setKpiFilter] = useState('');
  const [err, setErr] = useState('');

  // Reseed the form whenever the editor opens or the target initiative changes.
  useEffect(() => {
    if (!open) return;
    setPillar(initiative?.pillar || '');
    setPriority(initiative?.priority || '');
    setActivity(initiative?.activity || '');
    setOutcome(initiative?.measurableOutcome || '');
    setOwner(initiative?.owner || '');
    setPartner(initiative?.partner || '');
    setLinked(new Set(initiative?.linkedMetricIds || []));
    setKpiFilter('');
    setErr('');
  }, [open, initiative]);

  const pillarOptions = useMemo(
    () => [...new Set([...KNOWN_PILLARS, ...knownPillars])],
    [knownPillars]
  );

  const sections = useMemo(() => {
    const map = new Map<string, typeof metrics>();
    for (const m of metrics || []) {
      if (!map.has(m.section)) map.set(m.section, []);
      map.get(m.section)!.push(m);
    }
    return [...map.entries()];
  }, [metrics]);

  const filterLc = kpiFilter.trim().toLowerCase();

  const toggleMetric = (id: number) => {
    setLinked(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const saving = createInit.isPending || updateInit.isPending;
  const canSave = pillar.trim() && priority.trim() && activity.trim() && !saving;

  const handleSave = async () => {
    if (!canSave) return;
    setErr('');
    const payload = {
      pillar: pillar.trim(),
      priority: priority.trim(),
      activity: activity.trim(),
      measurableOutcome: outcome.trim(),
      owner: owner.trim(),
      partner: partner.trim(),
      linkedMetricIds: [...linked],
    };
    try {
      if (mode === 'edit' && initiative) {
        await updateInit.mutateAsync({ id: initiative.initiativeId, data: payload });
      } else {
        await createInit.mutateAsync(payload);
      }
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Save failed');
    }
  };

  const selectedMetrics = (metrics || []).filter(m => linked.has(m.metricId));

  return (
    <>
      <div className={`drawer-overlay ie-elevated${open ? ' open' : ''}`} onClick={onClose} />
      <div className={`drawer ie-elevated${open ? ' open' : ''}`} role="dialog" aria-label={mode === 'edit' ? 'Edit initiative' : 'New initiative'}>
        <div className="drawer-header" style={{ position: 'relative' }}>
          <div style={{ fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--muted)' }}>
            {mode === 'edit' ? 'Edit Initiative' : 'New Strategic Initiative'}
          </div>
          <div style={{ fontSize: '16px', fontWeight: 700, marginTop: '2px' }}>
            {mode === 'edit' ? (initiative?.activity?.slice(0, 60) || 'Initiative') : 'Add an initiative'}
          </div>
          <button className="close-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>

        <div className="drawer-body">
          <div className="ie-field">
            <label className="ie-label">Pillar <span className="ie-req">*</span></label>
            <input className="ie-input" list="ie-pillars" value={pillar} onChange={e => setPillar(e.target.value)} placeholder="Select or type a pillar" />
            <datalist id="ie-pillars">
              {pillarOptions.map(p => <option key={p} value={p} />)}
            </datalist>
          </div>

          <div className="ie-field">
            <label className="ie-label">Priority <span className="ie-req">*</span></label>
            <input className="ie-input" list="ie-priorities" value={priority} onChange={e => setPriority(e.target.value)} placeholder="Select or type a priority" />
            <datalist id="ie-priorities">
              {knownPriorities.map(p => <option key={p} value={p} />)}
            </datalist>
            <div className="ie-hint">Initiatives are grouped under their priority within a pillar.</div>
          </div>

          <div className="ie-field">
            <label className="ie-label">Activity <span className="ie-req">*</span></label>
            <textarea className="ie-input ie-textarea" value={activity} onChange={e => setActivity(e.target.value)} placeholder="What is being done?" />
          </div>

          <div className="ie-field">
            <label className="ie-label">Measurable Outcome</label>
            <textarea className="ie-input ie-textarea" value={outcome} onChange={e => setOutcome(e.target.value)} placeholder="How will success be measured?" />
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <div className="ie-field" style={{ flex: 1 }}>
              <label className="ie-label">Owner</label>
              <input className="ie-input" value={owner} onChange={e => setOwner(e.target.value)} placeholder="Owner" />
            </div>
            <div className="ie-field" style={{ flex: 1 }}>
              <label className="ie-label">Partner</label>
              <input className="ie-input" value={partner} onChange={e => setPartner(e.target.value)} placeholder="Partner (optional)" />
            </div>
          </div>

          {/* Linked KPIs */}
          <div className="ie-field">
            <label className="ie-label">Linked KPIs <span className="ie-count">{linked.size} selected</span></label>
            {selectedMetrics.length > 0 && (
              <div className="ie-chips">
                {selectedMetrics.map(m => (
                  <span key={m.metricId} className="ie-chip">
                    {m.name.length > 28 ? m.name.slice(0, 28) + '…' : m.name}
                    <button type="button" className="ie-chip-x" onClick={() => toggleMetric(m.metricId)} aria-label={`Unlink ${m.name}`}>✕</button>
                  </span>
                ))}
              </div>
            )}
            <input className="ie-input" value={kpiFilter} onChange={e => setKpiFilter(e.target.value)} placeholder="Search KPIs to link…" style={{ marginBottom: '6px' }} />
            <div className="ie-kpi-list">
              {sections.map(([section, list]) => {
                const shown = (list || []).filter(m => !filterLc || m.name.toLowerCase().includes(filterLc));
                if (shown.length === 0) return null;
                return (
                  <div key={section}>
                    <div className="ie-kpi-section">{sectionLabel(section)}</div>
                    {shown.map(m => {
                      const st = statusOf(m);
                      const checked = linked.has(m.metricId);
                      return (
                        <label key={m.metricId} className={`ie-kpi-row${checked ? ' checked' : ''}`}>
                          <input type="checkbox" checked={checked} onChange={() => toggleMetric(m.metricId)} />
                          <span className={`kpi-ref-dot ${st}`} />
                          <span className="ie-kpi-name">{m.name}</span>
                        </label>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>

          {err && <div className="ie-error">{err}</div>}
        </div>

        <div className="ie-footer">
          <button className="ie-btn ghost" onClick={onClose} disabled={saving}>Cancel</button>
          <button className="ie-btn primary" onClick={handleSave} disabled={!canSave}>
            {saving ? 'Saving…' : mode === 'edit' ? 'Save Changes' : 'Create Initiative'}
          </button>
        </div>
      </div>
    </>
  );
}
