'use client';

import { useState } from 'react';
import { useComments, useCreateComment, useDeleteComment, useCurrentUser } from '@/hooks/use-comments';
import { notifyCommentByEmail } from '@/lib/notify';
import { useToastStore } from '@/components/ui/Toast';
import { Comment } from '@/types';

type EntityType = 'metric' | 'metric_month' | 'initiative';

interface NotifyMeta {
  entityName: string;
  owner: string;
  month?: string;
  section?: string;
}

// Email notification on new comments is disconnected for now. Set
// NEXT_PUBLIC_ENABLE_COMMENT_EMAILS=true to re-enable owner email alerts (the
// /api/notify route + notify.ts remain intact).
const EMAIL_NOTIFICATIONS_ENABLED = process.env.NEXT_PUBLIC_ENABLE_COMMENT_EMAILS === 'true';

interface CommentThreadProps {
  entityType: EntityType;
  entityId: number;
  monthIndex?: number; // when set, scopes list + create to a specific month
  notify: NotifyMeta;
  placeholder?: string;
  postLabel?: string;
  emptyText?: string;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function parseWhen(raw: string): Date {
  // Snowflake's statements REST API returns TIMESTAMP_NTZ as epoch seconds
  // (e.g. "1784667803.333000000"). Handle that plus ISO strings.
  if (/^\d+(\.\d+)?$/.test(raw)) return new Date(parseFloat(raw) * 1000);
  return new Date(raw.includes('Z') || raw.includes('+') ? raw : raw + 'Z');
}

function formatWhen(raw: string): string {
  const d = parseWhen(raw);
  if (isNaN(d.getTime())) return raw;
  const now = Date.now();
  const diffMs = now - d.getTime();
  const mins = Math.round(diffMs / 60000);
  let rel: string;
  if (mins < 1) rel = 'just now';
  else if (mins < 60) rel = `${mins}m ago`;
  else if (mins < 1440) rel = `${Math.round(mins / 60)}h ago`;
  else if (mins < 10080) rel = `${Math.round(mins / 1440)}d ago`;
  else rel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const abs = d.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
  return `${rel} · ${abs}`;
}

export function CommentThread({ entityType, entityId, monthIndex, notify, placeholder, postLabel, emptyText }: CommentThreadProps) {
  const { data: allComments } = useComments(entityType, entityId);
  const { data: currentUser } = useCurrentUser();
  const createComment = useCreateComment();
  const deleteComment = useDeleteComment();
  const [text, setText] = useState('');

  const comments: Comment[] =
    monthIndex !== undefined
      ? (allComments || []).filter(c => c.monthIndex === monthIndex)
      : (allComments || []);

  const isMine = (c: Comment) =>
    !!c.commenterUsername &&
    !!currentUser?.username &&
    c.commenterUsername.toUpperCase() === currentUser.username.toUpperCase();

  const handlePost = async () => {
    if (!text.trim()) return;
    const body = text.trim();
    createComment.mutate({ entityType, entityId, monthIndex, text: body });
    if (EMAIL_NOTIFICATIONS_ENABLED) {
      // Identity for the email comes from the resolved current user (display name).
      const commenterName = currentUser?.displayName || 'A colleague';
      const sent = await notifyCommentByEmail(notify.entityName, body, commenterName, notify.owner, notify.month || '', notify.section || '');
      if (sent) useToastStore.getState().showToast(`Email sent to ${notify.owner}`);
    }
    setText('');
  };

  const handleDelete = (c: Comment) => {
    deleteComment.mutate({ commentId: c.commentId, entityType, entityId });
  };

  return (
    <div>
      {/* Comment list */}
      <div style={{ maxHeight: '200px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '10px' }}>
        {comments.length === 0 ? (
          <div style={{ fontSize: '12px', color: 'var(--muted)', fontStyle: 'italic', padding: '4px 0' }}>
            {emptyText || 'No comments yet.'}
          </div>
        ) : (
          comments.map(c => {
            const mine = isMine(c);
            return (
              <div key={c.commentId} className="cmt-item" style={{ display: 'flex', gap: '8px', background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: '6px', padding: '8px 10px' }}>
                <span className="cmt-avatar" title={c.commenter} aria-hidden="true">{initials(c.commenter)}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '3px', flexWrap: 'wrap' }}>
                    <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text)' }}>{c.commenter}</span>
                    {mine && <span className="cmt-you">You</span>}
                    <span style={{ fontSize: '10px', color: 'var(--muted)' }}>{formatWhen(c.createdAt)}</span>
                    {mine && (
                      <button
                        className="cmt-del"
                        title="Delete your comment"
                        aria-label="Delete your comment"
                        onClick={(e) => { e.stopPropagation(); handleDelete(c); }}
                        disabled={deleteComment.isPending}
                      >
                        ✕
                      </button>
                    )}
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text)', lineHeight: 1.5, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{c.commentText}</div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add comment form */}
      <div style={{ borderTop: '1px solid var(--border)', paddingTop: '10px' }}>
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder={placeholder || 'Add a comment...'}
          style={{ width: '100%', boxSizing: 'border-box', border: '1px solid var(--border)', borderRadius: '5px', padding: '6px 8px', fontSize: '12px', minHeight: '58px', resize: 'vertical', fontFamily: 'inherit', background: 'var(--bg)', display: 'block' }}
        />
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '7px', justifyContent: 'space-between' }}>
          <span className="cmt-as" title="Captured automatically from your sign-in">
            {currentUser ? (
              <>
                <span className="cmt-avatar cmt-avatar-sm" aria-hidden="true">{initials(currentUser.displayName)}</span>
                Commenting as <strong>{currentUser.displayName}</strong>
              </>
            ) : (
              'Identifying you…'
            )}
          </span>
          <button
            onClick={handlePost}
            disabled={!text.trim() || createComment.isPending}
            style={{ background: 'var(--brand-green)', color: '#fff', border: 'none', borderRadius: '5px', padding: '5px 16px', fontSize: '12px', fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap', opacity: text.trim() ? 1 : 0.5 }}
          >
            {postLabel || 'Post'}
          </button>
        </div>
      </div>
    </div>
  );
}
