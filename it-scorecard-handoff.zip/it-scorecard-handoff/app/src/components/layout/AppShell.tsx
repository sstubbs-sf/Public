'use client';

import { useEffect } from 'react';
import { MetricDrawer } from '@/components/drawer/MetricDrawer';
import { GlobalChat } from '@/components/chat/GlobalChat';
import { HelpPanel } from '@/components/help/HelpPanel';
import { MetricManager } from '@/components/manager/MetricManager';
import { MetricEditor } from '@/components/manager/MetricEditor';
import { GuidedTour } from '@/components/layout/GuidedTour';
import { ToastContainer } from '@/components/ui/Toast';
import { EscapeHandler } from '@/components/layout/EscapeHandler';
import { useUIStore } from '@/stores/ui-store';

export function AppShell({ children }: { children: React.ReactNode }) {
  const { helpOpen, toggleHelp, managerOpen, closeManager, syncBrand, startTour } = useUIStore();

  // Re-apply the persisted brand once mounted so the theme (data-brand) always
  // matches the store-driven logo, even if hydration dropped the head-script attribute.
  useEffect(() => {
    syncBrand();
  }, [syncBrand]);

  // Auto-start the guided tour once per browser (a "Take a tour" button replays it).
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!window.localStorage.getItem('scorecardTourSeen')) {
      window.localStorage.setItem('scorecardTourSeen', '1');
      const t = setTimeout(() => startTour(), 700);
      return () => clearTimeout(t);
    }
  }, [startTour]);

  return (
    <>
      <div style={{ transition: 'margin-left 0.25s cubic-bezier(0.4,0,0.2,1)', marginLeft: helpOpen ? '340px' : '0' }}>
        {children}
      </div>
      <MetricDrawer />
      <GlobalChat />
      <HelpPanel open={helpOpen} onClose={toggleHelp} />
      <MetricManager open={managerOpen} onClose={closeManager} />
      <MetricEditor />
      <GuidedTour />
      <ToastContainer />
      <EscapeHandler />
    </>
  );
}
