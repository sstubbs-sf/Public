'use client';

import { useEffect, useLayoutEffect, useState, useCallback } from 'react';
import { useUIStore } from '@/stores/ui-store';

interface TourStep {
  target?: string; // CSS selector (data-tour). Omit for a centered card.
  title: string;
  body: string;
}

// Every feature, once. View-specific steps (timeframe, column reorder) target
// elements that only exist in Table view and are auto-skipped in Cards view.
const TOUR_STEPS: TourStep[] = [
  {
    title: 'Welcome to the IT Operations Scorecard',
    body: 'A quick tour of everything you can do — tracking KPIs, drilling in, editing, commenting, and asking the AI assistant. Use Next/Back, or Skip anytime.',
  },
  {
    target: '[data-tour="summary"]',
    title: 'Health at a glance',
    body: 'See the share of metrics on target, and click any status tile (On Target / Watch / At Risk / No Data) to filter the scorecard to just those metrics.',
  },
  {
    target: '[data-tour="new-metric"]',
    title: 'Create & edit metrics',
    body: 'New Metric opens the editor: name, section, target, owner, scoring direction (higher or lower is better), a percent toggle, and a month-by-month Plan/Actual grid. Status (On Target / Watch / At Risk) is computed automatically. You can edit any metric later from here, from Manage Metrics, or from its detail drawer.',
  },
  {
    target: '[data-tour="manage"]',
    title: 'Manage all metrics',
    body: 'Manage Metrics lists every KPI in one place with per-row Edit and Delete — handy for bulk housekeeping.',
  },
  {
    target: '[data-tour="sort"]',
    title: 'Sort by risk',
    body: 'Flip to worst-performing-first to push At Risk and Watch metrics to the top.',
  },
  {
    target: '[data-tour="views"]',
    title: 'Cards or Table',
    body: 'Switch between the card grid and the data table. Cards show status color, current value, month-over-month change, the target (e.g. ">=90%"), and a sparkline with a dot at every month. The table adds sortable, reorderable columns.',
  },
  {
    target: '[data-tour="timeframe"]',
    title: 'Trend window',
    body: 'In the table, choose the trend window — Month, Quarter, or Annual. The Trend column draws the line over that window and its badge flags the worst status seen in the window (so a dip is visible even if today is green).',
  },
  {
    target: '.data-table th.col-draggable',
    title: 'Reorder columns',
    body: 'Drag any column header to reorder the table. Your layout is saved to your user profile and follows you back next time. Use "Reset columns" in the toolbar to restore the default order.',
  },
  {
    target: '[data-tour="drilldown"]',
    title: 'Drill into a metric',
    body: 'Click any card or row to open the detail drawer: a scoring band vs thresholds, the full Plan-vs-Actual chart, the monthly data grid, linked strategic initiatives, and Edit / Delete for the metric.',
  },
  {
    target: '[data-tour="drilldown"]',
    title: 'Comments & collaboration',
    body: 'Inside a metric you can comment at the metric level or on any individual month (you\'ll be prompted to note why a value changed). Strategic initiatives have their own comments too. You\'re identified automatically, and you can delete your own comments.',
  },
  {
    target: '[data-tour="pin"]',
    title: 'Pin to the assistant',
    body: 'Pin a metric\'s live data as context for the AI chat, so you can ask focused questions about exactly what you\'re looking at.',
  },
  {
    target: '[data-tour="chat"]',
    title: 'Ask the Scorecard Agent',
    body: 'Ask questions in natural language and get streaming answers, charts, and tables over live data. Attach files, keep multiple named chat sessions (searchable, grouped by date, rename/delete), and hand a conversation off to continue in CoWork.',
  },
  {
    target: '[data-tour="nav-initiatives"]',
    title: 'Strategic Initiatives',
    body: 'The Initiatives tab groups work by pillar, shows the KPIs each initiative is linked to (click a chip to jump to that metric), and lets you create, edit, link KPIs, and comment.',
  },
  {
    target: '[data-tour="help"]',
    title: 'Help is always here',
    body: 'Open the Getting Started guide anytime, or replay this tour with the "Take a tour" button.',
  },
  {
    title: "You're all set",
    body: 'That\'s the whole app. Explore freely — and use "Take a tour" in the header if you want a refresher.',
  },
];

const targetExists = (sel?: string) => !sel || (typeof document !== 'undefined' && !!document.querySelector(sel));

export function GuidedTour() {
  const { tourOpen, endTour } = useUIStore();
  const [idx, setIdx] = useState(0);
  const [rect, setRect] = useState<DOMRect | null>(null);

  // Next renderable step index from `from` moving by `dir` (skips absent targets).
  const findStep = useCallback((from: number, dir: number): number | null => {
    for (let i = from; i >= 0 && i < TOUR_STEPS.length; i += dir) {
      if (targetExists(TOUR_STEPS[i].target)) return i;
    }
    return null;
  }, []);

  useEffect(() => {
    if (tourOpen) setIdx(findStep(0, 1) ?? 0);
  }, [tourOpen, findStep]);

  const step = TOUR_STEPS[idx];

  const measure = useCallback(() => {
    const sel = TOUR_STEPS[idx]?.target;
    if (!sel) { setRect(null); return; }
    const el = document.querySelector(sel) as HTMLElement | null;
    if (!el) { setRect(null); return; }
    el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
    setRect(el.getBoundingClientRect());
  }, [idx]);

  useLayoutEffect(() => {
    if (!tourOpen) return;
    measure();
    // Re-measure shortly after to catch smooth-scroll settling.
    const t = setTimeout(measure, 320);
    return () => clearTimeout(t);
  }, [tourOpen, idx, measure]);

  useEffect(() => {
    if (!tourOpen) return;
    const reMeasure = () => {
      const sel = TOUR_STEPS[idx]?.target;
      const el = sel ? (document.querySelector(sel) as HTMLElement | null) : null;
      setRect(el ? el.getBoundingClientRect() : null);
    };
    window.addEventListener('resize', reMeasure);
    window.addEventListener('scroll', reMeasure, true);
    return () => {
      window.removeEventListener('resize', reMeasure);
      window.removeEventListener('scroll', reMeasure, true);
    };
  }, [tourOpen, idx]);

  const go = useCallback((dir: number) => {
    const next = findStep(idx + dir, dir);
    if (next === null) { if (dir > 0) endTour(); return; }
    setIdx(next);
  }, [idx, findStep, endTour]);

  useEffect(() => {
    if (!tourOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') endTour();
      else if (e.key === 'ArrowRight') go(1);
      else if (e.key === 'ArrowLeft') go(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [tourOpen, go, endTour]);

  if (!tourOpen || !step) return null;

  const renderable = TOUR_STEPS.map((_, i) => i).filter((i) => targetExists(TOUR_STEPS[i].target));
  const pos = renderable.indexOf(idx) + 1;
  const total = renderable.length;
  const isLast = idx === renderable[renderable.length - 1];
  const hasPrev = pos > 1;

  const pad = 6;
  const spot = rect
    ? { top: rect.top - pad, left: rect.left - pad, width: rect.width + pad * 2, height: rect.height + pad * 2 }
    : null;

  // Position the tooltip: below the target if there's room, else above; centered when no target.
  let popStyle: React.CSSProperties;
  if (!rect) {
    popStyle = { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' };
  } else {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const below = rect.bottom < vh * 0.62;
    const left = Math.min(Math.max(rect.left, 12), vw - 340);
    popStyle = below
      ? { top: rect.bottom + 14, left }
      : { top: rect.top - 14, left, transform: 'translateY(-100%)' };
  }

  return (
    <div className="tour-root" role="dialog" aria-modal="true">
      {spot ? (
        <div className="tour-spot" style={{ top: spot.top, left: spot.left, width: spot.width, height: spot.height }} />
      ) : (
        <div className="tour-dim" />
      )}
      <div className="tour-pop" style={popStyle}>
        <div className="tour-pop-step">Step {pos} of {total}</div>
        <div className="tour-pop-title">{step.title}</div>
        <div className="tour-pop-body">{step.body}</div>
        <div className="tour-pop-actions">
          <button className="tour-skip" onClick={endTour}>{isLast ? 'Close' : 'Skip'}</button>
          <div className="tour-nav">
            {hasPrev && <button className="tour-btn" onClick={() => go(-1)}>Back</button>}
            <button className="tour-btn primary" onClick={() => (isLast ? endTour() : go(1))}>
              {isLast ? 'Done' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
