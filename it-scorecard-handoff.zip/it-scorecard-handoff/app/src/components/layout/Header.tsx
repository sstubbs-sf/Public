'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useUIStore } from '@/stores/ui-store';
import { BRANDS } from '@/lib/brand';

export function Header() {
  const { toggleHelp, startTour } = useUIStore();
  const brandCfg = BRANDS.solventum;

  return (
    <header>
      <div className="hdr-left">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          key={brandCfg.logoSrc}
          src={brandCfg.logoSrc}
          alt={brandCfg.name}
          height={26}
          className="hdr-logo"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
            const fb = e.currentTarget.nextElementSibling as HTMLElement | null;
            if (fb) fb.style.display = 'block';
          }}
        />
        <span className="hdr-wordmark-fallback">{brandCfg.wordmark}</span>
        <div className="hdr-titles">
          <div className="hdr-title">IT Operations Scorecard</div>
          <div className="hdr-sub">IT Leadership</div>
        </div>
      </div>
      <div className="hdr-actions">
        <button className="hdr-tour-btn" onClick={startTour} title="Take a guided tour of the app">✱ Take a tour</button>
        <button className="hdr-btn" data-tour="help" onClick={toggleHelp} title="Getting Started Guide">?</button>
      </div>
    </header>
  );
}

export function TabNav() {
  const pathname = usePathname();

  return (
    <div className="tabs">
      <Link href="/scorecard" className={`tab-btn${pathname === '/scorecard' ? ' active' : ''}`}>
        Scorecard
      </Link>
      <Link href="/initiatives" data-tour="nav-initiatives" className={`tab-btn${pathname === '/initiatives' ? ' active' : ''}`}>
        Strategic Initiatives
      </Link>
    </div>
  );
}
