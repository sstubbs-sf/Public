'use client';

import { useEffect } from 'react';
import { useUIStore } from '@/stores/ui-store';

export function EscapeHandler() {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      const state = useUIStore.getState();
      // Priority order: Metric Editor → Manager → Drawer → Chat → Help
      if (state.metricEditorOpen) { state.closeMetricEditor(); return; }
      if (state.managerOpen) { state.closeManager(); return; }
      if (state.drawerOpen) { state.closeDrawer(); return; }
      if (state.chatOpen) { state.closeChatPanel(); return; }
      if (state.helpOpen) { state.toggleHelp(); return; }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, []);

  return null;
}
