'use client';

import { useUIStore } from '@/stores/ui-store';
import { useMetricById, useDeleteMetric } from '@/hooks/use-metrics';
import { useEffect } from 'react';
import { statusOf, getLatestMonth, formatValue, formatTarget } from '@/lib/utils';
import { Metric, Status } from '@/types';
import { ScoringBand } from './ScoringBand';
import { MetricChart } from './MetricChart';
import { MonthGrid } from './MonthGrid';
import { MetricComments } from './MetricComments';
import { ContextPinButton } from '@/components/chat/ContextPinButton';
import { metricToContextItem } from '@/lib/artifact-context';
import { useInitiatives } from '@/hooks/use-initiatives';

export function MetricDrawer() {
  const { drawerOpen, activeMetricId, closeDrawer, openMetricEditor } = useUIStore();
  const metric = useMetricById(activeMetricId);
  const deleteMetric = useDeleteMetric();

  useEffect(() => {
    if (drawerOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [drawerOpen]);

  if (!metric) return null;

  const status = statusOf(metric);
  const latest = getLatestMonth(metric);
  const statusLabels: Record<Status, string> = { green: 'On Target', yellow: 'Watch', red: 'At Risk', gray: 'No Data' };

  const handleEdit = () => {
    const id = metric.metricId;
    closeDrawer();
    openMetricEditor('edit', id);
  };
  const handleDelete = () => {
    if (confirm(`Delete metric "${metric.name}"?\n\nThis removes its monthly data, KPI links, and comments. This cannot be undone.`)) {
      deleteMetric.mutate(metric.metricId);
      closeDrawer();
    }
  };

  return (
    <>
      <div className={`drawer-overlay${drawerOpen ? ' open' : ''}`} onClick={closeDrawer} />
      <div className={`drawer${drawerOpen ? ' open' : ''}`}>
        <div className="drawer-header">
          <button className="close-btn" onClick={closeDrawer}>✕</button>
          <div className="d-title">
            {metric.name}
            <ContextPinButton item={metricToContextItem(metric)} />
            <MetricComments metricId={metric.metricId} metricName={metric.name} owner={metric.owner} />
          </div>
          <div className="d-actions">
            <button className="ic-act-btn" onClick={handleEdit}>✎ Edit metric</button>
            <button className="ic-act-btn danger" onClick={handleDelete} disabled={deleteMetric.isPending}>🗑 Delete</button>
          </div>
          <div className="d-kpis">
            <div className="d-kpi">
              <strong style={{ color: `var(--${status === 'gray' ? 'muted' : status})` }}>
                {latest ? formatValue(latest.actual, metric.isPercent) : '—'}
              </strong>
              <span>Latest</span>
            </div>
            <div className="d-kpi">
              <strong>{formatTarget(metric)}</strong>
              <span>Target</span>
            </div>
            <div className="d-kpi">
              <span className={`badge ${status}`}>{statusLabels[status]}</span>
            </div>
          </div>
        </div>

        <div className="drawer-body">
          <div className="d-section">
            <div className="d-section-title">Scoring</div>
            <ScoringBand metric={metric} />
          </div>

          <div className="d-section">
            <div className="d-section-title">Trend</div>
            <div className="chart-wrap">
              <MetricChart metric={metric} />
            </div>
          </div>

          <div className="d-section">
            <div className="d-section-title">Monthly Data</div>
            <MonthGrid metric={metric} />
          </div>

          <div className="d-section">
            <div className="d-section-title">Strategic Alignment</div>
            <StrategicAlignment metricId={metric.metricId} />
          </div>
        </div>
      </div>
    </>
  );
}

function StrategicAlignment({ metricId }: { metricId: number }) {
  const { data: initiatives } = useInitiatives();
  if (!initiatives) return <div style={{ fontSize: '12px', color: 'var(--muted)' }}>Loading...</div>;

  // Initiatives that actually link this KPI (real INITIATIVE_KPI_LINKS).
  const related = initiatives.filter(i => i.linkedMetricIds.includes(metricId)).slice(0, 4);

  if (related.length === 0) {
    return <div style={{ fontSize: '12px', color: 'var(--muted)' }}>No strategic initiatives linked. Use the Initiatives tab to link this KPI.</div>;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
      {related.map(init => (
        <div key={init.initiativeId} className="drawer-init-chip" style={{ display: 'flex', flexDirection: 'column', gap: '2px', padding: '7px 10px', border: '1px solid var(--border)', borderRadius: '6px', background: 'var(--surface)' }}>
          <span style={{ fontSize: '10px', fontWeight: 700, color: 'var(--brand-green)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{init.pillar}</span>
          <span style={{ fontSize: '12px', color: 'var(--text)', lineHeight: 1.4 }}>{(init.measurableOutcome || init.activity).substring(0, 120)}</span>
        </div>
      ))}
    </div>
  );
}
