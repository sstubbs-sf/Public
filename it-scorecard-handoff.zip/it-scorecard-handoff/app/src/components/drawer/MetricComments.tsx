'use client';

import { useState } from 'react';
import { useComments } from '@/hooks/use-comments';
import { CommentThread } from '@/components/comments/CommentThread';

interface MetricCommentsProps {
  metricId: number;
  metricName: string;
  owner: string;
}

export function MetricComments({ metricId, metricName, owner }: MetricCommentsProps) {
  const [open, setOpen] = useState(false);
  const { data: comments } = useComments('metric', metricId);
  const count = comments?.length || 0;

  return (
    <div>
      {/* Toggle badge */}
      <span
        className={`mc-toggle${count > 0 ? ' has-comments' : ''}`}
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', cursor: 'pointer', fontSize: '12px', color: count > 0 ? 'var(--green)' : 'var(--muted)', marginLeft: '10px', verticalAlign: 'middle', border: `1px solid ${count > 0 ? 'var(--green)' : 'var(--border)'}`, borderRadius: '12px', padding: '2px 8px' }}
      >
        <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" /></svg>
        {count || '+'}
      </span>

      {/* Expandable panel */}
      {open && (
        <div style={{ borderTop: '1px solid var(--border)', marginTop: '12px', paddingTop: '12px' }}>
          <CommentThread
            entityType="metric"
            entityId={metricId}
            notify={{ entityName: metricName, owner }}
            placeholder="Add a comment about this metric..."
            emptyText="No metric-level comments yet."
          />
        </div>
      )}
    </div>
  );
}

