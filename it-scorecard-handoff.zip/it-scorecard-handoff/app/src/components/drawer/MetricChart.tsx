'use client';

import { Metric, Status } from '@/types';
import { formatValue } from '@/lib/utils';

interface MetricChartProps {
  metric: Metric;
}

const STATUS_COLORS: Record<Status, string> = {
  green: '#16a34a',
  yellow: '#ca8a04',
  red: '#dc2626',
  gray: '#9ca3af',
};

export function MetricChart({ metric }: MetricChartProps) {
  const isPct = metric.isPercent;
  const W = 540, H = 180;
  const pad = { l: isPct ? 44 : 36, r: 12, t: 12, b: 24 };

  const planVals = metric.monthly.map(m => m.plan !== null ? (isPct ? m.plan * 100 : m.plan) : null);
  const actVals = metric.monthly.map(m => m.actual !== null ? (isPct ? m.actual * 100 : m.actual) : null);
  const statuses = metric.monthly.map(m => m.status);

  const all = [...planVals, ...actVals].filter((v): v is number => v !== null);
  if (all.length === 0) {
    return <div style={{ textAlign: 'center', fontSize: '12px', color: 'var(--muted)', padding: '20px 0' }}>No data available</div>;
  }

  let min = Math.min(...all);
  let max = Math.max(...all);
  const padY = (max - min) * 0.12 || (max * 0.1) || 1;
  min = Math.max(0, min - padY);
  max = max + padY;
  const range = max - min || 1;
  const n = metric.monthly.length - 1;

  const x = (i: number) => pad.l + (i / n) * (W - pad.l - pad.r);
  const y = (v: number) => pad.t + (1 - (v - min) / range) * (H - pad.t - pad.b);

  // Y-axis labels
  const yTicks = [min, (min + max) / 2, max];
  const yLabels = yTicks.map(v => {
    const label = isPct ? `${v.toFixed(0)}%` : (Number.isInteger(v) ? String(v) : v.toFixed(0));
    return { v, label };
  });

  // X-axis labels (every other)
  const xLabels = metric.monthly.map((m, i) => ({
    i,
    label: i % 2 === 0 ? m.monthName.slice(0, 3) : '',
  }));

  // Build plan path (dashed, single gray color)
  let planPath = '';
  let planStarted = false;
  planVals.forEach((v, i) => {
    if (v === null) { planStarted = false; return; }
    planPath += (planStarted ? 'L' : 'M') + x(i).toFixed(1) + ',' + y(v).toFixed(1) + ' ';
    planStarted = true;
  });

  // Build actual line segments — each segment colored by its ending month's status
  const actualSegments: { x1: number; y1: number; x2: number; y2: number; color: string }[] = [];
  const actualDots: { cx: number; cy: number; color: string; label: string }[] = [];

  let prevIdx = -1;
  let prevVal: number | null = null;

  actVals.forEach((v, i) => {
    if (v === null) { prevIdx = -1; prevVal = null; return; }
    const color = STATUS_COLORS[statuses[i]];
    actualDots.push({ cx: x(i), cy: y(v), color, label: `${metric.monthly[i].monthName}: ${formatValue(metric.monthly[i].actual, isPct)}` });

    if (prevIdx >= 0 && prevVal !== null) {
      actualSegments.push({
        x1: x(prevIdx), y1: y(prevVal),
        x2: x(i), y2: y(v),
        color,
      });
    }
    prevIdx = i;
    prevVal = v;
  });

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: '180px', overflow: 'visible' }}>
      {/* Grid lines */}
      {yTicks.map((v, i) => (
        <line key={i} x1={pad.l} y1={y(v)} x2={W - pad.r} y2={y(v)} stroke="var(--border)" strokeDasharray="3 3" />
      ))}

      {/* Y-axis labels */}
      {yLabels.map((yl, i) => (
        <text key={i} x={pad.l - 5} y={y(yl.v) + 3} textAnchor="end" fontSize="8" fill="#9ca3af">{yl.label}</text>
      ))}

      {/* X-axis labels */}
      {xLabels.map((xl) => xl.label ? (
        <text key={xl.i} x={x(xl.i)} y={H - 6} textAnchor="middle" fontSize="8" fill="#9ca3af">{xl.label}</text>
      ) : null)}

      {/* Plan line (dashed gray) */}
      <path d={planPath} fill="none" stroke="#9ca3af" strokeWidth="1.5" strokeDasharray="4 3" />

      {/* Actual line segments — each colored by that month's status */}
      {actualSegments.map((seg, i) => (
        <line key={i} x1={seg.x1} y1={seg.y1} x2={seg.x2} y2={seg.y2} stroke={seg.color} strokeWidth="2.2" strokeLinecap="round" />
      ))}

      {/* Actual dots */}
      {actualDots.map((dot, i) => (
        <circle key={i} cx={dot.cx} cy={dot.cy} r="3" fill={dot.color}>
          <title>{dot.label}</title>
        </circle>
      ))}

      {/* Legend */}
      <line x1={pad.l} y1={H - 0} x2={pad.l + 16} y2={H - 0} stroke="#16a34a" strokeWidth="2" />
      <text x={pad.l + 20} y={H + 1} fontSize="8" fill="#666">Actual (colored by status)</text>
      <line x1={pad.l + 160} y1={H - 0} x2={pad.l + 176} y2={H - 0} stroke="#9ca3af" strokeWidth="1.5" strokeDasharray="4 3" />
      <text x={pad.l + 180} y={H + 1} fontSize="8" fill="#666">Plan</text>
    </svg>
  );
}
