'use client';

import { Metric } from '@/types';
import { statusOf, getLatestMonth, formatValue } from '@/lib/utils';

interface ScoringBandProps {
  metric: Metric;
}

export function ScoringBand({ metric }: ScoringBandProps) {
  const status = statusOf(metric);
  const latest = getLatestMonth(metric);
  if (!latest || latest.actual === null || latest.plan === null) return null;

  const dir = metric.direction;
  const target = latest.plan;
  const actual = latest.actual;
  const fmt = (v: number) => formatValue(v, metric.isPercent);

  let z1cls: string, z2cls: string, z3cls: string;
  let z1w: string, z2w: string, z3w: string;
  let chip1: string, chip2: string, chip3: string;
  let mk: number;
  let t1pct: string, t2pct: string;
  let t1: string, t2: string;

  const greenThreshold = target;
  const yellowThreshold = dir === 'high' ? target * 0.80 : target * 1.20;

  if (dir === 'high') {
    const scale = target * 1.3;
    z1cls = 'red'; z2cls = 'yellow'; z3cls = 'green';
    z1w = (0.8 / 1.3 * 100).toFixed(1);
    z2w = (0.2 / 1.3 * 100).toFixed(1);
    z3w = (0.3 / 1.3 * 100).toFixed(1);
    mk = Math.min(actual / scale, 0.98) * 100;
    t1 = fmt(yellowThreshold); t2 = fmt(greenThreshold);
    t1pct = z1w;
    t2pct = (parseFloat(z1w) + parseFloat(z2w)).toFixed(1);
    chip1 = `≥ ${fmt(greenThreshold)}`;
    chip2 = `${fmt(yellowThreshold)} – ${fmt(greenThreshold)}`;
    chip3 = `< ${fmt(yellowThreshold)}`;
  } else {
    const scale = target * 1.5;
    z1cls = 'green'; z2cls = 'yellow'; z3cls = 'red';
    z1w = (1.0 / 1.5 * 100).toFixed(1);
    z2w = (0.2 / 1.5 * 100).toFixed(1);
    z3w = (0.3 / 1.5 * 100).toFixed(1);
    mk = Math.min(actual / scale, 0.98) * 100;
    t1 = fmt(greenThreshold); t2 = fmt(yellowThreshold);
    t1pct = z1w;
    t2pct = (parseFloat(z1w) + parseFloat(z2w)).toFixed(1);
    chip1 = `≤ ${fmt(greenThreshold)}`;
    chip2 = `${fmt(greenThreshold)} – ${fmt(yellowThreshold)}`;
    chip3 = `> ${fmt(yellowThreshold)}`;
  }

  return (
    <>
      <div className="scoring-bar-wrap">
        <div className="scoring-bar">
          <div className={`sz ${z1cls}${status === z1cls ? ' active' : ''}`} style={{ width: `${z1w}%` }} />
          <div className={`sz ${z2cls}${status === z2cls ? ' active' : ''}`} style={{ width: `${z2w}%` }} />
          <div className={`sz ${z3cls}${status === z3cls ? ' active' : ''}`} style={{ width: `${z3w}%` }} />
        </div>
        <div className="scoring-marker" style={{ left: `${mk.toFixed(1)}%` }} />
        <div className="scoring-marker-label" style={{ left: `${mk.toFixed(1)}%` }}>{fmt(actual)}</div>
        <div className="scoring-tick" style={{ left: `${t1pct}%` }}>{t1}</div>
        <div className="scoring-tick" style={{ left: `${t2pct}%` }}>{t2}</div>
      </div>
      <div className="scoring-thr-chips">
        <span className="thr-chip green">● On Target: {chip1}</span>
        <span className="thr-chip yellow">● Watch: {chip2}</span>
        <span className="thr-chip red">● At Risk: {chip3}</span>
      </div>
    </>
  );
}
