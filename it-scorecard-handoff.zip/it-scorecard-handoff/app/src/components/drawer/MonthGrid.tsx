'use client';

import { Fragment, useState } from 'react';
import { Metric } from '@/types';
import { formatValue } from '@/lib/utils';
import { useComments } from '@/hooks/use-comments';
import { CommentThread } from '@/components/comments/CommentThread';

interface MonthGridProps {
  metric: Metric;
}

export function MonthGrid({ metric }: MonthGridProps) {
  const [selectedMonth, setSelectedMonth] = useState<number | null>(null);
  const { data: allComments } = useComments('metric_month', metric.metricId);

  const getCommentCount = (monthIdx: number) => {
    if (!allComments) return 0;
    return allComments.filter(c => c.monthIndex === monthIdx).length;
  };

  const toggleMonth = (idx: number) => {
    setSelectedMonth(prev => prev === idx ? null : idx);
  };

  return (
    <div>
      <table className="mini-table">
        <thead>
          <tr>
            <th>Month</th>
            <th>Plan</th>
            <th>Actual</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {metric.monthly.map((m, i) => {
            const isHit = m.status === 'green';
            const isMiss = m.status === 'red';
            const cmtCount = getCommentCount(i);
            const isSelected = selectedMonth === i;
            return (
              <Fragment key={i}>
                <tr
                  onClick={() => toggleMonth(i)}
                  style={{ cursor: 'pointer', background: isSelected ? '#edf5ef' : undefined }}
                >
                  <td>
                    {m.monthName} {m.monthYear}
                    {cmtCount > 0 && <span className="cmt-dot active">{cmtCount}</span>}
                  </td>
                  <td>{formatValue(m.plan, metric.isPercent)}</td>
                  <td className={isMiss ? 'miss' : isHit ? 'hit' : ''}>
                    {formatValue(m.actual, metric.isPercent)}
                  </td>
                  <td>
                    <span style={{
                      display: 'inline-block', width: '8px', height: '8px', borderRadius: '50%',
                      background: m.status === 'green' ? 'var(--green)' : m.status === 'yellow' ? 'var(--yellow)' : m.status === 'red' ? 'var(--red)' : '#d1d5db'
                    }} />
                  </td>
                </tr>
                {isSelected && (
                  <tr className="month-expand-row">
                    <td colSpan={4} style={{ padding: '0 0 10px', textAlign: 'left', background: '#edf5ef', borderBottom: 'none' }}>
                      <MonthPanel
                        metric={metric}
                        monthIndex={i}
                        onClose={() => setSelectedMonth(null)}
                      />
                    </td>
                  </tr>
                )}
              </Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function MonthPanel({ metric, monthIndex, onClose }: { metric: Metric; monthIndex: number; onClose: () => void }) {
  const month = metric.monthly[monthIndex];
  const { data: allComments } = useComments('metric_month', metric.metricId);
  const [actualInput, setActualInput] = useState(
    month.actual !== null ? formatValue(month.actual, metric.isPercent) : ''
  );
  const [saveFlash, setSaveFlash] = useState('');

  const monthComments = (allComments || []).filter(c => c.monthIndex === monthIndex);
  const monthLabel = `${month.monthName} '${month.monthYear.slice(2)}`;

  const handleActualChange = () => {
    // Nudge: require a comment explaining a changed value before saving.
    if (actualInput.trim() && month.actual !== null && monthComments.length === 0) {
      setSaveFlash('Add a comment first');
      setTimeout(() => setSaveFlash(''), 2500);
      return;
    }
    setSaveFlash('Saved ✓');
    setTimeout(() => setSaveFlash(''), 2000);
  };

  return (
    <div style={{ border: '1px solid var(--border)', borderRadius: '8px', padding: '12px 14px', background: 'var(--surface)', marginTop: '8px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
        <span style={{ fontWeight: 700, fontSize: '13px', flex: 1 }}>{monthLabel}</span>
        <button onClick={onClose} style={{ border: 'none', background: 'none', cursor: 'pointer', color: 'var(--muted)', fontSize: '15px', padding: '0 4px', lineHeight: 1 }}>✕</button>
      </div>

      {/* Actual value editing */}
      <label style={{ display: 'flex', flexDirection: 'column', gap: '3px', fontSize: '11px', fontWeight: 600, color: 'var(--muted)', marginBottom: '10px' }}>
        Actual
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <input
            value={actualInput}
            onChange={e => setActualInput(e.target.value)}
            onBlur={handleActualChange}
            placeholder="Enter value"
            style={{ border: '1px solid var(--border)', borderRadius: '5px', padding: '5px 8px', fontSize: '13px', background: 'var(--bg)', width: '120px' }}
          />
          <span style={{ fontSize: '11px', color: saveFlash.includes('required') ? 'var(--red)' : 'var(--green)', fontWeight: 600, minWidth: '80px' }}>
            {saveFlash}
          </span>
        </div>
      </label>

      {/* Comment thread */}
      <div style={{ fontSize: '10px', fontWeight: 700, color: 'var(--muted)', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
        Comments ({monthComments.length})
      </div>
      <CommentThread
        entityType="metric_month"
        entityId={metric.metricId}
        monthIndex={monthIndex}
        notify={{ entityName: metric.name, owner: metric.owner, month: monthLabel, section: metric.section }}
        placeholder="What happened this month? Why was this the status?"
        postLabel="Post Comment"
        emptyText="No comments yet for this month."
      />
    </div>
  );
}
