'use client';

import { useState, useRef, useEffect } from 'react';
import { renderMarkdown, formatTimestamp } from '@/lib/markdown';
import { useUIStore } from '@/stores/ui-store';
import { useChatStore, type ThreadSummary } from '@/stores/chat-store';
import { useToastStore } from '@/components/ui/Toast';
import { AgentChart } from '@/components/chat/AgentChart';
import { SparkleIcon } from '@/components/chat/SparkleIcon';

const DAY = 86400000;
const startOfDay = (ts: number) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };

// CoWork-style recency buckets for the sessions list.
const BUCKET_ORDER = ['Today', 'Yesterday', 'Previous 7 days', 'Previous 30 days', 'Older'];
function bucketLabel(updatedOn: number): string {
  const today = startOfDay(Date.now());
  const d = startOfDay(updatedOn);
  if (d === today) return 'Today';
  if (d === today - DAY) return 'Yesterday';
  if (d > today - 7 * DAY) return 'Previous 7 days';
  if (d > today - 30 * DAY) return 'Previous 30 days';
  return 'Older';
}
function relativeTime(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < DAY) return `${Math.floor(diff / 3600000)}h ago`;
  if (diff < 7 * DAY) return `${Math.floor(diff / DAY)}d ago`;
  return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
function groupThreads(list: ThreadSummary[]): { label: string; items: ThreadSummary[] }[] {
  const groups: { label: string; items: ThreadSummary[] }[] = [];
  for (const t of list) {
    const label = bucketLabel(t.updatedOn);
    let g = groups.find((x) => x.label === label);
    if (!g) { g = { label, items: [] }; groups.push(g); }
    g.items.push(t);
  }
  return groups.sort((a, b) => BUCKET_ORDER.indexOf(a.label) - BUCKET_ORDER.indexOf(b.label));
}

export function GlobalChat() {
  const { chatOpen, chatExpanded, toggleChat, toggleChatExpand, closeChatPanel } = useUIStore();
  const {
    threads,
    activeThreadId,
    messages,
    attachments,
    contextItems,
    isStreaming,
    threadsLoading,
    loadThreads,
    newThread,
    switchThread,
    renameThread,
    deleteThread,
    uploadFiles,
    removeAttachment,
    removeContextItem,
    continueInCowork,
    send,
  } = useChatStore();

  const [input, setInput] = useState('');
  const [sessionsOpen, setSessionsOpen] = useState(false);
  const [renamingId, setRenamingId] = useState<number | null>(null);
  const [renameText, setRenameText] = useState('');
  const [sessionSearch, setSessionSearch] = useState('');
  const [menuOpenId, setMenuOpenId] = useState<number | null>(null);
  const [dragging, setDragging] = useState(false);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const msgsRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  // Load the user's threads the first time the panel opens
  useEffect(() => {
    if (chatOpen) loadThreads();
  }, [chatOpen, loadThreads]);

  useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight;
  }, [messages]);

  // Auto-grow the input textarea up to a few lines.
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 120) + 'px';
  }, [input]);

  // Close the per-session kebab menu on any outside click.
  useEffect(() => {
    if (menuOpenId === null) return;
    const onDown = (e: MouseEvent) => {
      const el = e.target as HTMLElement;
      if (!el.closest('.gchat-session-menu') && !el.closest('.gchat-kebab')) setMenuOpenId(null);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [menuOpenId]);

  const handleSend = () => {
    const text = input.trim();
    if (!text || isStreaming) return;
    setInput('');
    send(text);
  };

  const pickFiles = (list: FileList | null) => {
    if (!list || list.length === 0) return;
    uploadFiles(Array.from(list));
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    pickFiles(e.dataTransfer.files);
  };

  const uploading = attachments.some((a) => a.status === 'uploading');

  const copyMessage = async (text: string, idx: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIdx(idx);
      setTimeout(() => setCopiedIdx((c) => (c === idx ? null : c)), 1500);
    } catch {
      useToastStore.getState().showToast('Copy failed');
    }
  };

  const handleContinueInCowork = async () => {
    const res = await continueInCowork();
    if (res.empty) {
      useToastStore.getState().showToast('Pin a tile or ask something first to send to CoWork');
      return;
    }
    useToastStore
      .getState()
      .showToast(
        res.copied
          ? 'Opening CoWork — context copied; paste if it does not pre-fill'
          : 'Opening CoWork with your context'
      );
  };

  const CATEGORY_ICON: Record<string, string> = {
    text: '📄',
    spreadsheet: '📊',
    document: '📕',
    image: '🖼️',
    audio: '🎵',
  };

  const startNewChat = async () => {
    setSessionsOpen(false);
    await newThread();
  };

  const commitRename = (id: number) => {
    if (renameText.trim()) renameThread(id, renameText.trim());
    setRenamingId(null);
    setRenameText('');
  };

  const activeThread = threads.find((t) => t.threadId === activeThreadId);

  const q = sessionSearch.trim().toLowerCase();
  const filteredThreads = q ? threads.filter((t) => t.name.toLowerCase().includes(q)) : threads;
  const sessionGroups = groupThreads(filteredThreads);

  const suggestions = [
    "What's the overall IT health?",
    'Which metrics are at risk?',
    'What are the 3 IT pillars?',
    'Who owns the most metrics?',
    'How has performance trended?',
  ];

  const empty = messages.length === 0;

  return (
    <>
      {/* FAB */}
      {!chatOpen && (
        <button className="gchat-fab" data-tour="chat" onClick={toggleChat} title="Open AI assistant">
          💬
        </button>
      )}

      {/* Panel */}
      <div
        data-tour="chat"
        className={`gchat-panel${chatOpen ? ' open' : ''}${chatExpanded ? ' expanded' : ''}`}
        onDragOver={(e) => {
          e.preventDefault();
          if (!dragging) setDragging(true);
        }}
        onDragLeave={(e) => {
          if (e.currentTarget === e.target) setDragging(false);
        }}
        onDrop={onDrop}
      >
        {dragging && (
          <div className="gchat-drop">
            <div>Drop files to attach<br /><small>Any file except video</small></div>
          </div>
        )}
        <div className="gchat-hdr">
          <button
            className="gchat-icon-btn"
            onClick={() => setSessionsOpen((v) => !v)}
            title="Chat sessions"
          >
            ☰
          </button>
          <span className="gchat-agent-avatar" aria-hidden>✦</span>
          <span className="gchat-hdr-label">{activeThread?.name || 'Scorecard Agent'}</span>
          <button className="gchat-icon-btn" onClick={startNewChat} title="New chat">
            ＋
          </button>
          <button
            className="gchat-icon-btn gchat-cowork-btn"
            onClick={handleContinueInCowork}
            title="Continue in CoWork on the same agent"
          >
            ↗
          </button>
          <button className="gchat-icon-btn" onClick={toggleChatExpand} title="Expand/collapse">
            {chatExpanded ? '⊟' : '⊞'}
          </button>
          <button className="gchat-icon-btn" onClick={closeChatPanel} title="Close">
            ✕
          </button>
        </div>

        {/* Sessions drawer */}
        {sessionsOpen && (
          <div className="gchat-sessions">
            <div className="gchat-sessions-top">
              <button className="gchat-new-session" onClick={startNewChat}>＋ New chat</button>
              <input
                className="gchat-session-search"
                placeholder="Search chats…"
                value={sessionSearch}
                onChange={(e) => setSessionSearch(e.target.value)}
              />
            </div>
            <div className="gchat-sessions-list">
              {threadsLoading && <div className="gchat-sessions-empty">Loading…</div>}
              {!threadsLoading && filteredThreads.length === 0 && (
                <div className="gchat-sessions-empty">
                  {threads.length === 0 ? 'No chats yet. Start a new one.' : 'No chats match your search.'}
                </div>
              )}
              {sessionGroups.map((g) => (
                <div key={g.label} className="gchat-session-group">
                  <div className="gchat-session-group-label">{g.label}</div>
                  {g.items.map((t) => (
                    <div
                      key={t.threadId}
                      className={`gchat-session-item${t.threadId === activeThreadId ? ' active' : ''}`}
                    >
                      {renamingId === t.threadId ? (
                        <input
                          className="gchat-rename-input"
                          value={renameText}
                          autoFocus
                          onChange={(e) => setRenameText(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') commitRename(t.threadId);
                            if (e.key === 'Escape') { setRenamingId(null); setRenameText(''); }
                          }}
                          onBlur={() => commitRename(t.threadId)}
                        />
                      ) : (
                        <>
                          <button
                            className="gchat-session-main"
                            onClick={() => { switchThread(t.threadId); setSessionsOpen(false); }}
                            title={t.name}
                          >
                            <span className="gchat-session-ico" aria-hidden>💬</span>
                            <span className="gchat-session-text">
                              <span className="gchat-session-name">{t.name}</span>
                              <span className="gchat-session-time">{relativeTime(t.updatedOn)}</span>
                            </span>
                          </button>
                          <div className="gchat-session-menu-wrap">
                            <button
                              className="gchat-kebab"
                              title="More"
                              onClick={() => setMenuOpenId((id) => (id === t.threadId ? null : t.threadId))}
                            >
                              ⋯
                            </button>
                            {menuOpenId === t.threadId && (
                              <div className="gchat-session-menu">
                                <button
                                  onClick={() => {
                                    setRenamingId(t.threadId);
                                    setRenameText(t.name);
                                    setMenuOpenId(null);
                                  }}
                                >
                                  ✎ Rename
                                </button>
                                <button
                                  className="danger"
                                  onClick={() => { deleteThread(t.threadId); setMenuOpenId(null); }}
                                >
                                  🗑 Delete
                                </button>
                              </div>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="gchat-msgs" ref={msgsRef}>
          {empty && (
            <div className="gchat-welcome">
              <div className="gchat-welcome-avatar">✦</div>
              <div className="gchat-welcome-title">Scorecard Agent</div>
              <div className="gchat-welcome-sub">
                Powered by AI. I have access to all 21 metrics across IT Operations and
                Cyber Security. Ask about performance, trends, risks, or strategic alignment.
              </div>
              <div className="gchat-welcome-sugg">
                {suggestions.map((s, i) => (
                  <button key={i} className="gchat-sugg-card" onClick={() => send(s)}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) =>
            msg.role === 'user' ? (
              <div key={i} className="gchat-turn user">
                <div className="gchat-user-bubble">{msg.content}</div>
              </div>
            ) : (
              <div key={i} className="gchat-turn ai">
                <div className="gchat-ai-head">
                  <span className="gchat-ai-avatar" aria-hidden>✦</span>
                  <span className="gchat-ai-name">Scorecard Agent</span>
                </div>
                <div className="gchat-ai-body">
                  {msg.content ? (
                    <div
                      className={`gchat-ai-text${msg.streaming ? ' streaming' : ''}`}
                      dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }}
                    />
                  ) : (
                    msg.streaming && <div className="gchat-thinking"><i /><i /><i /></div>
                  )}
                  {msg.charts?.map((spec, ci) => (
                    <AgentChart key={ci} spec={spec} />
                  ))}
                  {!msg.streaming && msg.content && (
                    <div className="gchat-ai-actions">
                      <button
                        className="gchat-msg-act"
                        onClick={() => copyMessage(msg.content, i)}
                        title="Copy"
                      >
                        {copiedIdx === i ? '✓ Copied' : '⧉ Copy'}
                      </button>
                      {msg.timestamp && (
                        <span className="gchat-msg-time">{formatTimestamp(msg.timestamp)}</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )
          )}
        </div>

        {contextItems.length > 0 && (
          <div className="gchat-context">
            <span className="gchat-context-label">Context ({contextItems.length})</span>
            {contextItems.map((c) => (
              <div key={c.id} className="gchat-chip-ctx" title={`${c.kind}: ${c.label}`}>
                <span className="gchat-chip-icon gchat-chip-spark"><SparkleIcon size={12} filled /></span>
                <span className="gchat-chip-name">{c.label}</span>
                <button
                  className="gchat-chip-remove"
                  onClick={() => removeContextItem(c.id)}
                  title="Remove from context"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        {attachments.length > 0 && (
          <div className="gchat-attachments">
            {attachments.map((a) => (
              <div
                key={a.id}
                className={`gchat-chip-file ${a.status}`}
                title={a.status === 'error' ? a.error : `${a.name} (${a.category})`}
              >
                <span className="gchat-chip-icon">
                  {a.status === 'uploading' ? '⏳' : a.status === 'error' ? '⚠️' : CATEGORY_ICON[a.category] || '📄'}
                </span>
                <span className="gchat-chip-name">{a.name}</span>
                <button
                  className="gchat-chip-remove"
                  onClick={() => removeAttachment(a.id)}
                  title="Remove"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="gchat-input-row">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            style={{ display: 'none' }}
            onChange={(e) => {
              pickFiles(e.target.files);
              e.target.value = '';
            }}
          />
          <div className="gchat-input-wrap">
            <button
              className="gchat-attach"
              onClick={() => fileInputRef.current?.click()}
              title="Attach files (any type except video)"
            >
              📎
            </button>
            <textarea
              ref={taRef}
              rows={1}
              className="gchat-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={uploading ? 'Processing attachments…' : 'Ask a question…'}
              disabled={isStreaming}
            />
            <button
              className="gchat-send"
              onClick={handleSend}
              disabled={isStreaming || !input.trim()}
              title="Send"
            >
              &#9654;
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
