'use client';

import { useEffect, useRef, useState } from 'react';

// Renders a single Vega-Lite chart spec emitted by the Cortex agent.
// vega-embed is dynamically imported so it stays out of the initial bundle.
export function AgentChart({ spec }: { spec: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let view: { finalize: () => void } | null = null;
    let cancelled = false;

    (async () => {
      const el = ref.current;
      if (!el) return;
      let parsed: Record<string, unknown>;
      try {
        parsed = typeof spec === 'string' ? JSON.parse(spec) : (spec as Record<string, unknown>);
      } catch {
        setError(true);
        return;
      }
      try {
        const embed = (await import('vega-embed')).default;
        if (cancelled || !ref.current) return;
        // Responsive width; strip any fixed width the agent may have set.
        const chartSpec = { ...parsed, width: 'container' } as Record<string, unknown>;
        const result = await embed(ref.current, chartSpec as never, {
          actions: false,
          renderer: 'svg',
          config: {
            background: 'transparent',
            font: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            axis: { labelColor: '#5a7060', titleColor: '#5a7060', gridColor: '#eef2ee' },
          },
        });
        view = result.view;
      } catch {
        if (!cancelled) setError(true);
      }
    })();

    return () => {
      cancelled = true;
      if (view) {
        try {
          view.finalize();
        } catch { /* noop */ }
      }
    };
  }, [spec]);

  if (error) return null;
  return <div className="gchat-chart" ref={ref} />;
}
