// Shared AI sparkle icon used by the context toggle (on cards) and the
// pinned-context chips in the chat panel, so the metaphor is consistent.
export function SparkleIcon({ size = 16, filled = false }: { size?: number; filled?: boolean }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? 'currentColor' : 'none'}
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {/* AI sparkle */}
      <path d="M12 3l1.6 4.9a3 3 0 0 0 1.9 1.9L20.4 11.4l-4.9 1.6a3 3 0 0 0-1.9 1.9L12 19.8l-1.6-4.9a3 3 0 0 0-1.9-1.9L3.6 11.4l4.9-1.6a3 3 0 0 0 1.9-1.9z" />
      {/* small twinkles */}
      <path d="M19 4.5v2M20 5.5h-2" stroke="currentColor" fill="none" />
      <path d="M5 17v1.6M5.8 17.8H4.2" stroke="currentColor" fill="none" />
    </svg>
  );
}
