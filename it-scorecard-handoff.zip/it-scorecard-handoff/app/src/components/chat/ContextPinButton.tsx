'use client';

import { useChatStore } from '@/stores/chat-store';
import { useToastStore } from '@/components/ui/Toast';
import { SparkleIcon } from '@/components/chat/SparkleIcon';
import type { ContextItem } from '@/types';

interface ContextPinButtonProps {
  item: ContextItem;
  size?: number;
  className?: string;
}

// Modern "add to context" toggle using an AI sparkle icon.
// Default: muted sparkle outline. Active: filled accent sparkle.
export function ContextPinButton({ item, size = 16, className }: ContextPinButtonProps) {
  const contextItems = useChatStore((s) => s.contextItems);
  const toggleContextItem = useChatStore((s) => s.toggleContextItem);
  const active = contextItems.some((c) => c.id === item.id);

  const onClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleContextItem(item);
    useToastStore
      .getState()
      .showToast(active ? `Removed “${item.label}” from chat context` : `Added “${item.label}” to chat context`);
  };

  return (
    <button
      type="button"
      onClick={onClick}
      className={`ctx-pin${active ? ' active' : ''}${className ? ' ' + className : ''}`}
      title={active ? 'Remove from chat context' : 'Add to chat context'}
      aria-pressed={active}
    >
      <SparkleIcon size={size} filled={active} />
    </button>
  );
}
