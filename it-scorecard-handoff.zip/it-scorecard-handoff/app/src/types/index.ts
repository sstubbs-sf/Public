export type Status = 'green' | 'yellow' | 'red' | 'gray';

export interface MonthData {
  monthIndex: number;
  monthName: string;
  monthYear: string;
  plan: number | null;
  actual: number | null;
  status: Status;
}

export interface Metric {
  metricId: number;
  name: string;
  section: string;
  targetDescription: string;
  owner: string;
  direction: 'high' | 'low';
  isPercent: boolean;
  monthly: MonthData[];
}

export interface Initiative {
  initiativeId: number;
  pillar: string;
  priority: string;
  activity: string;
  measurableOutcome: string;
  owner: string;
  partner: string;
  linkedMetricIds: number[];
}

export interface Comment {
  commentId: number;
  entityType: 'metric_month' | 'metric' | 'initiative';
  entityId: number;
  monthIndex: number | null;
  commentText: string;
  commenter: string;
  commenterUsername?: string | null;
  createdAt: string;
}

export interface AgentMessage {
  role: 'user' | 'assistant';
  content: string;
  charts?: string[];
  timestamp?: Date;
  streaming?: boolean;
}

export type AttachmentCategory =
  | 'text'
  | 'spreadsheet'
  | 'document'
  | 'image'
  | 'audio';

export type AttachmentStatus = 'uploading' | 'ready' | 'error';

export interface Attachment {
  id: string;
  name: string;
  category: AttachmentCategory;
  status: AttachmentStatus;
  sizeBytes: number;
  extractedText?: string;
  error?: string;
}

// An on-screen scorecard artifact (metric or initiative) pinned as chat context.
export interface ContextItem {
  id: string; // stable key, e.g. "metric:12" | "initiative:3"
  kind: 'metric' | 'initiative';
  label: string; // short display name for the chip
  text: string; // serialized content injected into the agent context
}
