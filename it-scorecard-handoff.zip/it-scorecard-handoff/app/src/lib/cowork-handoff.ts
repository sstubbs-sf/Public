import type { AgentMessage, ContextItem, Attachment } from '@/types';

// Snowflake CoWork (https://ai.snowflake.com) direct link to the Scorecard agent.
// Set NEXT_PUBLIC_COWORK_URL to your account's agent deep link to enable the
// "Continue in CoWork" button, e.g.
//   https://ai.snowflake.com/<ORG>/<ACCOUNT>/#/agents/ITSCORECARD.ITSCORECARD_DEMO.SCORECARD_AGENT
// When unset, the button copies the prompt to the clipboard instead of opening a tab.
export const COWORK_BASE_URL = process.env.NEXT_PUBLIC_COWORK_URL || '';
export const COWORK_PROMPT_PARAM =
  process.env.NEXT_PUBLIC_COWORK_PROMPT_PARAM ?? 'prompt';

// Overall cap for the handoff prompt (URL length + readability).
const PROMPT_CAP = 8000;
const MSG_CAP = 3500; // budget for the conversation recap
const PER_MSG_CAP = 600;

function truncate(text: string, cap: number): string {
  if (text.length <= cap) return text;
  return text.slice(0, cap) + ` …[truncated]`;
}

interface HandoffInput {
  messages: AgentMessage[];
  contextItems: ContextItem[];
  attachments: Attachment[];
}

/**
 * Build a single self-contained prompt that carries the session's discussed
 * context, the pinned scorecard tiles, and any uploaded-file context into CoWork
 * so the user can continue the investigation on the same agent.
 */
export function buildCoworkPrompt({ messages, contextItems, attachments }: HandoffInput): string {
  const parts: string[] = [];

  // 1) Conversation recap (most recent last)
  const convo = messages
    .filter((m) => m.content?.trim())
    .map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${truncate(m.content.trim(), PER_MSG_CAP)}`);
  if (convo.length) {
    parts.push('Conversation so far:\n' + truncate(convo.join('\n'), MSG_CAP));
  }

  // 2) Pinned scorecard tiles
  if (contextItems.length) {
    const tiles = contextItems.map((c) => `--- ${c.kind.toUpperCase()}: ${c.label} ---\n${c.text}`);
    parts.push('Pinned scorecard context:\n' + tiles.join('\n\n'));
  }

  // 3) Uploaded-file context
  const files = attachments.filter((a) => a.status === 'ready' && a.extractedText);
  if (files.length) {
    const blocks = files.map((a) => `--- FILE: ${a.name} (${a.category}) ---\n${a.extractedText}`);
    parts.push('Uploaded files:\n' + blocks.join('\n\n'));
  }

  const header =
    'I was investigating IT Scorecard metrics in another tool and want to continue here. ' +
    'Use the context below to help me continue the investigation.';
  const footer = 'Based on the above, what should I look at next?';

  const body = truncate(parts.join('\n\n'), PROMPT_CAP - header.length - footer.length - 8);
  return `${header}\n\n${body}\n\n${footer}`;
}

/** Build the CoWork URL, appending the prompt into the hash route when enabled. */
export function buildCoworkUrl(prompt: string): string {
  if (!COWORK_BASE_URL) return '';
  if (!COWORK_PROMPT_PARAM) return COWORK_BASE_URL;
  const sep = COWORK_BASE_URL.includes('?') ? '&' : '?';
  return `${COWORK_BASE_URL}${sep}${COWORK_PROMPT_PARAM}=${encodeURIComponent(prompt)}`;
}
