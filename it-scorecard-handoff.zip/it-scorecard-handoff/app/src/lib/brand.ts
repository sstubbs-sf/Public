// Central brand configuration.
// Data content (metrics, owners) is unaffected — only chrome/branding.

export type BrandMode = 'solventum';

export const BRAND_KEY = 'scorecardBrand';
export const DEFAULT_BRAND: BrandMode = 'solventum';

export interface BrandConfig {
  /** Company name used in titles/email (e.g. "Solventum IT Scorecard"). */
  name: string;
  /** Header logo asset (white variant for the colored header). */
  logoSrc: string;
  /** Lowercase wordmark shown next to / as fallback for the logo. */
  wordmark: string;
}

export const BRANDS: Record<BrandMode, BrandConfig> = {
  solventum: {
    name: 'Solventum',
    logoSrc: '/solventum-logo-horz-white.svg',
    wordmark: 'solventum',
  },
};

export function isBrandMode(v: unknown): v is BrandMode {
  return v === 'solventum';
}

/** Read the persisted brand from localStorage (client only). */
export function readStoredBrand(): BrandMode {
  if (typeof window === 'undefined') return DEFAULT_BRAND;
  const v = window.localStorage.getItem(BRAND_KEY);
  return isBrandMode(v) ? v : DEFAULT_BRAND;
}
