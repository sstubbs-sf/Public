import type { Metric, Initiative, ContextItem } from '@/types';
import { statusOf, getLatestMonth, formatValue, statusLabel, latestMonthLabel } from './utils';

// Pure serializers that turn on-screen scorecard artifacts into compact text
// blocks for the agent context. No React / server deps.

export function metricContextId(metricId: number): string {
  return `metric:${metricId}`;
}

export function initiativeContextId(initiativeId: number): string {
  return `initiative:${initiativeId}`;
}

function serializeMetric(m: Metric): string {
  const latest = getLatestMonth(m);
  const lines: string[] = [];
  lines.push(`Metric: ${m.name}`);
  lines.push(`Section: ${m.section}`);
  if (m.owner) lines.push(`Owner: ${m.owner}`);
  lines.push(`Target: ${m.targetDescription} (better when ${m.direction === 'high' ? 'higher' : 'lower'})`);
  lines.push(`Status: ${statusLabel(statusOf(m))}`);
  if (latest) {
    lines.push(`Latest actual: ${formatValue(latest.actual, m.isPercent)} (${latestMonthLabel(m)})`);
  }
  const series = m.monthly
    .filter((mo) => mo.plan !== null || mo.actual !== null)
    .map(
      (mo) =>
        `${mo.monthName} ${mo.monthYear}: plan=${formatValue(mo.plan, m.isPercent)}, actual=${formatValue(mo.actual, m.isPercent)}, status=${mo.status}`
    );
  if (series.length) {
    lines.push('Monthly plan vs actual:');
    lines.push(...series);
  }
  return lines.join('\n');
}

function serializeInitiative(i: Initiative): string {
  const lines: string[] = [];
  lines.push(`Initiative activity: ${i.activity}`);
  lines.push(`Pillar: ${i.pillar}`);
  if (i.priority) lines.push(`Priority: ${i.priority}`);
  if (i.measurableOutcome) lines.push(`Measurable outcome: ${i.measurableOutcome}`);
  if (i.owner) lines.push(`Owner: ${i.owner}`);
  if (i.partner) lines.push(`Partner: ${i.partner}`);
  return lines.join('\n');
}

export function metricToContextItem(m: Metric): ContextItem {
  return {
    id: metricContextId(m.metricId),
    kind: 'metric',
    label: m.name,
    text: serializeMetric(m),
  };
}

export function initiativeToContextItem(i: Initiative): ContextItem {
  const label = i.activity.length > 40 ? i.activity.slice(0, 40) + '…' : i.activity;
  return {
    id: initiativeContextId(i.initiativeId),
    kind: 'initiative',
    label,
    text: serializeInitiative(i),
  };
}
