import type { AttachmentCategory } from '@/types';

// Pure, dependency-free file-type helpers. Safe to import from both client
// (chat store / components) and server (extraction route). Do NOT add server-only
// imports here.

const TEXT_EXT = new Set([
  'txt', 'md', 'markdown', 'csv', 'tsv', 'json', 'jsonl', 'ndjson', 'xml', 'yaml',
  'yml', 'log', 'ini', 'cfg', 'conf', 'toml', 'env', 'properties',
  // source code
  'sql', 'py', 'js', 'jsx', 'ts', 'tsx', 'java', 'c', 'cpp', 'h', 'hpp', 'cs',
  'go', 'rs', 'rb', 'php', 'sh', 'bash', 'zsh', 'ps1', 'r', 'scala', 'kt', 'swift',
  'html', 'htm', 'css', 'scss', 'less', 'vue', 'svelte', 'graphql', 'proto',
]);
const SPREADSHEET_EXT = new Set(['xlsx', 'xls', 'xlsm', 'xlsb', 'ods']);
const DOCUMENT_EXT = new Set(['pdf', 'docx', 'doc', 'pptx', 'ppt', 'rtf', 'eml', 'odt', 'odp']);
const IMAGE_EXT = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'tif', 'tiff', 'heic', 'heif']);
const AUDIO_EXT = new Set(['mp3', 'wav', 'm4a', 'flac', 'ogg', 'oga', 'aac', 'wma', 'weba']);
const VIDEO_EXT = new Set(['mp4', 'mov', 'avi', 'mkv', 'wmv', 'flv', 'webm', 'm4v', 'mpeg', 'mpg', '3gp']);

export function fileExtension(name: string): string {
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i + 1).toLowerCase() : '';
}

export type Classification =
  | { supported: true; category: AttachmentCategory }
  | { supported: false; reason: string };

export function classify(name: string): Classification {
  const ext = fileExtension(name);
  if (VIDEO_EXT.has(ext)) return { supported: false, reason: 'Video files are not supported.' };
  if (TEXT_EXT.has(ext)) return { supported: true, category: 'text' };
  if (SPREADSHEET_EXT.has(ext)) return { supported: true, category: 'spreadsheet' };
  if (DOCUMENT_EXT.has(ext)) return { supported: true, category: 'document' };
  if (IMAGE_EXT.has(ext)) return { supported: true, category: 'image' };
  if (AUDIO_EXT.has(ext)) return { supported: true, category: 'audio' };
  // Unknown/binary: treat as document so AI_PARSE_DOCUMENT can attempt it.
  return { supported: true, category: 'document' };
}

// Cap the extracted text stored per file so a single upload can't blow the
// per-turn context budget. The store applies a further global cap at send time.
export const PER_FILE_CHAR_CAP = 60_000;

export function truncate(text: string, cap = PER_FILE_CHAR_CAP): string {
  if (text.length <= cap) return text;
  return text.slice(0, cap) + `\n\n[...truncated ${text.length - cap} characters...]`;
}
