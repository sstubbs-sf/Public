import { readFileSync } from 'fs';
import { SF_WAREHOUSE } from '@/lib/config';

interface QueryOptions {
  callersRights?: boolean;
  callerToken?: string;
  warehouse?: string;
  role?: string;
}

/**
 * Read the SPCS ingress user token forwarded by Snowflake when the service is
 * created with `executeAsCaller: true` (Path B). This is OFF by default: the app
 * runs on App Runtime (no caller's rights), so we must NOT concatenate a user
 * token onto the service token or auth would fail. Set ENABLE_CALLERS_RIGHTS=true
 * only on an executeAsCaller SPCS service.
 */
export function getCallerToken(req: Request): string | undefined {
  if (process.env.ENABLE_CALLERS_RIGHTS !== 'true') return undefined;
  return req.headers.get('sf-context-current-user-token') ?? undefined;
}

/**
 * The authenticated user accessing the app. On SPCS ingress Snowflake forwards
 * the `Sf-Context-Current-User` header (the login name) on every request to a
 * public endpoint — this works WITHOUT caller's rights. It's the only reliable
 * source of the accessing user, since the service itself runs as the service
 * user (so CURRENT_USER() would return the service account in SPCS).
 *
 * Returns the raw login name, or undefined when the header is absent (local dev).
 */
export function getCurrentUserLogin(req: Request): string | undefined {
  const v = req.headers.get('sf-context-current-user');
  return v && v.trim() ? v.trim() : undefined;
}

/**
 * Resolve an accessing user's login + friendly display name.
 * - SPCS: use the forwarded header for the login name.
 * - Local dev (no header): fall back to SELECT CURRENT_USER() (the PAT user).
 *   NOTE: never fall back to CURRENT_USER() in SPCS — it returns the service user.
 * Friendly name comes from SNOWFLAKE.ACCOUNT_USAGE.USERS (cached in-process).
 */
export async function getCurrentUser(req: Request): Promise<{ username: string; displayName: string }> {
  let login = getCurrentUserLogin(req);
  if (!login) {
    // Local dev only: derive from the session identity.
    if (!process.env.SNOWFLAKE_HOST) {
      try {
        const rows = await querySnowflake<{ USER: string }[]>('SELECT CURRENT_USER() AS USER');
        login = rows[0]?.USER || undefined;
      } catch {
        // ignore
      }
    }
  }
  if (!login) return { username: 'unknown', displayName: 'Unknown User' };
  const displayName = await resolveDisplayName(login);
  return { username: login, displayName };
}

// In-process cache of login -> friendly display name. ACCOUNT_USAGE has latency
// and won't include brand-new users, so we always fall back to the login name.
const displayNameCache = new Map<string, string>();

export async function resolveDisplayName(login: string): Promise<string> {
  const key = login.toUpperCase();
  const cached = displayNameCache.get(key);
  if (cached) return cached;
  let display = login;
  try {
    const rows = await querySnowflake<{ FRIENDLY: string }[]>(
      `SELECT COALESCE(
                NULLIF(TRIM(COALESCE(FIRST_NAME,'') || ' ' || COALESCE(LAST_NAME,'')), ''),
                NULLIF(DISPLAY_NAME, ''),
                NAME
              ) AS FRIENDLY
         FROM SNOWFLAKE.ACCOUNT_USAGE.USERS
        WHERE NAME = ? AND DELETED_ON IS NULL
        LIMIT 1`,
      { '1': { type: 'TEXT', value: login } }
    );
    if (rows[0]?.FRIENDLY) display = rows[0].FRIENDLY;
  } catch {
    // ACCOUNT_USAGE not reachable or no row — keep login name.
  }
  displayNameCache.set(key, display);
  return display;
}

interface SnowflakeRow {
  [key: string]: unknown;
}

function getAccountUrl(): string {
  // SPCS: use the internal host Snowflake provides (avoids external egress)
  if (process.env.SNOWFLAKE_HOST) return `https://${process.env.SNOWFLAKE_HOST}`;
  // Local dev only: set SNOWFLAKE_ACCOUNT_URL in .env (e.g. https://<account>.snowflakecomputing.com)
  return process.env.SNOWFLAKE_ACCOUNT_URL || '';
}

function getToken(callersRights?: boolean, callerToken?: string): string {
  // SPCS: read service token from mounted path
  if (process.env.SNOWFLAKE_HOST) {
    try {
      const serviceToken = readFileSync('/snowflake/session/token', 'utf-8').trim();
      if (callersRights && callerToken) {
        return serviceToken + '.' + callerToken;
      }
      return serviceToken;
    } catch {
      // Fall through to env vars
    }
  }
  // Local dev: use PAT or OAuth token from environment
  return process.env.SNOWFLAKE_TOKEN || process.env.SF_PAT || '';
}

function getTokenType(): string {
  if (process.env.SNOWFLAKE_HOST) return 'OAUTH';
  if (process.env.SNOWFLAKE_TOKEN) return 'OAUTH';
  return 'PROGRAMMATIC_ACCESS_TOKEN';
}

export async function querySnowflake<T = SnowflakeRow[]>(
  sql: string,
  bindings?: Record<string, { type: string; value: string }>,
  options?: QueryOptions
): Promise<T> {
  const token = getToken(options?.callersRights, options?.callerToken);
  if (!token) throw new Error('No Snowflake auth token available');

  const resp = await fetch(`${getAccountUrl()}/api/v2/statements`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-Snowflake-Authorization-Token-Type': getTokenType(),
    },
    body: JSON.stringify({
      statement: sql,
      ...(bindings && { bindings }),
      warehouse: options?.warehouse || SF_WAREHOUSE,
      ...(options?.role && { role: options.role }),
    }),
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`Snowflake query failed (${resp.status}): ${errText.substring(0, 200)}`);
  }

  const data = await resp.json();

  // Parse Snowflake REST API response format into row objects
  if (!data.data || !data.resultSetMetaData?.rowType) {
    return [] as unknown as T;
  }

  const columns = data.resultSetMetaData.rowType.map((col: { name: string }) => col.name);
  const rows: SnowflakeRow[] = data.data.map((row: string[]) => {
    const obj: SnowflakeRow = {};
    columns.forEach((col: string, i: number) => {
      obj[col] = row[i];
    });
    return obj;
  });

  return rows as unknown as T;
}

export async function querySnowflakeLongRunning<T = SnowflakeRow[]>(
  sql: string,
  bindings?: Record<string, { type: string; value: string }>,
  options?: QueryOptions
): Promise<T> {
  const token = getToken(options?.callersRights, options?.callerToken);
  if (!token) throw new Error('No Snowflake auth token available');

  const resp = await fetch(`${getAccountUrl()}/api/v2/statements`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-Snowflake-Authorization-Token-Type': getTokenType(),
    },
    body: JSON.stringify({
      statement: sql,
      ...(bindings && { bindings }),
      warehouse: options?.warehouse || SF_WAREHOUSE,
      ...(options?.role && { role: options.role }),
      timeout: 300,
    }),
  });

  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`Snowflake query failed (${resp.status}): ${errText.substring(0, 200)}`);
  }

  const data = await resp.json();

  // Handle async execution — poll for results
  if (data.statementStatusUrl) {
    return await pollForResults<T>(data.statementStatusUrl, token);
  }

  if (!data.data || !data.resultSetMetaData?.rowType) {
    return [] as unknown as T;
  }

  const columns = data.resultSetMetaData.rowType.map((col: { name: string }) => col.name);
  const rows: SnowflakeRow[] = data.data.map((row: string[]) => {
    const obj: SnowflakeRow = {};
    columns.forEach((col: string, i: number) => {
      obj[col] = row[i];
    });
    return obj;
  });

  return rows as unknown as T;
}

async function pollForResults<T>(statusUrl: string, token: string): Promise<T> {
  const maxAttempts = 60;
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise(resolve => setTimeout(resolve, 2000));
    const resp = await fetch(`${getAccountUrl()}${statusUrl}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'X-Snowflake-Authorization-Token-Type': getTokenType(),
      },
    });
    const data = await resp.json();
    if (data.statementStatusUrl) continue; // Still running
    if (!data.data || !data.resultSetMetaData?.rowType) return [] as unknown as T;

    const columns = data.resultSetMetaData.rowType.map((col: { name: string }) => col.name);
    const rows = data.data.map((row: string[]) => {
      const obj: SnowflakeRow = {};
      columns.forEach((col: string, i: number) => { obj[col] = row[i]; });
      return obj;
    });
    return rows as unknown as T;
  }
  throw new Error('Query timed out after polling');
}
