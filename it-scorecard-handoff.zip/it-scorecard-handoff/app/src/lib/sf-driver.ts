import { readFileSync } from 'fs';
import snowflake, { type Connection } from 'snowflake-sdk';
import { OBJ, SF_WAREHOUSE } from '@/lib/config';

// Named internal stage that holds transient chat uploads before Cortex processing.
export const CHAT_UPLOADS_STAGE = OBJ.CHAT_UPLOADS_STAGE;

// The app's REST client (src/lib/snowflake.ts) can run SQL but the Snowflake SQL
// REST API cannot PUT local files to a stage, and its statement endpoint goes
// async for long (>45s) AI calls without a reliable poller. The snowflake-sdk
// driver handles both: PUT-to-stage AND long-running extraction queries (it waits
// for completion regardless of duration). This module owns that driver path.

// The driver opens background sockets (OCSP / telemetry) that can emit ECONNRESET
// AFTER we've already destroyed the connection. In a long-running node server
// (SPCS `node server.js`) an unhandled 'error'/'aborted' would crash the process,
// so swallow exactly those benign socket resets once at module load.
declare global {
  // eslint-disable-next-line no-var
  var __sfDriverGuard: boolean | undefined;
}
if (!global.__sfDriverGuard) {
  global.__sfDriverGuard = true;
  process.on('uncaughtException', (err: NodeJS.ErrnoException) => {
    if (err && (err.code === 'ECONNRESET' || err.message === 'aborted')) {
      // benign background socket reset from snowflake-sdk — ignore
      return;
    }
    throw err;
  });
}

function getAccount(): string {
  if (process.env.SNOWFLAKE_ACCOUNT) return process.env.SNOWFLAKE_ACCOUNT;
  // Derive from the external account URL used elsewhere in the app.
  const url = process.env.SNOWFLAKE_ACCOUNT_URL || '';
  return url.replace(/^https?:\/\//, '').split('.')[0];
}

function connectionOptions(): snowflake.ConnectionOptions {
  const account = getAccount();
  const base = { account, warehouse: SF_WAREHOUSE };

  // SPCS: authenticate with the mounted OAuth service token against the internal host.
  if (process.env.SNOWFLAKE_HOST) {
    const token = readFileSync('/snowflake/session/token', 'utf-8').trim();
    return { ...base, host: process.env.SNOWFLAKE_HOST, authenticator: 'OAUTH', token } as snowflake.ConnectionOptions;
  }

  // Local dev: OAuth token env var, else a programmatic access token (PAT).
  if (process.env.SNOWFLAKE_TOKEN) {
    return { ...base, authenticator: 'OAUTH', token: process.env.SNOWFLAKE_TOKEN } as snowflake.ConnectionOptions;
  }

  return {
    ...base,
    username: process.env.SNOWFLAKE_USER || '',
    authenticator: 'PROGRAMMATIC_ACCESS_TOKEN',
    token: process.env.SF_PAT || '',
  } as snowflake.ConnectionOptions;
}

function connectOnce(): Promise<Connection> {
  const conn = snowflake.createConnection(connectionOptions());
  return new Promise((resolve, reject) => {
    conn.connect((err, c) => (err ? reject(err) : resolve(c)));
  });
}

function execVoid(conn: Connection, sqlText: string): Promise<void> {
  return new Promise((resolve, reject) => {
    conn.execute({ sqlText, complete: (err) => (err ? reject(err) : resolve()) });
  });
}

function execRows(
  conn: Connection,
  sqlText: string,
  binds?: (string | number)[]
): Promise<Array<Record<string, unknown>>> {
  return new Promise((resolve, reject) => {
    conn.execute({
      sqlText,
      binds,
      complete: (err, _stmt, rows) => (err ? reject(err) : resolve(rows ?? [])),
    });
  });
}

function destroy(conn: Connection): Promise<void> {
  return new Promise((resolve) => {
    try {
      conn.destroy(() => resolve());
    } catch {
      resolve();
    }
  });
}

/**
 * PUT a local file to CHAT_UPLOADS, then run the provided extraction SQL against
 * the staged file — all on one short-lived driver connection. `buildSql` receives
 * the stage-relative path and returns { sqlText, binds } for a single-column query;
 * the first column of the first row is returned as the extracted text.
 */
export async function stageAndExtract(
  localPath: string,
  subdir: string,
  basename: string,
  buildSql: (stagePath: string) => { sqlText: string; binds?: (string | number)[] }
): Promise<string> {
  const conn = await connectOnce();
  try {
    const dest = `@${CHAT_UPLOADS_STAGE}/${subdir}`;
    await execVoid(conn, `PUT 'file://${localPath}' '${dest}' AUTO_COMPRESS=FALSE OVERWRITE=TRUE`);

    const stagePath = `${subdir}/${basename}`;
    const { sqlText, binds } = buildSql(stagePath);
    const rows = await execRows(conn, sqlText, binds);
    if (!rows.length) return '';
    const row = rows[0];
    const val = row[Object.keys(row)[0]];
    return val == null ? '' : String(val);
  } finally {
    await destroy(conn);
  }
}
