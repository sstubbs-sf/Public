import { CHAT_UPLOADS_STAGE, stageAndExtract } from './sf-driver';
import { truncate } from './file-types';
import type { AttachmentCategory } from '@/types';

// Server-only Cortex extraction for staged binary files (document / image / audio).
// Text and spreadsheet files are handled client-side and never reach this module.
// Execution runs on the snowflake-sdk driver (see sf-driver.ts) so long-running AI
// calls (transcription/parse can exceed the REST API's 45s inline threshold) still
// complete reliably.

const TO_FILE = `TO_FILE('@${CHAT_UPLOADS_STAGE}', ?)`;

type BinaryCategory = Extract<AttachmentCategory, 'document' | 'image' | 'audio'>;

const IMAGE_PROMPT =
  'Extract and describe ALL content in this image so it can be used as reference ' +
  'context: transcribe any text verbatim, describe tables/charts/figures and their ' +
  'values, and summarize what the image shows. Respond with the content only.';

function buildSql(category: BinaryCategory, stagePath: string): { sqlText: string; binds: string[] } {
  if (category === 'document') {
    return {
      sqlText: `SELECT AI_PARSE_DOCUMENT(${TO_FILE}, {'mode': 'LAYOUT'}):content::string AS TXT`,
      binds: [stagePath],
    };
  }
  if (category === 'image') {
    return {
      sqlText: `SELECT AI_COMPLETE('pixtral-large', PROMPT(? || ' {0}', ${TO_FILE})) AS TXT`,
      binds: [IMAGE_PROMPT, stagePath],
    };
  }
  // audio
  return {
    sqlText: `SELECT AI_TRANSCRIBE(${TO_FILE}):text::string AS TXT`,
    binds: [stagePath],
  };
}

/**
 * Stage a local binary file and run the category-appropriate Cortex extraction.
 * Returns truncated extracted text.
 */
export async function extractBinaryFile(
  category: BinaryCategory,
  localPath: string,
  subdir: string,
  basename: string
): Promise<string> {
  const text = await stageAndExtract(localPath, subdir, basename, (stagePath) =>
    buildSql(category, stagePath)
  );
  return truncate(text.trim());
}
