import { Metric, MonthData, Status } from '@/types';

export function statusOf(metric: Metric): Status {
  const latest = getLatestMonth(metric);
  if (!latest || latest.actual === null) return 'gray';
  return latest.status || 'gray';
}

export function getLatestMonth(metric: Metric): MonthData | null {
  const withActual = metric.monthly.filter(m => m.actual !== null);
  return withActual.length > 0 ? withActual[withActual.length - 1] : null;
}

export function formatValue(value: number | null, isPercent: boolean): string {
  if (value === null) return '—';
  if (isPercent) {
    // Values stored as decimals (0.93 = 93%), convert to display percentage
    const pct = Math.round(value * 1000) / 10;
    return pct % 1 === 0 ? `${pct.toFixed(0)}%` : `${pct.toFixed(1)}%`;
  }
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}

// Uniform target display, e.g. ">=90%", "<=5%", "<=7". The operator comes from
// the metric direction (high -> ">=", low -> "<="). The number is picked in
// priority order: one attached to a comparison operator (e.g. "<40", ">=85%"),
// then a percentage (e.g. "90%"), then the first number — so stray digits like
// the "1" in "P1 baseline" are ignored. "%" is appended for percent metrics.
// Falls back to the raw description if no number can be parsed.
export function formatTarget(metric: Metric): string {
  const desc = metric.targetDescription ?? '';
  const op = metric.direction === 'low' ? '<=' : '>=';
  const unit = metric.isPercent ? '%' : '';
  const opMatch = desc.match(/[<>]=?\s*(\d+(?:\.\d+)?)/);
  const pctMatch = desc.match(/(\d+(?:\.\d+)?)\s*%/);
  const numMatch = desc.match(/\d+(?:\.\d+)?/);
  const n = opMatch?.[1] ?? pctMatch?.[1] ?? numMatch?.[0];
  if (!n) return desc || '—';
  return `${op}${n}${unit}`;
}

export function statusLabel(status: Status): string {
  switch (status) {
    case 'green': return 'On Target';
    case 'yellow': return 'Watch';
    case 'red': return 'At Risk';
    default: return '—';
  }
}

export function computeStatus(actual: number | null, plan: number | null, direction: 'high' | 'low'): Status {
  if (actual === null || plan === null) return 'gray';
  const ratio = direction === 'high' ? actual / plan : plan / actual;
  if (!Number.isFinite(ratio)) return 'gray';
  if (ratio >= 0.95) return 'green';
  if (ratio >= 0.85) return 'yellow';
  return 'red';
}

export function latestMonthLabel(metric: Metric): string {
  const latest = getLatestMonth(metric);
  if (!latest) return '';
  return `${latest.monthName} '${latest.monthYear.slice(2)}`;
}

// Display-only, parallel section names. Underlying metric.section values are
// unchanged (they still drive pillar/initiative linkage), so this map only
// affects rendering.
const SECTION_LABELS: Record<string, string> = {
  'IT Operational Metrics': 'IT Operations',
  'Operational Cyber Dashboard': 'Cybersecurity',
};

export function sectionLabel(section: string): string {
  return SECTION_LABELS[section] || section;
}

// Worst-first ordering for the "sort by status" mode.
const STATUS_RANK: Record<Status, number> = { red: 0, yellow: 1, green: 2, gray: 3 };

export function statusRank(status: Status): number {
  return STATUS_RANK[status];
}

// Trailing-window trend timeframes (in months of data-with-actuals).
export type TrendTimeframe = 'month' | 'quarter' | 'annual';
export const TREND_WINDOW: Record<TrendTimeframe, number> = { month: 1, quarter: 3, annual: 12 };

// The trailing N months (with an actual value) for the selected timeframe.
export function windowedMonths(metric: Metric, timeframe: TrendTimeframe): MonthData[] {
  const withActual = metric.monthly.filter(m => m.actual !== null);
  return withActual.slice(-TREND_WINDOW[timeframe]);
}

// Worst status across a set of months (red < yellow < green); ignores gray/no-data.
// Returns 'gray' only when no month has a real status.
export function worstStatusInWindow(months: MonthData[]): Status {
  let worst: Status = 'gray';
  for (const m of months) {
    const s = m.status;
    if (!s || s === 'gray') continue;
    if (worst === 'gray' || statusRank(s) < statusRank(worst)) worst = s;
  }
  return worst;
}

export interface StatusCounts {
  green: number;
  yellow: number;
  red: number;
  gray: number;
  total: number;
  onTargetPct: number; // green / (metrics with data) * 100, rounded
}

export function statusCounts(metrics: Metric[]): StatusCounts {
  const c: StatusCounts = { green: 0, yellow: 0, red: 0, gray: 0, total: metrics.length, onTargetPct: 0 };
  for (const m of metrics) c[statusOf(m)]++;
  const withData = c.green + c.yellow + c.red;
  c.onTargetPct = withData > 0 ? Math.round((c.green / withData) * 100) : 0;
  return c;
}

// Latest month that has an actual, across ALL metrics — used for a single
// "Data as of {month}" indicator.
export function globalDataAsOf(metrics: Metric[]): string {
  let best: MonthData | null = null;
  for (const m of metrics) {
    const latest = getLatestMonth(m);
    if (latest && (!best || latest.monthIndex > best.monthIndex)) best = latest;
  }
  if (!best) return '';
  return `${best.monthName} '${best.monthYear.slice(2)}`;
}

// Change vs the prior month with an actual. `improved` accounts for metric
// direction (for 'low' metrics a decrease is an improvement).
export interface PriorDelta {
  deltaText: string; // e.g. "+0.4" or "-1.2%"
  arrow: '▲' | '▼';
  improved: boolean;
}

export function priorDelta(metric: Metric): PriorDelta | null {
  const withActual = metric.monthly.filter(m => m.actual !== null);
  if (withActual.length < 2) return null;
  const cur = withActual[withActual.length - 1].actual as number;
  const prev = withActual[withActual.length - 2].actual as number;
  const raw = cur - prev;
  if (raw === 0) return null;
  const up = raw > 0;
  const improved = metric.direction === 'high' ? up : !up;
  const mag = Math.abs(raw);
  // Suppress changes that round to zero at display precision (e.g. "-0.0pt"),
  // which would otherwise show a misleading red/green signal for ~no change.
  const displayMag = metric.isPercent ? Math.round(mag * 1000) / 10 : Math.round(mag * 10) / 10;
  if (displayMag === 0) return null;
  const magText = metric.isPercent
    ? `${displayMag.toFixed(1)}pt`
    : (Number.isInteger(mag) ? String(mag) : mag.toFixed(1));
  return { deltaText: `${up ? '+' : '-'}${magText}`, arrow: up ? '▲' : '▼', improved };
}

export function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
