import { BRANDS, readStoredBrand } from '@/lib/brand';

const OWNER_EMAILS: Record<string, string> = {
  'Mike Johnson': 'samson.stubbs@snowflake.com',
  'Yvonne Stevens': 'samson.stubbs@snowflake.com',
  'Michael Graveen': 'samson.stubbs@snowflake.com',
  'Mike /Yvonne': 'samson.stubbs@snowflake.com',
  'Mike/ Michael Graveen': 'samson.stubbs@snowflake.com',
  'Mike / Michael Graveen': 'samson.stubbs@snowflake.com',
  'Sanjay': 'samson.stubbs@snowflake.com',
  'Sanjay/Yvonne': 'samson.stubbs@snowflake.com',
  'Sanjay / Yvonne': 'samson.stubbs@snowflake.com',
};

function resolveOwnerEmail(ownerStr: string): string {
  if (OWNER_EMAILS[ownerStr]) return OWNER_EMAILS[ownerStr];
  const first = ownerStr.split(/[\/,]/)[0].trim();
  for (const k in OWNER_EMAILS) {
    if (k.includes(first)) return OWNER_EMAILS[k];
  }
  return 'samson.stubbs@snowflake.com';
}

export async function notifyCommentByEmail(
  metricName: string,
  commentText: string,
  commenter: string,
  ownerStr: string,
  month?: string,
  section?: string
): Promise<boolean> {
  const ownerEmail = resolveOwnerEmail(ownerStr);
  try {
    const resp = await fetch('/api/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        metricName,
        commentText,
        commenter,
        ownerEmail,
        ownerName: ownerStr,
        month: month || '',
        section: section || '',
        brandName: BRANDS[readStoredBrand()].name,
      }),
    });
    const data = await resp.json();
    return data.sent === true;
  } catch {
    return false;
  }
}
