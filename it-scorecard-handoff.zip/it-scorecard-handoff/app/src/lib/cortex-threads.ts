import { readFileSync } from 'fs';

// Application name used to scope threads to this app (Threads API limits to 16 bytes)
export const ORIGIN_APPLICATION = 'scorecard';

export function getAccountUrl(): string {
  // SPCS: use the internal host Snowflake provides (avoids external egress)
  if (process.env.SNOWFLAKE_HOST) return `https://${process.env.SNOWFLAKE_HOST}`;
  // Local dev only: set SNOWFLAKE_ACCOUNT_URL in .env
  return process.env.SNOWFLAKE_ACCOUNT_URL || '';
}

export function getAuth(callerToken?: string): { token: string; tokenType: string } {
  // SPCS: read the mounted service token; if a caller (ingress user) token is
  // supplied, build a caller's-rights login token so threads + the agent run as
  // the logged-in user.
  if (process.env.SNOWFLAKE_HOST) {
    try {
      const serviceToken = readFileSync('/snowflake/session/token', 'utf-8').trim();
      return {
        token: callerToken ? `${serviceToken}.${callerToken}` : serviceToken,
        tokenType: 'OAUTH',
      };
    } catch {
      // fall through to env vars
    }
  }
  if (process.env.SNOWFLAKE_TOKEN) return { token: process.env.SNOWFLAKE_TOKEN, tokenType: 'OAUTH' };
  return { token: process.env.SF_PAT || '', tokenType: 'PROGRAMMATIC_ACCESS_TOKEN' };
}

/** Read the SPCS ingress user token forwarded when executeAsCaller is enabled.
 *  Gated off by default (App Runtime has no caller's rights); enable only on an
 *  executeAsCaller SPCS service via ENABLE_CALLERS_RIGHTS=true. */
export function getCallerToken(req: Request): string | undefined {
  if (process.env.ENABLE_CALLERS_RIGHTS !== 'true') return undefined;
  return req.headers.get('sf-context-current-user-token') ?? undefined;
}

export interface ThreadMetadata {
  thread_id: number;
  thread_name: string;
  origin_application: string;
  created_on: number;
  updated_on: number;
}

export interface ThreadMessage {
  message_id: number;
  parent_id: number | null;
  created_on: number;
  role: string;
  message_payload: string;
  request_id: string;
  message_type: string;
}

function headers(callerToken?: string) {
  const { token, tokenType } = getAuth(callerToken);
  if (!token) throw new Error('No auth token available');
  return {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    Authorization: `Bearer ${token}`,
    'X-Snowflake-Authorization-Token-Type': tokenType,
  };
}

async function ensureOk(resp: Response, label: string) {
  if (!resp.ok) {
    const body = await resp.text();
    throw new Error(`${label} failed (${resp.status}): ${body.substring(0, 200)}`);
  }
}

export async function createThread(callerToken?: string): Promise<ThreadMetadata> {
  const resp = await fetch(`${getAccountUrl()}/api/v2/cortex/threads`, {
    method: 'POST',
    headers: headers(callerToken),
    signal: AbortSignal.timeout(30000),
    body: JSON.stringify({ origin_application: ORIGIN_APPLICATION }),
  });
  await ensureOk(resp, 'Create thread');
  return resp.json();
}

export async function listThreads(callerToken?: string): Promise<ThreadMetadata[]> {
  const resp = await fetch(
    `${getAccountUrl()}/api/v2/cortex/threads?origin_application=${ORIGIN_APPLICATION}`,
    { method: 'GET', headers: headers(callerToken), signal: AbortSignal.timeout(30000) }
  );
  await ensureOk(resp, 'List threads');
  const data = await resp.json();
  return Array.isArray(data) ? data : [];
}

export async function describeThread(
  id: number,
  callerToken?: string
): Promise<{ metadata: ThreadMetadata; messages: ThreadMessage[] }> {
  const resp = await fetch(
    `${getAccountUrl()}/api/v2/cortex/threads/${id}?message_type=conversation&page_size=100`,
    { method: 'GET', headers: headers(callerToken), signal: AbortSignal.timeout(30000) }
  );
  await ensureOk(resp, 'Describe thread');
  return resp.json();
}

export async function updateThread(id: number, threadName: string, callerToken?: string): Promise<void> {
  const resp = await fetch(`${getAccountUrl()}/api/v2/cortex/threads/${id}`, {
    method: 'POST',
    headers: headers(callerToken),
    signal: AbortSignal.timeout(30000),
    body: JSON.stringify({ thread_name: threadName }),
  });
  await ensureOk(resp, 'Update thread');
}

export async function deleteThread(id: number, callerToken?: string): Promise<void> {
  const resp = await fetch(`${getAccountUrl()}/api/v2/cortex/threads/${id}`, {
    method: 'DELETE',
    headers: headers(callerToken),
    signal: AbortSignal.timeout(30000),
  });
  await ensureOk(resp, 'Delete thread');
}
