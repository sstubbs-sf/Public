'use client';

// Convert GitHub-style pipe tables into styled HTML. Runs before the newline
// passes; emitted HTML is single-line so it survives the \n -> <br> transform.
function renderTables(text: string): string {
  const lines = text.split('\n');
  const out: string[] = [];
  const isRow = (l: string) => /\|/.test(l) && l.trim().startsWith('|');
  const isSep = (l: string) => /^\s*\|?[\s:|-]*-[\s:|-]*\|?\s*$/.test(l) && /-/.test(l);

  const cells = (l: string) =>
    l
      .trim()
      .replace(/^\||\|$/g, '')
      .split('|')
      .map((c) => c.trim());

  for (let i = 0; i < lines.length; i++) {
    if (isRow(lines[i]) && i + 1 < lines.length && isSep(lines[i + 1])) {
      const header = cells(lines[i]);
      i += 2; // skip header + separator
      const bodyRows: string[][] = [];
      while (i < lines.length && isRow(lines[i]) && !isSep(lines[i])) {
        bodyRows.push(cells(lines[i]));
        i++;
      }
      i--; // step back; outer loop will advance

      const th = header
        .map(
          (c) =>
            `<th style="text-align:left;padding:5px 9px;border-bottom:1px solid var(--border);font-weight:700;font-size:11px;color:var(--muted);white-space:nowrap">${c}</th>`
        )
        .join('');
      const trs = bodyRows
        .map(
          (r) =>
            '<tr>' +
            r
              .map(
                (c) =>
                  `<td style="padding:5px 9px;border-bottom:1px solid var(--border);vertical-align:top">${c}</td>`
              )
              .join('') +
            '</tr>'
        )
        .join('');
      out.push(
        `<table style="border-collapse:collapse;margin:8px 0;width:100%;font-size:12px"><thead><tr>${th}</tr></thead><tbody>${trs}</tbody></table>`
      );
    } else {
      out.push(lines[i]);
    }
  }
  return out.join('\n');
}

export function renderMarkdown(text: string): string {
  let html = text;
  // Code blocks
  html = html.replace(/```([\s\S]*?)```/g, '<pre style="margin:6px 0;white-space:pre-wrap;word-break:break-word;background:#f3f4f6;padding:8px;border-radius:4px;font-size:11px">$1</pre>');
  // Tables (before inline + newline passes)
  html = renderTables(html);
  // Headings
  html = html.replace(/^### (.+)$/gm, '<strong style="font-size:13px;display:block;margin:8px 0 4px">$1</strong>');
  html = html.replace(/^## (.+)$/gm, '<strong style="font-size:14px;display:block;margin:8px 0 4px">$1</strong>');
  html = html.replace(/^# (.+)$/gm, '<strong style="font-size:15px;display:block;margin:8px 0 4px">$1</strong>');
  // Bold
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  // Italic
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code style="background:#f3f4f6;padding:1px 4px;border-radius:3px;font-size:11px">$1</code>');
  // Unordered lists
  html = html.replace(/^- (.+)$/gm, '<li style="margin:3px 0;margin-left:16px">$1</li>');
  html = html.replace(/(<li[^>]*>.*<\/li>\n?)+/g, '<ul style="margin:6px 0;padding:0;list-style:disc">$&</ul>');
  // Ordered lists
  html = html.replace(/^\d+\. (.+)$/gm, '<li style="margin:3px 0;margin-left:16px">$1</li>');
  // Horizontal rule
  html = html.replace(/^---$/gm, '<hr style="border:none;border-top:1px solid var(--border);margin:8px 0">');
  // Links (sanitize javascript: protocol)
  html = html.replace(/\[([^\]]+)\]\((?!javascript:)(https?:\/\/[^)]+)\)/g, '<a href="$2" style="color:var(--primary);text-decoration:underline" target="_blank" rel="noopener">$1</a>');
  // Paragraphs (double newlines)
  html = html.replace(/\n\n/g, '</p><p style="margin:6px 0">');
  // Single newlines
  html = html.replace(/\n/g, '<br>');
  return html;
}

export function formatTimestamp(date?: Date): string {
  if (!date) return '';
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}
