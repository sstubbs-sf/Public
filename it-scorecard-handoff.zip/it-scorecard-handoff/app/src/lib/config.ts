// Central Snowflake object configuration. All names default to the original
// deployment but can be overridden via environment variables at deploy time
// (set in service-spec.yml). This keeps the app portable across accounts
// without code edits — change the env vars, not the source.

export const SF_DATABASE = process.env.SF_DATABASE ?? 'ITSCORECARD';
export const SF_ANALYTICS_SCHEMA = process.env.SF_ANALYTICS_SCHEMA ?? 'ITSCORECARD_DEMO';
export const SF_APP_SCHEMA = process.env.SF_APP_SCHEMA ?? 'ITSCORECARD_DEMO';
export const SF_AGENT = process.env.SF_AGENT ?? 'SCORECARD_AGENT';
export const SF_SEMANTIC_VIEW = process.env.SF_SEMANTIC_VIEW ?? 'ITSCORECARD_DEMO_SV';
export const SF_WAREHOUSE = process.env.SF_WAREHOUSE ?? 'ITSCORECARD_DEMO_WH';

const A = `${SF_DATABASE}.${SF_ANALYTICS_SCHEMA}`;
const P = `${SF_DATABASE}.${SF_APP_SCHEMA}`;

// Fully-qualified object names used across the API routes.
export const OBJ = {
  METRICS: `${A}.METRICS`,
  METRIC_MONTHLY_DATA: `${A}.METRIC_MONTHLY_DATA`,
  INITIATIVES: `${A}.INITIATIVES`,
  INITIATIVE_KPI_LINKS: `${A}.INITIATIVE_KPI_LINKS`,
  COMMENTS: `${P}.COMMENTS`,
  CHAT_UPLOADS_STAGE: `${P}.CHAT_UPLOADS`,
  USER_PREFS: `${P}.USER_PREFS`,
  METRIC_ID_SEQ: `${A}.METRIC_ID_SEQ`,
  INITIATIVE_ID_SEQ: `${A}.INITIATIVE_ID_SEQ`,
} as const;

// Path segments for the Cortex Agent :run REST endpoint.
export const AGENT_PATH = `databases/${SF_DATABASE}/schemas/${SF_APP_SCHEMA}/agents/${SF_AGENT}`;
