import { z } from 'zod';

export const CommentCreateSchema = z.object({
  entityType: z.enum(['metric_month', 'metric', 'initiative']),
  entityId: z.number(),
  monthIndex: z.number().nullable().optional(),
  text: z.string().min(1).max(4000),
  // NOTE: commenter is intentionally NOT accepted from the client. The server
  // derives identity from the authenticated accessing user (Sf-Context-Current-User).
});

export const NotifySchema = z.object({
  metricName: z.string(),
  commentText: z.string().min(1),
  commenter: z.string(),
  ownerEmail: z.string().email(),
  ownerName: z.string(),
  month: z.string().optional(),
  section: z.string().optional(),
  brandName: z.string().optional(),
});

// Create/update a strategic initiative + its linked KPIs. Identity (created_by/
// updated_by) is derived server-side, never trusted from the client.
export const InitiativeWriteSchema = z.object({
  pillar: z.string().min(1).max(500),
  priority: z.string().min(1).max(2000),
  activity: z.string().min(1).max(4000),
  measurableOutcome: z.string().max(4000).optional().default(''),
  owner: z.string().max(500).optional().default(''),
  partner: z.string().max(500).optional().default(''),
  linkedMetricIds: z.array(z.number().int()).max(500).optional().default([]),
});

// Create/update a metric + its monthly plan/actual values. Values are stored raw
// (percent metrics as decimals, e.g. 0.93 = 93%); the client converts before sending.
// STATUS is never trusted from the client — the server recomputes it from plan/actual/direction.
export const MetricMonthWriteSchema = z.object({
  monthIndex: z.number().int().min(0).max(60),
  plan: z.number().nullable().optional().default(null),
  actual: z.number().nullable().optional().default(null),
});

export const MetricWriteSchema = z.object({
  name: z.string().min(1).max(500),
  section: z.string().min(1).max(500),
  targetDescription: z.string().max(2000).optional().default(''),
  owner: z.string().max(500).optional().default(''),
  direction: z.enum(['high', 'low']),
  isPercent: z.boolean().optional().default(false),
  monthly: z.array(MetricMonthWriteSchema).max(120).optional().default([]),
});

export const AgentMessageSchema = z.object({
  message: z.string().min(1).max(10000),
  context: z.string().optional(),
  threadId: z.number().int().optional(),
  parentMessageId: z.number().int().optional(),
});

// Per-user UI preference (e.g. saved table column order). Value is an opaque
// JSON string the client owns; server just stores it keyed by (user, key).
export const PrefWriteSchema = z.object({
  key: z.string().min(1).max(100),
  value: z.string().max(100000),
});

export type CommentCreate = z.infer<typeof CommentCreateSchema>;
export type InitiativeWrite = z.infer<typeof InitiativeWriteSchema>;
export type MetricWrite = z.infer<typeof MetricWriteSchema>;
