-- =====================================================================
-- 06_role_and_users.sql  —  ONE full-rights application role + users
-- Run as ACCOUNTADMIN, after 05_cortex_agent.sql (objects must exist so the
-- ON ALL grants pick them up; FUTURE grants cover anything created later).
-- ITSCORECARD_DEMO_USERS gets FULL rights on the database, schema, and warehouse
-- — app usage, data CRUD, semantic-model creation, agent usage, everything.
-- Uses the ITSCORECARD single-namespace defaults; edit the user logins below.
-- Idempotent.
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- 1) The single application role --------------------------------------------
CREATE ROLE IF NOT EXISTS ITSCORECARD_DEMO_USERS
  COMMENT = 'IT Operations Scorecard — full rights on ITSCORECARD db + warehouse (app + users)';

-- 2) FULL rights on the warehouse, database, and schema ----------------------
GRANT ALL PRIVILEGES ON WAREHOUSE ITSCORECARD_DEMO_WH        TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON DATABASE  ITSCORECARD               TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON SCHEMA    ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;

-- 3) Full rights on every object in the schema (existing + future) -----------
--    Schema ALL already includes CREATE TABLE / SEQUENCE / STAGE / SEMANTIC VIEW /
--    SERVICE / IMAGE REPOSITORY, so users can build new models + objects at will.
GRANT ALL PRIVILEGES ON ALL    TABLES         IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON FUTURE TABLES         IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON ALL    VIEWS          IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON FUTURE VIEWS          IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON ALL    SEQUENCES      IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON FUTURE SEQUENCES      IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON ALL    STAGES         IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT ALL PRIVILEGES ON FUTURE STAGES         IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO TO ROLE ITSCORECARD_DEMO_USERS;
GRANT SELECT, REFERENCES ON SEMANTIC VIEW ITSCORECARD.ITSCORECARD_DEMO.ITSCORECARD_DEMO_SV TO ROLE ITSCORECARD_DEMO_USERS;

-- 4) Cortex (AI agent / chat) ------------------------------------------------
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE ITSCORECARD_DEMO_USERS;
GRANT USAGE ON AGENT ITSCORECARD.ITSCORECARD_DEMO.SCORECARD_AGENT TO ROLE ITSCORECARD_DEMO_USERS;

-- 5) App deploy + runtime (so the role can deploy AND run the app) -----------
GRANT USAGE, MONITOR ON COMPUTE POOL SYSTEM_COMPUTE_POOL_CPU              TO ROLE ITSCORECARD_DEMO_USERS;
GRANT USAGE ON INTEGRATION ITSCORECARD_DEMO_NPM_ACCESS_INTEGRATION        TO ROLE ITSCORECARD_DEMO_USERS;
GRANT CREATE APPLICATION SERVICE ON SCHEMA ITSCORECARD.ITSCORECARD_DEMO   TO ROLE ITSCORECARD_DEMO_USERS;
GRANT CREATE IMAGE REPOSITORY    ON SCHEMA ITSCORECARD.ITSCORECARD_DEMO   TO ROLE ITSCORECARD_DEMO_USERS;
GRANT CREATE SERVICE             ON SCHEMA ITSCORECARD.ITSCORECARD_DEMO   TO ROLE ITSCORECARD_DEMO_USERS;
GRANT BIND SERVICE ENDPOINT      ON ACCOUNT                               TO ROLE ITSCORECARD_DEMO_USERS;

-- 6) Role hierarchy ----------------------------------------------------------
GRANT ROLE ITSCORECARD_DEMO_USERS TO ROLE SYSADMIN;

-- 7) The app users -----------------------------------------------------------
--    Grant the role to the TWO app users (USER1, USER2 in config.env). Both lines
--    below default to SSTUBBS — replace with the real logins (if USER1 == USER2,
--    the second pair is a harmless no-op). In a FRESH account these users may not
--    exist yet: CoCo checks `SHOW USERS LIKE '<login>'` first and, if missing,
--    creates them with ONE of the templates below.
--
--    Option A — password with forced reset on first login:
--      CREATE USER IF NOT EXISTS <login>
--        PASSWORD = '<temp-password>' MUST_CHANGE_PASSWORD = TRUE COMMENT = 'IT Scorecard user';
--    Option B — SSO / existing identity (no password; login via your IdP):
--      CREATE USER IF NOT EXISTS <login>
--        LOGIN_NAME = '<login>' COMMENT = 'IT Scorecard user';

-- USER1:
GRANT ROLE ITSCORECARD_DEMO_USERS TO USER SSTUBBS;
ALTER USER SSTUBBS SET DEFAULT_ROLE = ITSCORECARD_DEMO_USERS DEFAULT_WAREHOUSE = ITSCORECARD_DEMO_WH;

-- USER2 (replace SSTUBBS with the second login; skip if same as USER1):
GRANT ROLE ITSCORECARD_DEMO_USERS TO USER SSTUBBS;
ALTER USER SSTUBBS SET DEFAULT_ROLE = ITSCORECARD_DEMO_USERS DEFAULT_WAREHOUSE = ITSCORECARD_DEMO_WH;

SELECT '06_role_and_users complete' AS status;
