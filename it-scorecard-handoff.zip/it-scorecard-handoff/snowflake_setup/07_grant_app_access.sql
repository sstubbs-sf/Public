-- =====================================================================
-- 07_grant_app_access.sql  —  RUN AFTER `snow app deploy` SUCCEEDS
-- Lets the users open the deployed app URL. Run as ACCOUNTADMIN.
-- Snowflake App Runtime exposes an APPLICATION SERVICE; USAGE on it (plus USAGE
-- on its database + schema) grants access to the public endpoint.
-- Object names are the ITSCORECARD single-namespace defaults (schema ITSCORECARD_DEMO).
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- The app is deployed into ITSCORECARD.ITSCORECARD_DEMO (see app/snowflake.yml).
-- The service lives at ITSCORECARD.ITSCORECARD_DEMO.ITSCORECARD_APP.

-- Database + schema usage for the schema that holds the service:
GRANT USAGE ON DATABASE ITSCORECARD                       TO ROLE ITSCORECARD_DEMO_USERS;
GRANT USAGE ON SCHEMA   ITSCORECARD.ITSCORECARD_DEMO      TO ROLE ITSCORECARD_DEMO_USERS;

-- Access the public endpoint (open the app URL):
GRANT USAGE ON APPLICATION SERVICE ITSCORECARD.ITSCORECARD_DEMO.ITSCORECARD_APP TO ROLE ITSCORECARD_DEMO_USERS;

-- Optional: let the role suspend/resume/upgrade the app (lifecycle control):
-- GRANT OPERATE ON APPLICATION SERVICE ITSCORECARD.ITSCORECARD_DEMO.ITSCORECARD_APP TO ROLE ITSCORECARD_DEMO_USERS;
-- Optional: let the role view status + container logs:
-- GRANT MONITOR ON APPLICATION SERVICE ITSCORECARD.ITSCORECARD_DEMO.ITSCORECARD_APP TO ROLE ITSCORECARD_DEMO_USERS;

-- Discover the live URL to share with your users:
--   SHOW APPLICATION SERVICES IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO;
--   -- or in Cortex Code Desktop: open the Apps view.

SELECT '07_grant_app_access complete — share the app URL with your users' AS status;
