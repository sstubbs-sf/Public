-- =====================================================================
-- 02_schema.sql  —  Tables, sequences, and the chat-uploads stage
-- Run as ACCOUNTADMIN, after 01_prereqs.sql. Idempotent (IF NOT EXISTS).
-- Column definitions match the source account exactly (GET_DDL).
-- Object names are the ITSCORECARD single-namespace defaults (schema ITSCORECARD_DEMO).
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- ---- ANALYTICS: metrics ----------------------------------------------------
CREATE TABLE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.METRICS (
  METRIC_ID          NUMBER(38,0),
  METRIC_NAME        VARCHAR(16777216),
  SECTION            VARCHAR(16777216),
  TARGET_DESCRIPTION VARCHAR(16777216),
  OWNER              VARCHAR(16777216),
  DIRECTION          VARCHAR(16777216) COMMENT 'high = higher is better, low = lower is better',
  IS_PERCENT         BOOLEAN,
  CREATED_BY         VARCHAR(255),
  UPDATED_BY         VARCHAR(255),
  UPDATED_AT         TIMESTAMP_NTZ(9)
);

CREATE TABLE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.METRIC_MONTHLY_DATA (
  METRIC_ID    NUMBER(38,0),
  MONTH_INDEX  NUMBER(38,0),
  MONTH_NAME   VARCHAR(16777216),
  MONTH_YEAR   VARCHAR(16777216),
  PLAN_VALUE   FLOAT,
  ACTUAL_VALUE FLOAT,
  STATUS       VARCHAR(16777216) COMMENT 'green, yellow, red, or gray'
);

-- ---- ANALYTICS: initiatives ------------------------------------------------
CREATE TABLE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.INITIATIVES (
  INITIATIVE_ID      NUMBER(38,0),
  PILLAR             VARCHAR(16777216),
  PRIORITY           VARCHAR(16777216),
  ACTIVITY           VARCHAR(16777216),
  MEASURABLE_OUTCOME VARCHAR(16777216),
  OWNER              VARCHAR(16777216),
  PARTNER            VARCHAR(16777216),
  CREATED_BY         VARCHAR(255),
  UPDATED_BY         VARCHAR(255),
  UPDATED_AT         TIMESTAMP_NTZ(9)
);

CREATE TABLE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.INITIATIVE_KPI_LINKS (
  INITIATIVE_ID NUMBER(38,0) NOT NULL,
  METRIC_ID     NUMBER(38,0) NOT NULL,
  PRIMARY KEY (INITIATIVE_ID, METRIC_ID)
);

-- ---- APP: comments (starts empty) ------------------------------------------
CREATE TABLE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.COMMENTS (
  COMMENT_ID         NUMBER(38,0) AUTOINCREMENT START 1 INCREMENT 1 NOORDER,
  ENTITY_TYPE        VARCHAR(50)  NOT NULL,
  ENTITY_ID          NUMBER(38,0) NOT NULL,
  MONTH_INDEX        NUMBER(38,0),
  COMMENT_TEXT       VARCHAR(4000) NOT NULL,
  COMMENTER          VARCHAR(200) DEFAULT 'Anonymous',
  CREATED_AT         TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP(),
  COMMENTER_USERNAME VARCHAR(255)
);

-- ---- Per-user UI preferences (e.g. saved table column order) ---------------
CREATE TABLE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.USER_PREFS (
  USERNAME   VARCHAR(255)     NOT NULL,
  PREF_KEY   VARCHAR(100)     NOT NULL,
  PREF_VALUE VARCHAR(16777216),
  UPDATED_AT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP(),
  PRIMARY KEY (USERNAME, PREF_KEY)
);

-- ---- Sequences (starting values re-computed in 03_seed_data.sql) -----------
CREATE SEQUENCE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.METRIC_ID_SEQ     START = 1 INCREMENT = 1;
CREATE SEQUENCE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.INITIATIVE_ID_SEQ START = 1 INCREMENT = 1;

-- ---- Chat uploads stage (transient files processed by Cortex AI) -----------
CREATE STAGE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.CHAT_UPLOADS
  COMMENT = 'Transient uploads from the Scorecard chat; processed by Cortex AI then referenced as session context.';

SELECT '02_schema complete' AS status;
