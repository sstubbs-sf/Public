-- =====================================================================
-- 01_prereqs.sql  —  Account-level prerequisites (run as ACCOUNTADMIN)
-- Creates: warehouse, database + single schema, and the npm egress integration
-- required by `snow app deploy` to build the container image remotely.
-- Idempotent: safe to re-run.
-- Object names are the ITSCORECARD single-namespace defaults (schema ITSCORECARD_DEMO).
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- 1) Warehouse used by the app REST queries and the Cortex Agent -------------
--    Medium, Generation 2, auto-scale multi-cluster (1-10). Multi-cluster
--    requires Enterprise Edition (or higher). Auto-suspend keeps idle cost ~0.
CREATE WAREHOUSE IF NOT EXISTS ITSCORECARD_DEMO_WH
  WAREHOUSE_SIZE = MEDIUM
  GENERATION = '2'
  MIN_CLUSTER_COUNT = 1
  MAX_CLUSTER_COUNT = 10
  SCALING_POLICY = 'STANDARD'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE
  COMMENT = 'IT Operations Scorecard app queries + Cortex Agent (Medium Gen2, auto-scale 1-10)';

-- 2) Database + single schema ------------------------------------------------
CREATE DATABASE IF NOT EXISTS ITSCORECARD
  COMMENT = 'Solventum 2026 IT Operations Scorecard';
CREATE SCHEMA IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO
  COMMENT = 'All Scorecard objects: metrics, monthly data, initiatives, comments, semantic view, agent, chat uploads, app service';

-- 3) npm egress for the Snowflake App remote build ---------------------------
--    `snow app deploy` builds the Next.js image on Snowflake compute; it needs
--    outbound access to npm + GitHub. Self-contained (no cross-database refs).
CREATE NETWORK RULE IF NOT EXISTS ITSCORECARD.ITSCORECARD_DEMO.NPM_NETWORK_RULE
  MODE = EGRESS
  TYPE = HOST_PORT
  VALUE_LIST = (
    'registry.npmjs.org:443','registry.npmjs.org:80',
    'github.com:443','codeload.github.com:443','objects.githubusercontent.com:443'
  )
  COMMENT = 'npm + GitHub egress for Snowflake App remote builds';

CREATE EXTERNAL ACCESS INTEGRATION IF NOT EXISTS ITSCORECARD_DEMO_NPM_ACCESS_INTEGRATION
  ALLOWED_NETWORK_RULES = (ITSCORECARD.ITSCORECARD_DEMO.NPM_NETWORK_RULE)
  ENABLED = TRUE
  COMMENT = 'npm registry egress for ITSCORECARD app remote builds';

-- 4) Compute pool ------------------------------------------------------------
--    The build + service use a CPU compute pool. SYSTEM_COMPUTE_POOL_CPU is a
--    Snowflake-provided system pool available in most accounts. If your account
--    does not expose it, create a small pool and set COMPUTE_POOL in config.env:
--
--    CREATE COMPUTE POOL IF NOT EXISTS SYSTEM_COMPUTE_POOL_CPU
--      MIN_NODES = 1 MAX_NODES = 1 INSTANCE_FAMILY = CPU_X64_XS AUTO_SUSPEND_SECS = 600;

-- 5) Cortex prerequisites (for the AI chat assistant) ------------------------
--    The agent orchestrates on claude-opus-4-8 and uses Web Search. Ensure:
--      • Snowflake Cortex is enabled for this account/region.
--      • claude-opus-4-8 is available in your region, OR enable cross-region
--        inference:  ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';
--    (No object to create here — this is a readiness note.)

SELECT '01_prereqs complete' AS status;
