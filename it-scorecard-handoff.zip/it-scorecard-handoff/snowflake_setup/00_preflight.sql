-- =====================================================================
-- 00_preflight.sql  —  Read-only environment checks (run FIRST)
-- Confirms the target account is ready before any objects are created.
-- Nothing here mutates state. Substitute @@TOKENS@@ from config.env first.
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- 1) Who/where am I? Note the region — it affects Cortex model availability.
SELECT CURRENT_ROLE()    AS current_role,
       CURRENT_ACCOUNT() AS current_account,
       CURRENT_REGION()  AS current_region;

-- 2) Compute pool for the app build + service.
--    Expect one row for SYSTEM_COMPUTE_POOL_CPU. If EMPTY, the pool is missing:
--    create a small pool (see 01_prereqs.sql) and set COMPUTE_POOL in config.env.
SHOW COMPUTE POOLS LIKE 'SYSTEM_COMPUTE_POOL_CPU';

-- 3) Cross-region inference setting.
--    If claude-opus-4-8 is not native to CURRENT_REGION, you must enable this
--    (ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';) for the agent.
SHOW PARAMETERS LIKE 'CORTEX_ENABLED_CROSS_REGION' IN ACCOUNT;

-- 4) Does the target database already exist?
--    If a row is returned, this is a RE-DEPLOY — confirm with the user before
--    running 02/03 (03 replaces table contents).
SHOW DATABASES LIKE 'ITSCORECARD';

-- 5) Are the two app users present?
--    If a login is missing, create it in Phase 5 (see 06_role_and_users.sql).
SHOW USERS LIKE 'SSTUBBS';
SHOW USERS LIKE 'SSTUBBS';

SELECT '00_preflight complete — review the results above before proceeding' AS status;
