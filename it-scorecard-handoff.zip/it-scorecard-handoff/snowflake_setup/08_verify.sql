-- =====================================================================
-- 08_verify.sql  —  Post-deploy verification (run LAST)
-- Confirms data, agent, app service, and grants are all in place.
-- Object names are the ITSCORECARD single-namespace defaults (schema ITSCORECARD_DEMO).
-- =====================================================================
USE ROLE ACCOUNTADMIN;

-- 1) Seed data row counts — expect: 21 / 273 / 21 / 135 --------------------
SELECT 'METRICS'              AS table_name, COUNT(*) AS row_count FROM ITSCORECARD.ITSCORECARD_DEMO.METRICS
UNION ALL
SELECT 'METRIC_MONTHLY_DATA', COUNT(*) FROM ITSCORECARD.ITSCORECARD_DEMO.METRIC_MONTHLY_DATA
UNION ALL
SELECT 'INITIATIVES',         COUNT(*) FROM ITSCORECARD.ITSCORECARD_DEMO.INITIATIVES
UNION ALL
SELECT 'INITIATIVE_KPI_LINKS',COUNT(*) FROM ITSCORECARD.ITSCORECARD_DEMO.INITIATIVE_KPI_LINKS
ORDER BY table_name;

-- 2) Semantic view exists ---------------------------------------------------
SHOW SEMANTIC VIEWS LIKE 'ITSCORECARD_DEMO_SV' IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO;

-- 2b) Per-user prefs table exists (starts empty; backs saved table column order) --
SHOW TABLES LIKE 'USER_PREFS' IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO;

-- 3) Cortex Agent exists ----------------------------------------------------
SHOW AGENTS LIKE 'SCORECARD_AGENT' IN SCHEMA ITSCORECARD.ITSCORECARD_DEMO;

-- 4) Application Service exists + is running (after `snow app deploy`) -------
SHOW APPLICATION SERVICES LIKE 'ITSCORECARD_APP' IN DATABASE ITSCORECARD;

-- 5) Grants on the app role — should include DB/schema usage, table privileges,
--    CORTEX_USER, agent USAGE, warehouse USAGE, and (post-07) application service USAGE.
SHOW GRANTS TO ROLE ITSCORECARD_DEMO_USERS;

-- 6) Both users have the role -----------------------------------------------
SHOW GRANTS OF ROLE ITSCORECARD_DEMO_USERS;

SELECT '08_verify complete — confirm counts 21/273/21/135, agent + service present, grants + users OK' AS status;
