-- =====================================================================
-- 04_semantic_view.sql  —  Cortex Analyst semantic view (backs the agent)
-- Run as ACCOUNTADMIN, after data is loaded (03). Reproduces the source DDL.
-- Object names are the ITSCORECARD single-namespace defaults (schema ITSCORECARD_DEMO).
-- =====================================================================
USE ROLE ACCOUNTADMIN;

CREATE OR REPLACE SEMANTIC VIEW ITSCORECARD.ITSCORECARD_DEMO.ITSCORECARD_DEMO_SV
  TABLES (
    ITSCORECARD.ITSCORECARD_DEMO.METRICS PRIMARY KEY (METRIC_ID)
      COMMENT='21 IT KPI metrics with targets owners and sections',
    MONTHLY_DATA AS ITSCORECARD.ITSCORECARD_DEMO.METRIC_MONTHLY_DATA
      COMMENT='Monthly plan vs actual values Sep 2025 to Sep 2026',
    ITSCORECARD.ITSCORECARD_DEMO.INITIATIVES PRIMARY KEY (INITIATIVE_ID)
      COMMENT='21 strategic initiatives under 3 pillars'
  )
  RELATIONSHIPS (
    MONTHLY_DATA(METRIC_ID) REFERENCES METRICS(METRIC_ID)
  )
  FACTS (
    MONTHLY_DATA.PLAN_VAL AS PLAN_VALUE,
    MONTHLY_DATA.ACTUAL_VAL AS ACTUAL_VALUE
  )
  DIMENSIONS (
    METRICS.METRIC_NAME AS METRIC_NAME WITH SYNONYMS=('KPI','indicator') COMMENT='Name of the IT metric',
    METRICS.SECTION_NAME AS SECTION WITH SYNONYMS=('category','dashboard') COMMENT='IT Operational Metrics or Operational Cyber Dashboard',
    METRICS.TARGET_DESC AS TARGET_DESCRIPTION COMMENT='Human-readable target threshold',
    METRICS.OWNER_NAME AS OWNER WITH SYNONYMS=('responsible','accountable') COMMENT='Person or team responsible',
    METRICS.DIRECTION_VAL AS DIRECTION COMMENT='high means higher is better, low means lower is better',
    MONTHLY_DATA.MONTH_NM AS MONTH_NAME WITH SYNONYMS=('month') COMMENT='Three-letter month name',
    MONTHLY_DATA.MONTH_YR AS MONTH_YEAR WITH SYNONYMS=('year') COMMENT='Four-digit year',
    MONTHLY_DATA.STATUS_VAL AS STATUS WITH SYNONYMS=('health','RAG status','performance') COMMENT='green yellow red or gray' SAMPLE_VALUES ('green', 'yellow', 'red', 'gray') IS_ENUM,
    INITIATIVES.PILLAR_NAME AS PILLAR WITH SYNONYMS=('strategic pillar') COMMENT='Trusted Partner or Top Quartile Performer or Best Preferred Place to Work',
    INITIATIVES.ACTIVITY_TEXT AS ACTIVITY COMMENT='Specific activity or deliverable',
    INITIATIVES.OUTCOME_TEXT AS MEASURABLE_OUTCOME COMMENT='Expected measurable result',
    INITIATIVES.OWNER_INIT AS INITIATIVES.OWNER COMMENT='Person responsible for initiative'
  )
  METRICS (
    MONTHLY_DATA.AVG_ACTUAL AS AVG(monthly_data.actual_val) COMMENT='Average actual value across months',
    MONTHLY_DATA.LATEST_ACTUAL AS MAX(monthly_data.actual_val) COMMENT='Most recent actual value',
    MONTHLY_DATA.METRIC_COUNT AS COUNT(DISTINCT monthly_data.METRIC_ID) COMMENT='Count of distinct metrics',
    INITIATIVES.INITIATIVE_COUNT AS COUNT(initiatives.INITIATIVE_ID) COMMENT='Count of initiatives'
  )
  COMMENT='Solventum 2026 IT Operations Scorecard tracking 21 KPIs and 21 strategic initiatives';

SELECT '04_semantic_view complete' AS status;
