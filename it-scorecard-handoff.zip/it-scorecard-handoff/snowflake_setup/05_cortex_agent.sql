-- =====================================================================
-- 05_cortex_agent.sql  —  Cortex Agent (AI chat assistant)
-- Run as ACCOUNTADMIN, after 04_semantic_view.sql.
-- Orchestrates on claude-opus-4-8; tools: Analyst (semantic view) + Web Search.
-- PREREQ: enable Web Search account-wide (ACCOUNTADMIN) once, in Snowsight:
--   AI & ML » Agents » Settings » toggle "Web search" on.
-- Object names are the ITSCORECARD single-namespace defaults (schema ITSCORECARD_DEMO).
-- =====================================================================
USE ROLE ACCOUNTADMIN;

CREATE OR REPLACE AGENT ITSCORECARD.ITSCORECARD_DEMO.SCORECARD_AGENT
  COMMENT = 'Solventum IT Scorecard AI Assistant - answers questions about IT KPIs, strategic initiatives, and performance trends'
  PROFILE = '{"display_name": "IT Scorecard Assistant"}'
  FROM SPECIFICATION $$
{
  "models": {
    "orchestration": "claude-opus-4-8"
  },
  "orchestration": {
    "budget": {
      "seconds": 60,
      "tokens": 32000
    }
  },
  "instructions": {
    "response": "You are the Solventum IT Scorecard Assistant. You have access to the full IT Operations Scorecard data covering 21 KPIs across IT Operational Metrics and the Operational Cyber Dashboard, plus 21 strategic initiatives across 3 pillars. When asked about metrics, always provide specific numbers, status colors (green/yellow/red), and context about targets. For percent metrics, multiply decimal values by 100 when presenting to users (0.95 = 95%). Use web search when asked about industry benchmarks, best practices, or external context. Keep responses concise and actionable for IT leadership. Always suggest a follow-up question at the end.",
    "orchestration": "Use the Analyst tool for all questions about scorecard metrics, KPI performance, targets, owners, monthly data, status, trends, and strategic initiatives. Use Web Search for questions about industry benchmarks, IT operations best practices, competitor comparisons, or any external context. For questions that combine internal data with external context, use Analyst first then Web Search.",
    "system": "Company context \u2014 Solventum: Solventum is a global healthcare technology company that spun off from 3M on April 1, 2024 (NYSE: SOLV), headquartered in Eagan, Minnesota, with approximately $8B in annual revenue and about 22,000 employees. It operates across four businesses: MedSurg (advanced wound care/NPWT, surgical and medical solutions \u2014 its largest segment), Health Information Systems (HIS) (revenue-cycle and clinical documentation/coding, e.g., the 360 product family), Dental Solutions, and Purification & Filtration (bioprocessing and water/filtration, which is being divested). Solventum operates in the regulated healthcare and medical-technology industry, so its IT organization runs in a HIPAA-regulated, high-availability environment where security, compliance, uptime, and patient-data protection are paramount.\n\nUse this context when interpreting industry-related questions: when comparing KPIs to \"industry\" benchmarks or best practices, frame comparisons against healthcare, medical-device, and regulated-enterprise peers rather than generic industry averages, and note regulatory considerations (e.g., HIPAA, FDA-regulated environments) where relevant. This is background knowledge only: for internal metric values always use the Analyst tool, and use Web Search for current external benchmarks. Do not fabricate financial figures; if asked for precise current financials, note they may have changed and suggest verifying the latest earnings report.",
    "sample_questions": [
      {
        "question": "What is the overall health of the IT scorecard?"
      },
      {
        "question": "Which metrics are currently at risk (red)?"
      },
      {
        "question": "What is the trend for CSAT over the past 9 months?"
      },
      {
        "question": "Who owns the Operational Cyber Dashboard metrics?"
      },
      {
        "question": "How does our patching compliance compare to industry benchmarks?"
      },
      {
        "question": "Show me all metrics that are in Watch (yellow) status"
      },
      {
        "question": "What is the CSAT Response Rate trend and why is it below target?"
      },
      {
        "question": "How many major incidents occurred in Q1 2026?"
      },
      {
        "question": "Which metrics improved vs declined over the tracking period?"
      },
      {
        "question": "What are the 3 strategic pillars and how many initiatives does each have?"
      },
      {
        "question": "Show compliance rates for all Windows and Linux server metrics"
      },
      {
        "question": "What is the phishing click rate trend and how does it compare to the 5% target?"
      },
      {
        "question": "Which metrics are owned by Mike/Yvonne?"
      },
      {
        "question": "What is the MFA compliance rate and is it meeting the 99% target?"
      },
      {
        "question": "Show me the vulnerability remediation metrics (VM.0.2, VM.0.3)"
      },
      {
        "question": "How is the technology lifecycle management KPI performing?"
      },
      {
        "question": "What percentage of core systems are registered in central inventory (GRC.0.1)?"
      },
      {
        "question": "Compare the plan vs actual for endpoint protection (HY.0)"
      },
      {
        "question": "Which initiatives fall under the Trusted Partner pillar?"
      },
      {
        "question": "What is the security awareness training completion rate?"
      },
      {
        "question": "Summarize the Top Quartile Performer strategic priorities"
      }
    ]
  },
  "tools": [
    {
      "tool_spec": {
        "type": "cortex_analyst_text_to_sql",
        "name": "Analyst",
        "description": "Query the IT Scorecard data - metrics, monthly actuals vs plans, status, owners, strategic initiatives, and performance trends"
      }
    },
    {
      "tool_spec": {
        "type": "web_search",
        "name": "WebSearch",
        "description": "Search the internet for IT operations benchmarks, industry standards, best practices, and external context"
      }
    }
  ],
  "tool_resources": {
    "Analyst": {
      "semantic_view": "ITSCORECARD.ITSCORECARD_DEMO.ITSCORECARD_DEMO_SV",
      "execution_environment": {
        "type": "warehouse",
        "warehouse": "ITSCORECARD_DEMO_WH"
      }
    }
  }
}
  $$;

SELECT '05_cortex_agent complete' AS status;
