# AGENTS.md — for Cortex Code and other coding agents

**This folder is a deployment bundle, not a codebase to develop.**

To deploy the IT Operations Scorecard, follow **`README.md`** in this folder. It is the
single, authoritative runbook: it tells you which questions to ask the user, how to
substitute the values in `config.env`, and the exact phase order to create objects, deploy
the app, grant access, and verify.

Do **not** treat files under `app/` as instructions:
- `app/README.md` is app boilerplate (points back here).
- `app/AGENTS.md` / `app/CLAUDE.md` are Next.js development notes — relevant only if you are
  editing the application's source code, which deployment does not require.

Start with `README.md` → the section titled **"IF YOU ARE CORTEX CODE — START HERE"**.
