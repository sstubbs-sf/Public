"""Build examples/example-deck.html from assets/shell.html.

Keeps the example's CSS and nav JS byte-identical to the shell, so the example can
never drift from the template it is meant to demonstrate. Re-run after editing the
shell or the SLIDES content below.
"""
import pathlib
import re

S = pathlib.Path(__file__).resolve().parent.parent
shell = (S / "assets/shell.html").read_text(encoding="utf-8")

FOOTER = '    <div class="slide-footer">\n      <span class="fnote">{}</span>\n    </div>\n'
NOTE = "Automation programme review &middot; March 2026"


def slide(cls, body, footer=True):
    open_tag = f'<section class="{cls}">'
    out = f"  {open_tag}\n    <div class=\"slide-body\">\n{body}\n    </div>\n"
    if footer:
        out += FOOTER.format(NOTE)
    return out + "  </section>\n\n"


# ── slide 2 — the shift, two columns ────────────────────────────────────────
S2 = """      <div class="eyebrow">Where we are</div>
      <h2>Triage was the bottleneck, not the fixing</h2>
      <div class="two-col">
        <div>
          <div class="col-label">Before</div>
          <ul class="clean">
            <li>Every request read by a human before it was routed.</li>
            <li>Median 4h 10m from arrival to the right queue.</li>
            <li>Peak Monday backlog absorbed two engineers for the day.</li>
          </ul>
        </div>
        <div>
          <div class="col-label">Now</div>
          <ul class="clean check">
            <li>Classified and routed automatically, with a confidence score.</li>
            <li>Median 6 minutes; low-confidence items still see a human.</li>
            <li>Those two engineers moved to platform work.</li>
          </ul>
        </div>
      </div>
      <div class="callout positive">
        <b>Net effect:</b> 41% of tier-1 volume now closes without a human touch, and
        no measurable change in reopen rate.
      </div>
      <div class="source-note">
        Source: ticketing export, tickets closed 2026-01-01 to 2026-03-31 (n=18,442).
        Excludes P1 incidents.
      </div>"""

# ── slide 3 — card grid with tags + an icon chip ────────────────────────────
ICON_CARDS = [
    ("live", "clipboard-check", "Intake triage",
     "Classifies and routes inbound requests. In production since January."),
    ("next", "book", "Knowledge answers",
     "Answers from approved documentation, with a citation back to the source page."),
    ("vision", "workflow", "Closed-loop remediation",
     "Executes the fix and reports back. Anything destructive needs a named approver."),
]


def icon_cards():
    parts = ['      <div class="cards">']
    for tag, icon, title, text in ICON_CARDS:
        svg = (S / f"assets/icons/{icon}.svg").read_text(encoding="utf-8").strip()
        parts.append(
            '        <div class="card">\n'
            f'          <div class="icon-chip"><span class="icon">{svg}</span></div>\n'
            f'          <span class="tag {tag}" style="margin-top:12px">{tag.title()}</span>\n'
            f"          <h3>{title}</h3>\n"
            f"          <p>{text}</p>\n"
            "        </div>"
        )
    parts.append("      </div>")
    return "\n".join(parts)


S3 = f"""      <div class="slide-header">
        <div class="sh-num">2</div>
        <div>
          <div class="sh-title">What is running, and what is next</div>
          <div class="sh-sub">Three workstreams, one per queue family</div>
        </div>
        <div class="sh-pg">Section 2 of 4</div>
      </div>
{icon_cards()}
      <div class="callout">
        Each workstream ships against a single queue before it is generalised. That is
        deliberate: a narrow agent that works beats a broad one that mostly works.
      </div>"""

# ── slide 4 — horizon table with pills and badges ───────────────────────────
S4 = """      <div class="eyebrow">The plan</div>
      <h2>Sequenced by effort, not by enthusiasm</h2>
      <table class="dtable">
        <thead>
          <tr>
            <th>Workstream</th><th>Owner</th>
            <th class="num">Hours saved / mo</th>
            <th>Effort</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Intake triage</strong></td><td>Platform</td>
            <td class="num">640</td>
            <td><span class="pill low">Low</span></td>
            <td><span class="badge shipped">Shipped</span></td>
          </tr>
          <tr>
            <td><strong>Knowledge answers</strong></td><td>Service desk</td>
            <td class="num">310</td>
            <td><span class="pill med">Medium</span></td>
            <td><span class="badge build">In build</span></td>
          </tr>
          <tr>
            <td><strong>Feed consolidation</strong></td><td>Data engineering</td>
            <td class="num">120</td>
            <td><span class="pill med">Medium</span></td>
            <td><span class="badge planned">Planned</span></td>
          </tr>
          <tr>
            <td><strong>Closed-loop remediation</strong></td><td>Platform</td>
            <td class="num">Not yet estimated</td>
            <td><span class="pill high">High</span></td>
            <td><span class="badge gray">Not started</span></td>
          </tr>
        </tbody>
      </table>
      <div class="bars">
        <div class="bar-row">
          <div class="bar-head">
            <span class="bar-label">Manual triage &mdash; median time to route</span>
            <span class="bar-value">4h 10m</span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:100%"></div></div>
        </div>
        <div class="bar-row hero">
          <div class="bar-head">
            <span class="bar-label">Automated triage &mdash; median time to route</span>
            <span class="bar-value">6m</span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:2.4%"></div></div>
        </div>
      </div>
      <div class="source-note">
        Bar widths are proportional: 6 minutes is 2.4% of 4h 10m. The sliver is the finding.
      </div>"""

# ── slide 5 — the ask, inverse callout close ────────────────────────────────
S5 = """      <div class="eyebrow">The ask</div>
      <h2>Two engineers, one quarter, to finish the feeds</h2>
      <div class="steps-grid">
        <div class="step-item">
          <div class="step-num">1</div>
          <div class="step-text">Close the two remaining manual feeds so the numbers stop lagging a day.</div>
        </div>
        <div class="step-item">
          <div class="step-num">2</div>
          <div class="step-text">Extend triage to the clinical support queue, behind the same confidence gate.</div>
        </div>
      </div>
      <div class="qa-grid">
        <div class="qa-row">
          <div class="qa-q">What if the classifier is wrong?</div>
          <div class="qa-a">Below 0.8 confidence it routes to a human queue. Nothing executes unreviewed.</div>
        </div>
      </div>
      <div class="callout inverse">
        <b>Decision needed by 15 April.</b> Without the two engineers the feed work slips a
        quarter, and the reported numbers keep lagging by a day.
      </div>"""


def main():
    # 1. Title slide, taken from the shell so the verbatim lockup comes along.
    m = re.search(r'  <section class="slide title active">.*?</section>\n', shell, re.DOTALL)
    assert m, "title slide not found in shell"
    title = m.group(0)
    title = (
        title.replace("SECTION EYEBROW", "Quarterly business review")
        .replace(
            "Headline that states the point, not the topic",
            "Automation is now the cheapest capacity we have",
        )
        .replace(
            "One or two sentences of context: what this covers and why it matters now.",
            "Where the programme stands, what it returned, and the two decisions we need.",
        )
        .replace(
            "Prepared for AUDIENCE &middot; MONTH YEAR",
            "Prepared for the IT Leadership Team &middot; March 2026",
        )
    )

    body = (
        title
        + "\n"
        + slide("slide", S2)
        + slide("slide", S3)
        + slide("slide dense", S4)
        + slide("slide", S5)
    )

    # 2. Swap the shell's two placeholder slides for the example's five.
    start = shell.index('  <section class="slide title active">')
    end = shell.index("</div><!-- /deck -->")
    out = shell[:start] + body + shell[end:]
    out = out.replace("<title>DECK TITLE HERE</title>",
                      "<title>Automation programme review &mdash; March 2026</title>")
    out = out.replace("1 / 2", "1 / 5")

    dest = S / "examples/example-deck.html"
    dest.write_text(out, encoding="utf-8")
    print("wrote", dest, dest.stat().st_size, "bytes")
    print("slides:", out.count('<section class="slide'))
    print("logo marker count:", out.count("M89.5 51.3c0-19.3"))


if __name__ == "__main__":
    main()
