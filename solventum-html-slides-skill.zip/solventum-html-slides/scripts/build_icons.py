"""Generate the neutral Solventum-deck icon set into assets/icons/.

House style, applied uniformly so any two icons sit together without looking
mismatched:
  - 24x24 viewBox, no width/height attributes (the .icon CSS class sizes them)
  - stroke="currentColor", fill="none", stroke-width 1.6, round caps and joins
  - inherits colour from the parent, so one icon works on white and on deep green

These are deliberately generic (documents, charts, locks, people, clinical) with
no vendor or product marks. Re-run this script after editing BODIES.
"""
import pathlib

WRAP = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
    'stroke="currentColor" stroke-width="1.6" stroke-linecap="round" '
    'stroke-linejoin="round">{}</svg>\n'
)

C = '<circle cx="{}" cy="{}" r="{}"/>'
L = '<line x1="{}" y1="{}" x2="{}" y2="{}"/>'
P = '<path d="{}"/>'
PL = '<polyline points="{}"/>'
R = '<rect x="{}" y="{}" width="{}" height="{}" rx="{}"/>'

BODIES = {
    # ── status ──────────────────────────────────────────────────────
    "check-circle": C.format(12, 12, 9) + PL.format("8 12.4 11 15.4 16.4 9"),
    "x-circle": C.format(12, 12, 9) + L.format(9, 9, 15, 15) + L.format(15, 9, 9, 15),
    "alert-triangle": (
        P.format("M12 3.6 21.4 20H2.6z") + L.format(12, 9.5, 12, 14)
        + L.format(12, 17, 12, 17.1)
    ),
    "clock": C.format(12, 12, 9) + PL.format("12 7 12 12.4 16 12.4"),
    "flag": P.format("M5 21V4") + P.format("M5 4h11l-2 4 2 4H5"),
    "eye": (
        P.format("M2.5 12S6 5.6 12 5.6 21.5 12 21.5 12 18 18.4 12 18.4 2.5 12 2.5 12z")
        + C.format(12, 12, 3)
    ),
    "gauge": P.format("M4 17a8.5 8.5 0 1 1 16 0") + L.format(12, 12.5, 16.2, 9),
    # ── trend + data ────────────────────────────────────────────────
    "trending-up": PL.format("3 17 9 11 13 15 21 7") + PL.format("15 7 21 7 21 13"),
    "trending-down": PL.format("3 7 9 13 13 9 21 17") + PL.format("15 17 21 17 21 11"),
    "bar-chart": L.format(6, 20, 6, 13) + L.format(12, 20, 12, 8) + L.format(18, 20, 18, 11),
    "pie-chart": C.format(12, 12, 9) + P.format("M12 3v9h9"),
    "layers": P.format("M12 3l9 5-9 5-9-5z") + PL.format("3 12.6 12 17.6 21 12.6"),
    "grid": (
        R.format(3.5, 3.5, 7, 7, 1.5) + R.format(13.5, 3.5, 7, 7, 1.5)
        + R.format(3.5, 13.5, 7, 7, 1.5) + R.format(13.5, 13.5, 7, 7, 1.5)
    ),
    "percent": L.format(5.5, 18.5, 18.5, 5.5) + C.format(7.5, 7.5, 2.4) + C.format(16.5, 16.5, 2.4),
    "dollar": (
        L.format(12, 3, 12, 21)
        + P.format(
            "M16.4 7.6C16.4 5.8 14.5 4.6 12 4.6S7.6 5.8 7.6 8s2 3.2 4.4 3.7 "
            "4.8 1.4 4.8 3.8-2.3 3.5-4.8 3.5-4.4-1.2-4.4-3.2"
        )
    ),
    # ── systems ─────────────────────────────────────────────────────
    "database": (
        '<ellipse cx="12" cy="6" rx="8" ry="3"/>'
        + P.format("M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6")
        + P.format("M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3")
    ),
    "server": (
        R.format(3, 4, 18, 7, 2) + R.format(3, 13, 18, 7, 2)
        + L.format(7, 7.5, 7.1, 7.5) + L.format(7, 16.5, 7.1, 16.5)
    ),
    "cloud": P.format(
        "M7.2 19h9.6a4.1 4.1 0 0 0 .6-8.1A5.6 5.6 0 0 0 6.8 11.4A4 4 0 0 0 7.2 19z"
    ),
    "workflow": (
        R.format(3, 4, 6.5, 6, 1.6) + R.format(14.5, 14, 6.5, 6, 1.6)
        + P.format("M9.5 7h3.5a2 2 0 0 1 2 2v8")
    ),
    "link": (
        P.format("M9.4 14.6a4 4 0 0 1 0-5.7l2-2a4 4 0 0 1 5.7 5.7l-1 1")
        + P.format("M14.6 9.4a4 4 0 0 1 0 5.7l-2 2a4 4 0 0 1-5.7-5.7l1-1")
    ),
    "refresh": (
        P.format("M20 12a8 8 0 1 1-2.6-5.9") + PL.format("20 3 20 7 16 7")
    ),
    "code": PL.format("8.5 8 4.5 12 8.5 16") + PL.format("15.5 8 19.5 12 15.5 16"),
    "terminal": (
        R.format(3, 4, 18, 16, 2) + PL.format("7 10 9.6 12.6 7 15.2")
        + L.format(12.6, 15.2, 17, 15.2)
    ),
    # ── security ────────────────────────────────────────────────────
    "lock": R.format(4, 10, 16, 11, 2) + P.format("M8 10V7a4 4 0 0 1 8 0v3"),
    "shield": P.format("M12 3l8 3v6c0 5-3.4 8.2-8 9.5C7.4 20.2 4 17 4 12V6z"),
    "key": (
        C.format(8, 16, 3.6)
        + P.format("M10.6 13.4 20.5 3.5")
        + P.format("M15.8 8.2l2.4 2.4") + P.format("M18.3 5.7l2.4 2.4")
    ),
    "shield-check": (
        P.format("M12 3l8 3v6c0 5-3.4 8.2-8 9.5C7.4 20.2 4 17 4 12V6z")
        + PL.format("8.6 11.8 11.2 14.4 15.6 9.6")
    ),
    # ── people ──────────────────────────────────────────────────────
    "user": C.format(12, 8, 4) + P.format("M4.5 20.5c0-4.1 3.4-6.6 7.5-6.6s7.5 2.5 7.5 6.6"),
    "users": (
        C.format(9.5, 8, 3.5) + P.format("M3 20.5c0-3.7 2.9-5.8 6.5-5.8s6.5 2.1 6.5 5.8")
        + C.format(17.5, 8.5, 2.8) + P.format("M18 14.8c2.4.5 4 2.4 4 5.2")
    ),
    "message-square": P.format(
        "M4.5 5h15A1.5 1.5 0 0 1 21 6.5v8a1.5 1.5 0 0 1-1.5 1.5H10l-5 4v-4H4.5A1.5 "
        "1.5 0 0 1 3 14.5v-8A1.5 1.5 0 0 1 4.5 5z"
    ),
    "mail": R.format(3, 5, 18, 14, 2) + PL.format("3.6 7 12 13 20.4 7"),
    # ── documents ───────────────────────────────────────────────────
    "file-text": (
        P.format("M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z")
        + PL.format("14 3 14 8 19 8")
        + L.format(8.5, 12.5, 15.5, 12.5) + L.format(8.5, 16.5, 13, 16.5)
    ),
    "folder": P.format(
        "M3 7.5A2 2 0 0 1 5 5.5h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
    ),
    "book": (
        P.format("M4 5.5A2.5 2.5 0 0 1 6.5 3H19v15H6.5A2.5 2.5 0 0 0 4 20.5z")
        + P.format("M19 18v3H6.5")
    ),
    "clipboard-check": (
        P.format(
            "M9 4H7a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2"
        )
        + R.format(9, 2.4, 6, 3.6, 1.2)
        + PL.format("9.2 13 11.6 15.4 15.4 11")
    ),
    "search": C.format(10.5, 10.5, 6.5) + L.format(15.3, 15.3, 20.5, 20.5),
    "filter": P.format("M3 5h18l-7 8.2V19l-4 2v-7.8z"),
    # ── direction + ideas ───────────────────────────────────────────
    "arrow-right": L.format(3.5, 12, 19, 12) + PL.format("13 6 19 12 13 18"),
    "arrow-up-right": L.format(6, 18, 17.5, 6.5) + PL.format("9.5 6.5 17.5 6.5 17.5 14.5"),
    "target": C.format(12, 12, 9) + C.format(12, 12, 5.4) + C.format(12, 12, 1.9),
    "zap": P.format("M13 2.5 4.5 14H10l-1 7.5L19.5 10H13.5z"),
    "lightbulb": (
        P.format("M12 3a6 6 0 0 0-3.5 10.9V16h7v-2.1A6 6 0 0 0 12 3z")
        + L.format(9.5, 18.6, 14.5, 18.6) + L.format(10.5, 21, 13.5, 21)
    ),
    "plus-circle": C.format(12, 12, 9) + L.format(12, 8, 12, 16) + L.format(8, 12, 16, 12),
    "minus-circle": C.format(12, 12, 9) + L.format(8, 12, 16, 12),
    "calendar": (
        R.format(3, 5, 18, 16, 2) + L.format(3, 10, 21, 10)
        + L.format(8, 3, 8, 7) + L.format(16, 3, 16, 7)
    ),
    "map-pin": (
        P.format("M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11z") + C.format(12, 10, 2.6)
    ),
    "settings": (
        C.format(12, 12, 3.2)
        + L.format(12, 2.5, 12, 5.5) + L.format(12, 18.5, 12, 21.5)
        + L.format(2.5, 12, 5.5, 12) + L.format(18.5, 12, 21.5, 12)
        + L.format(5.7, 5.7, 7.8, 7.8) + L.format(16.2, 16.2, 18.3, 18.3)
        + L.format(18.3, 5.7, 16.2, 7.8) + L.format(7.8, 16.2, 5.7, 18.3)
    ),
    # ── clinical (Solventum context) ────────────────────────────────
    "heart-pulse": (
        P.format(
            "M12 20.3S3.7 14.9 3.7 9.5A4.6 4.6 0 0 1 12 6.8a4.6 4.6 0 0 1 8.3 2.7"
            "c0 5.4-8.3 10.8-8.3 10.8z"
        )
        + PL.format("6.2 11.4 9.2 11.4 10.7 8.8 13 14.2 14.6 11.4 17.8 11.4")
    ),
    "hospital": (
        R.format(4, 5, 16, 16, 2)
        + L.format(12, 9.5, 12, 16.5) + L.format(8.5, 13, 15.5, 13)
    ),
    "stethoscope": (
        P.format("M6 3.5v5a4.5 4.5 0 0 0 9 0v-5")
        + P.format("M10.5 13v2.5a4.5 4.5 0 0 0 9 0V13")
        + C.format(19.5, 11, 1.9)
    ),
}


def main():
    out = pathlib.Path(__file__).resolve().parent.parent / "assets/icons"
    out.mkdir(parents=True, exist_ok=True)
    for name, body in sorted(BODIES.items()):
        (out / f"{name}.svg").write_text(WRAP.format(body), encoding="utf-8")
    print(f"wrote {len(BODIES)} icons to {out}")


if __name__ == "__main__":
    main()
