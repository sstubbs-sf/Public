#!/usr/bin/env python3
"""Quality gate for a Solventum HTML deck, one-pager, or exec brief.

    python3 scripts/check_deck.py path/to/deck.html [more.html ...]

Checks the failure modes that are expensive to catch by eye, and cheap to catch here:

  1. LOGO INTEGRITY   the official swoosh path is present, and no stroke-primitive
                      approximation or bare text wordmark is standing in for it
  2. SELF-CONTAINED   no external src/href, CDN, webfont, or remote image
  3. BRAND PURITY     no foreign brand tokens or non-Solventum accent palettes
  4. CONTRAST         #05dd4d is not used as text colour on a light surface
  5. PRINT INTACT     the @page rule and the print overrides survived editing
  6. STRUCTURE        tags balance, deck nav wiring is consistent, no placeholders left

Exit code 0 = pass (warnings allowed), 1 = at least one error.
"""
import argparse
import pathlib
import re
import sys

# The report uses box-drawing and dash characters, and decks are UTF-8. Neither
# can be assumed to survive the platform's locale encoding — on Windows that is
# usually cp1252, and in a bare container it can be ASCII — so pin both ends.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):  # non-standard stream; keep going
        pass

# The first curve of the official Solventum swoosh. Present in every legitimate
# copy of the lockup, whether inlined or URL-encoded in a CSS data URI.
LOGO_MARKER = "M89.5 51.3c0-19.3"

FOREIGN_BRAND = [
    "snowflake", "databricks", "microsoft", "azure", "aws", "amazon", "google",
    "salesforce", "oracle", "sap", "servicenow-logo", "openai", "anthropic",
]
# Palettes that are not in the Solventum system; a stray one usually means a
# component was pasted in from another deck.
FOREIGN_HEX = ["#29b5e8", "#11567f", "#7d44cf", "#635bff", "#ff4b4b", "#1f6feb"]

PLACEHOLDERS = [
    "DECK TITLE HERE", "ONE-PAGER TITLE HERE", "SECTION EYEBROW", "DECK NAME",
    "DOCUMENT TYPE", "DOCUMENT NAME", "MONTH YEAR", "AUDIENCE", "OWNER",
    "Lorem ipsum", "TODO", "TBD", "XXX", "FIXME",
]


class Report:
    def __init__(self, path):
        self.path = path
        self.errors = []
        self.warns = []

    def err(self, msg):
        self.errors.append(msg)

    def warn(self, msg):
        self.warns.append(msg)


def check_logo(t, r):
    n = t.count(LOGO_MARKER)
    if n == 0:
        r.err(
            "logo missing: the official swoosh path was not found. Paste the SVG from "
            "assets/brand/ verbatim — do not redraw it, and do not substitute a text "
            "wordmark or an icon."
        )
        return
    # A hand-drawn stand-in usually shows up as stroke primitives inside an element
    # that is named like the logo.
    for m in re.finditer(r'<svg[^>]*class="[^"]*(?:logo|lockup|wordmark)[^"]*"[^>]*>(.{0,900}?)</svg>',
                         t, re.DOTALL | re.IGNORECASE):
        frag = m.group(1)
        if LOGO_MARKER not in frag and re.search(r"<(line|polyline|circle|ellipse|rect)\b", frag):
            r.err(
                "logo approximation: an element classed as a logo is built from stroke "
                "primitives instead of the official path."
            )
            break
    # A text-only wordmark is a fallback, not the logo. Flag it only if it looks like
    # it is doing the logo's job in the brand chrome.
    if re.search(r'class="[^"]*(?:logo|lockup|wordmark)[^"]*"[^>]*>\s*[Ss]olventum\.?\s*<', t):
        r.err("text wordmark is standing in for the lockup in a logo slot.")


def check_self_contained(t, r):
    for m in re.finditer(r'\b(?:src|href)\s*=\s*["\']([^"\']+)["\']', t):
        url = m.group(1).strip()
        if url.startswith(("#", "data:", "mailto:", "tel:")):
            continue
        if url.startswith(("http://", "https://", "//")):
            # A link the reader clicks is fine; a resource the page loads is not.
            tag_start = t.rfind("<", 0, m.start())
            tag = t[tag_start:m.start()].lower()
            if "<a" in tag:
                continue
            r.err(f"external resource loaded at render time: {url}")
        else:
            r.err(f"relative file reference breaks the single-file guarantee: {url}")
    # Require the at-rule as it is actually written — followed by a url() or a
    # quoted path — so a deck that merely names @import in prose is not failed.
    if re.search(r"@import\s+(?:url\(|['\"])", t, re.IGNORECASE):
        r.err("@import pulls in an external stylesheet.")
    if re.search(r"@font-face\s*\{", t):
        r.err("@font-face: use the system font stack instead of a webfont.")
    # Any absolute URL inside url() breaks self-containment, whether or not the
    # host is a known CDN — a tracking pixel on a private host is still a
    # network call and still leaks who opened the deck.
    for m in re.finditer(r'url\(\s*["\']?\s*((?:https?:)?//[^"\')\s]+)', t, re.IGNORECASE):
        r.err(f"external URL in CSS url(): {m.group(1)}")
    # Scope the CDN scan to URL-ish context, so prose that merely mentions a CDN
    # (including this skill's own comments) does not trip the gate.
    for m in re.finditer(r'(?:https?:)?//[^\s"\'()<>]+|url\(\s*["\']?([^"\')]+)', t, re.IGNORECASE):
        frag = (m.group(0) or "").lower()
        if frag.startswith("url(") and "data:" in frag:
            continue
        for bad in ("cdn.", "unpkg.com", "jsdelivr", "fonts.googleapis", "cdnjs", "googleapis.com"):
            if bad in frag:
                r.err(f"CDN reference found: {bad}")
    if re.search(r'\bfetch\s*\(|XMLHttpRequest|new\s+Image\s*\(\s*["\']http', t):
        r.err("runtime network call found; the file must render with no network.")


def check_no_active_content(t, r):
    """Reject executable content that arrives with pasted-in art.

    A deck is a file people email onward and open locally, so it must not carry
    anything that runs on its own. The usual way this happens is not malice but
    an SVG downloaded from the internet and pasted in with an onload handler or
    a <foreignObject> still attached.
    """
    for m in re.finditer(r"<[^>]*?\s(on[a-z]+)\s*=", t, re.IGNORECASE):
        r.err(f"inline event handler '{m.group(1)}' — move behaviour into the deck's script "
              "block, or strip it if it came from pasted art")
    for m in re.finditer(r'(?:href|src|to|from|values)\s*=\s*["\']?\s*javascript:', t, re.IGNORECASE):
        r.err("javascript: URL found")
    for tag in ("iframe", "object", "embed", "foreignobject", "use", "image"):
        for m in re.finditer(rf"<\s*{tag}\b", t, re.IGNORECASE):
            r.err(f"<{tag}> is not allowed: it can load or execute external content. "
                  "Icons must be plain shape elements — run scripts/normalize_icon.py "
                  "over any SVG taken from the internet")
            break
    # Animation elements can retarget an href to a javascript: URL at runtime.
    for m in re.finditer(r"<\s*(animate|animatetransform|animatemotion|set)\b", t, re.IGNORECASE):
        r.err(f"<{m.group(1).lower()}> animation element found in art; strip it")
        break


def check_brand(t, r):
    low = t.lower()
    for name in FOREIGN_BRAND:
        # A deck may legitimately name a vendor in prose, so this is a warning.
        # It becomes an error only where the name sits in a logo or brand slot,
        # which means another company's identity is being presented as ours.
        # Word-bounded: an unbounded scan matches "sap" inside "disappears".
        word = re.compile(rf"(?<![a-z0-9]){re.escape(name)}(?![a-z0-9])")
        if not word.search(low):
            continue
        if re.search(rf'class="[^"]*(?:logo|lockup|wordmark|brand)[^"]*"[^>]*>[^<]*{re.escape(name)}',
                     low, re.IGNORECASE):
            r.err(f"foreign brand '{name}' is occupying a logo or brand slot")
        else:
            r.warn(f"foreign brand reference: '{name}' — confirm it belongs in this deck")
    for hexv in FOREIGN_HEX:
        if hexv in low:
            r.warn(f"off-palette colour {hexv} — check it against assets/brand/BRAND.md")


def check_contrast(t, r):
    # #05dd4d on white is ~1.7:1. Legal as an accent or a large fill, not as text.
    for m in re.finditer(r"(?<!-)\bcolor\s*:\s*(#05dd4d|var\(--brand\))", t, re.IGNORECASE):
        start = max(0, m.start() - 400)
        ctx = t[start:m.start()].lower()
        # Inside .slide.title / .brand-bar / .inverse / .arch-box the surface is dark.
        on_dark = any(k in ctx for k in (
            ".slide.title", ".brand-bar", ".inverse", ".arch-box", ".arch-title", "--inverse",
        ))
        if not on_dark:
            r.warn(
                "--brand (#05dd4d) used as a text colour outside a dark surface — "
                "roughly 1.7:1 on white. Use --brand-deep (#0a7d38) for text."
            )
            break


def check_print(t, r):
    # Match the at-rule as it is actually written (start of a line, brace on the
    # same line), not prose in a comment that happens to mention it.
    has_page = re.search(r"^\s*@page\b[^{\n]*\{", t, re.MULTILINE)
    has_print = re.search(r"^\s*@media\s+print\b[^{\n]*\{", t, re.MULTILINE)
    if not has_page:
        r.err("no @page rule: PDF export will not set page size or margins.")
    elif re.search(r"@media\s+print\b[^{]*\{(?:[^{}]|\{[^{}]*\})*?@page", t, re.DOTALL):
        r.warn("@page appears nested inside @media print; keep it at top level.")
    if not has_print:
        r.err("no @media print block: the deck will print with screen chrome.")
        return
    if "print-color-adjust" not in t:
        r.warn("no print-color-adjust: brand colours may drop out of the PDF.")
    is_deck = 'class="deck"' in t or "class='deck'" in t
    if is_deck:
        if not re.search(r"page-break-after|break-after", t):
            r.err("deck print CSS has no page break: slides will run together.")
        if not re.search(r"max-height\s*:\s*none", t):
            r.err(
                "print CSS does not release .slide-body max-height/overflow — on paper "
                "overflow:auto clips silently."
            )


def check_structure(t, r):
    for tag in ("div", "section", "span", "table", "tr", "td", "ul", "li", "svg"):
        opens = len(re.findall(rf"<{tag}\b", t, re.IGNORECASE))
        closes = len(re.findall(rf"</{tag}\s*>", t, re.IGNORECASE))
        if opens != closes:
            r.err(f"unbalanced <{tag}>: {opens} open, {closes} close")

    slides = re.findall(r'<section[^>]*class="[^"]*\bslide\b[^"]*"', t)
    if slides:
        active = [s for s in slides if "active" in s]
        if len(active) != 1:
            r.err(f"{len(active)} slides carry 'active'; exactly one should on load.")
        # Content slides (not the title/divider) should carry the brand footer.
        content = [s for s in slides if "title" not in s]
        footers = t.count('class="slide-footer"')
        if content and footers < len(content):
            r.warn(f"{len(content)} content slides but {footers} slide-footer blocks.")
        for el in ("prev-btn", "next-btn", "count", "progress-bar"):
            if f'id="{el}"' not in t:
                r.err(f"nav element #{el} is missing; the deck will not navigate.")
        if "keydown" not in t:
            r.warn("no keydown handler: arrow-key navigation is gone.")

    found = [p for p in PLACEHOLDERS if p in t]
    if found:
        r.warn("unfilled placeholder text: " + ", ".join(sorted(set(found))[:6]))


def check_file(path):
    r = Report(path)
    try:
        t = path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        r.err(f"cannot read file: {e}")
        return r
    if not t.lstrip().lower().startswith("<!doctype html"):
        r.warn("missing <!DOCTYPE html>")
    check_logo(t, r)
    check_self_contained(t, r)
    check_no_active_content(t, r)
    check_brand(t, r)
    check_contrast(t, r)
    check_print(t, r)
    check_structure(t, r)
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()

    failed = False
    for f in args.files:
        r = check_file(pathlib.Path(f))
        head = f"── {r.path}"
        print(head)
        if not r.errors and not r.warns:
            print("   PASS — no issues found\n")
            continue
        for e in r.errors:
            print(f"   ERROR  {e}")
        for w in r.warns:
            print(f"   warn   {w}")
        print(f"   {len(r.errors)} error(s), {len(r.warns)} warning(s)\n")
        failed = failed or bool(r.errors)

    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
