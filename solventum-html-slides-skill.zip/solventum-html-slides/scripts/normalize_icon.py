#!/usr/bin/env python3
"""Force an arbitrary SVG into the deck's icon house style.

Usage:
    python3 scripts/normalize_icon.py path/to/icon.svg [--name my-icon] [--stdout]

What it does:
  - rewrites the root <svg> attributes to viewBox="0 0 24 24", fill="none",
    stroke="currentColor", stroke-width 1.6, round caps and joins
  - rescales the viewBox to 24x24 via a wrapping <g transform> when the source
    viewBox is a different size, so paths do not have to be re-authored
  - sanitizes the art down to an allowlist of shape elements and geometry
    attributes, so the icon inherits colour and carries no executable content
  - refuses non-square art, which would not line up with the rest of the set

Security note: the input is usually a file downloaded from the internet, and the
output is pasted inline into an HTML deck. An SVG inlined into HTML runs in the
page's origin, so a permissive filter here would turn a downloaded icon into
stored XSS in every deck that uses it. The filter is therefore an allowlist:
anything not named below is dropped, rather than a denylist of known-bad names.

Writes to assets/icons/<name>.svg unless --stdout is given.
"""
import argparse
import pathlib
import re
import sys

# Messages contain dashes, and SVGs are UTF-8; do not rely on the platform's
# locale encoding, which is cp1252 on Windows and can be ASCII in a container.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

TARGET = 24.0
ROOT_ATTRS = (
    'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
    'stroke="currentColor" stroke-width="1.6" stroke-linecap="round" '
    'stroke-linejoin="round"'
)
# A 24px line icon only ever needs these. Everything else — script, a, use,
# image, foreignObject, animate/set (which can animate an href into a
# javascript: URL), and any unknown element — is dropped.
ALLOWED_ELEMENTS = {
    "g", "path", "circle", "ellipse", "rect", "line", "polyline", "polygon",
}
# Geometry and shape-hint attributes only. No href, no on* handlers, no style,
# and no fill/stroke, which would defeat colour inheritance. width/height are
# geometry on <rect>, so they stay; the root <svg> is rebuilt from ROOT_ATTRS,
# so a source width/height can never pin the icon's display size.
ALLOWED_ATTRS = {
    "d", "cx", "cy", "r", "rx", "ry", "x", "y", "x1", "y1", "x2", "y2",
    "width", "height", "points", "transform", "fill-rule", "clip-rule",
    "vector-effect", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit",
    "pathlength",
}
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
# name="value" | name='value' | name=value | name
ATTR_RE = re.compile(r"""([A-Za-z_:][-\w:.]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?""")
TAG_RE = re.compile(r"<\s*(/?)\s*([A-Za-z_:][-\w:.]*)((?:[^>\"']|\"[^\"]*\"|'[^']*')*)/?\s*>")



def parse_viewbox(svg: str):
    m = re.search(r'viewBox\s*=\s*["\']([^"\']+)["\']', svg)
    if not m:
        w = re.search(r'\bwidth\s*=\s*["\']([\d.]+)', svg)
        h = re.search(r'\bheight\s*=\s*["\']([\d.]+)', svg)
        if w and h:
            return 0.0, 0.0, float(w.group(1)), float(h.group(1))
        return None
    parts = re.split(r"[,\s]+", m.group(1).strip())
    if len(parts) != 4:
        return None
    return tuple(float(p) for p in parts)


def clean_attrs(raw: str) -> str:
    """Keep only allowlisted geometry attributes, re-quoted."""
    out = []
    for m in ATTR_RE.finditer(raw):
        name = m.group(1).lower()
        if name not in ALLOWED_ATTRS:
            continue
        val = next((g for g in m.group(2, 3, 4) if g is not None), "")
        # Values are geometry, so anything outside this set is not a coordinate.
        val = re.sub(r"[^0-9A-Za-z ,.\-+()%#]", "", val)
        out.append(f'{name}="{val}"')
    return (" " + " ".join(out)) if out else ""


def sanitize(body: str, dropped: set) -> str:
    """Rebuild the art from an allowlist of elements and attributes.

    Text between tags is discarded: an icon has no text content, and keeping it
    would preserve the body of a dropped <script>.
    """
    out = []
    for m in TAG_RE.finditer(body):
        closing, tag, attrs = m.group(1), m.group(2).lower(), m.group(3)
        if tag not in ALLOWED_ELEMENTS:
            dropped.add(tag)
            continue
        if closing:
            out.append(f"</{tag}>")
        elif tag == "g":
            out.append(f"<g{clean_attrs(attrs)}>")
        else:
            out.append(f"<{tag}{clean_attrs(attrs)}/>")
    return "".join(out)


def inner(svg: str, dropped: set) -> str:
    m = re.search(r"<svg\b[^>]*>(.*)</svg\s*>", svg, re.DOTALL | re.IGNORECASE)
    if not m:
        sys.exit("error: no <svg> element found")
    return sanitize(m.group(1), dropped)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("--name", help="output filename stem (default: source stem)")
    ap.add_argument("--stdout", action="store_true", help="print instead of writing")
    args = ap.parse_args()

    src = pathlib.Path(args.src)
    if not src.exists():
        sys.exit(f"error: {src} not found")
    raw = src.read_text(encoding="utf-8")

    vb = parse_viewbox(raw)
    if not vb:
        sys.exit("error: could not determine a viewBox or width/height")
    x, y, w, h = vb
    if w <= 0 or h <= 0:
        sys.exit("error: viewBox has zero extent")
    ratio = max(w, h) / min(w, h)
    if ratio > 1.15:
        sys.exit(
            f"error: art is {w:g}x{h:g} (ratio {ratio:.2f}) — not square enough for the "
            "icon set. Crop or pad it to a square viewBox first."
        )

    dropped = set()
    body = inner(raw, dropped)
    if not body:
        sys.exit("error: nothing survived sanitizing — no shape elements in the source")
    scale = TARGET / max(w, h)
    if abs(scale - 1.0) > 1e-6 or x or y:
        # Translate first, then scale, so the source origin lands at 0,0.
        body = f'<g transform="scale({scale:.6g}) translate({-x:.6g} {-y:.6g})">{body}</g>'

    out_svg = f"<svg {ROOT_ATTRS}>{body}</svg>\n"
    if dropped:
        print(f"note: dropped non-shape elements: {', '.join(sorted(dropped))}",
              file=sys.stderr)

    if args.stdout:
        print(out_svg, end="")
        return
    name = args.name or src.stem
    if not NAME_RE.match(name):
        sys.exit(f"error: --name must be lowercase letters, digits, and hyphens: {name!r}")
    icons = (pathlib.Path(__file__).resolve().parent.parent / "assets/icons").resolve()
    dest = (icons / f"{name}.svg").resolve()
    # Belt and braces: NAME_RE already excludes separators, but confirm the
    # resolved path really is inside the icon folder before writing.
    if dest.parent != icons:
        sys.exit(f"error: refusing to write outside {icons}")
    dest.write_text(out_svg, encoding="utf-8")

    print(f"wrote {dest} ({len(out_svg)} bytes)")
    print("Preview it next to the set before using it — a normalized icon can still be "
          "too heavy or too detailed for 24px.")


if __name__ == "__main__":
    main()
