"""Compose assets/onepager.html from the shared CSS in assets/shell.html.

Run once. Regenerating keeps the one-pager's tokens, typography, and component
CSS byte-identical to the deck shell, so a token edit in shell.html can be
propagated by re-running this script.
"""
import pathlib

S = pathlib.Path(__file__).resolve().parent.parent
shell = (S / "assets/shell.html").read_text(encoding="utf-8")


def between(a, b):
    i = shell.index(a)
    j = shell.index(b)
    assert i < j, (a, b)
    return shell[i:j].rstrip() + "\n"


reset_tokens = between("  * { box-sizing", "  html, body { height: 100%; }")
typography = between("  /* \u2500\u2500 TYPOGRAPHY", "  /* \u2500\u2500 TITLE /")
components = between("  /* \u2500\u2500 CALLOUTS", "  /* \u2500\u2500 CHROME:")

white = (S / "assets/brand/solventum-logo-horz-white.svg").read_text(encoding="utf-8").strip()
logo = white.replace("<svg ", '<svg class="bar-logo" ', 1)
assert 'class="bar-logo"' in logo

PAGE_CSS = """  html { background: var(--canvas); }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, system-ui, sans-serif;
    background: var(--canvas); color: var(--ink);
    -webkit-font-smoothing: antialiased; padding: 26px 16px 60px;
  }

  /* PAGE */
  .page {
    width: min(980px, 100%); margin: 0 auto; background: var(--bg);
    border: 1px solid var(--border); border-radius: 14px; overflow: hidden;
    box-shadow: 0 10px 34px rgba(6,48,28,.10);
  }

  /* BRAND BAR */
  .brand-bar {
    background: var(--header-grad); color: #fff; padding: 26px 34px 24px;
    display: flex; flex-direction: column; gap: 16px;
  }
  .brand-bar .bar-logo { height: 26px; width: auto; align-self: flex-start; }
  .brand-bar .eyebrow { color: var(--brand); }
  .brand-bar h1 { color: #fff; font-size: 30px; max-width: 34ch; margin-top: 4px; }
  .brand-bar .sub { color: rgba(255,255,255,.82); font-size: 15px; max-width: 78ch; }

  /* META STRIP */
  .meta-strip {
    display: flex; flex-wrap: wrap; gap: 0 34px;
    background: var(--panel); border-bottom: 1px solid var(--border); padding: 13px 34px;
  }
  .meta-item { font-size: 12px; color: var(--muted); }
  .meta-item b {
    display: block; font-size: 10.5px; font-weight: 800; letter-spacing: .08em;
    text-transform: uppercase; color: var(--brand-deep); margin-bottom: 3px;
  }

  /* DOCUMENT BODY */
  .doc { padding: 30px 34px 34px; display: flex; flex-direction: column; gap: 26px; }
  .doc > section { display: flex; flex-direction: column; gap: 13px; }
  .sec-head {
    display: flex; align-items: baseline; gap: 11px;
    border-bottom: 2px solid var(--border); padding-bottom: 8px;
  }
  .sec-num {
    font-size: 12px; font-weight: 800; color: var(--brand-deep);
    font-variant-numeric: tabular-nums;
  }
  .sec-title { font-size: 19px; font-weight: 800; letter-spacing: -.01em; color: var(--ink); }
  .sec-note { margin-left: auto; font-size: 11px; color: var(--muted); }

  /* PAGE FOOTER */
  .page-footer {
    border-top: 1px solid var(--border); padding: 16px 34px 20px;
    display: flex; align-items: center; justify-content: space-between; gap: 18px;
    font-size: 11.5px; color: var(--muted); background: var(--panel);
  }
  .page-footer::before {
    content: ""; display: block; width: 104px; height: 19px; flex-shrink: 0;
    background: var(--logo-dark) no-repeat left center / contain;
  }

  /* PRINT - portrait, flows across pages */
  @page { size: portrait; margin: 12mm 12mm 14mm; }
  @media print {
    * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    body { padding: 0; background: #fff; }
    .page { width: 100%; border: none; border-radius: 0; box-shadow: none; }
    /* Keep a unit of meaning on one page rather than splitting it across the fold. */
    .doc > section, .card, .tier-card, .step-item, .qa-row, .callout, .arch-box,
    .mini-card, .stat, .bar-row { break-inside: avoid; page-break-inside: avoid; }
    .sec-head { break-after: avoid; page-break-after: avoid; }
    .dtable thead { display: table-header-group; }
    .dtable tr { break-inside: avoid; }
    .pop { display: none !important; }
  }
"""

BODY = """
<div class="page">

  <header class="brand-bar">
    <!-- Official Solventum lockup, white wordmark. Pasted verbatim - never redraw it. -->
    __LOGO__
    <div>
      <div class="eyebrow">DOCUMENT TYPE</div>
      <h1>The recommendation, stated as a sentence</h1>
    </div>
    <div class="sub">Two lines of context: the decision on the table and what happens next.</div>
  </header>

  <div class="meta-strip">
    <div class="meta-item"><b>Audience</b>AUDIENCE</div>
    <div class="meta-item"><b>Owner</b>OWNER</div>
    <div class="meta-item"><b>Date</b>MONTH YEAR</div>
    <div class="meta-item"><b>Status</b>Draft for review</div>
  </div>

  <div class="doc">

    <section>
      <div class="sec-head">
        <span class="sec-num">01</span>
        <span class="sec-title">Where we are</span>
      </div>
      <!-- Components drop in here. See references/components.md. -->
    </section>

    <section>
      <div class="sec-head">
        <span class="sec-num">02</span>
        <span class="sec-title">What we recommend</span>
        <span class="sec-note">Optional right-aligned note</span>
      </div>
    </section>

    <section>
      <div class="sec-head">
        <span class="sec-num">03</span>
        <span class="sec-title">What we need</span>
      </div>
    </section>

  </div>

  <footer class="page-footer">
    <span>DOCUMENT NAME &middot; MONTH YEAR &middot; Internal</span>
  </footer>

</div>
"""

HEAD = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>ONE-PAGER TITLE HERE</title>
<style>
  /* ==============================================================
     SOLVENTUM HTML SLIDES - ONE-PAGER / EXEC BRIEF SHELL
     Same tokens and components as assets/shell.html, laid out as a
     single scrolling document that prints portrait across pages.
     Token reference: assets/brand/BRAND.md
     Components:      references/components.md
     Generated by scripts/build_onepager.py from shell.html.
     ============================================================== */

"""

html = (
    HEAD
    + reset_tokens
    + "\n"
    + PAGE_CSS
    + "\n"
    + typography
    + "\n"
    + components
    + "</style>\n</head>\n<body>\n"
    + BODY.replace("__LOGO__", logo)
    + "</body>\n</html>\n"
)

out = S / "assets/onepager.html"
out.write_text(html, encoding="utf-8")
print("bytes:", out.stat().st_size)
print("logo marker count:", html.count("M89.5 51.3c0-19.3"))
print("tokens present:", "--brand-deep: #0a7d38" in html)
for cls in (".callout {", ".dtable {", ".ipill {", ".cards {", ".stat {", ".arch-box {"):
    assert cls in html, cls
print("component CSS present: ok")
