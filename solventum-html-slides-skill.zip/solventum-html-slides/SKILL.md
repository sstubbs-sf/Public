---
name: solventum-html-slides
description: Build Solventum-branded HTML slide decks, one-pagers, and executive briefs as single self-contained files, with the official logo, brand colour system, component library, and landscape PDF export. Use whenever the user wants to build a deck, presentation, slide, exec brief, one-pager, board or steering-committee readout, QBR, roadmap, or any Solventum-styled HTML document. Triggers: build a deck, create a presentation, make a slide, HTML presentation, Solventum branded, exec brief, one-pager, executive summary, board deck, steering committee, QBR, roadmap deck, readout, leadership update, slide deck, export to PDF.
---

# Solventum HTML Slides

Build presentation-grade HTML in Solventum branding. Output is a **single self-contained `.html`
file** — no CDN, no webfont, no sidecar assets — that opens anywhere, emails cleanly, and prints
to landscape PDF with one slide per page.

Everything needed ships in this skill. Nothing is loaded from the network at render time.

## Files in this skill

| Path | What it is | When to read it |
|---|---|---|
| `assets/shell.html` | Deck shell: tokens, all component CSS, nav JS, print CSS | Copy for every deck |
| `assets/onepager.html` | One-pager / exec-brief shell, same tokens, prints portrait | Copy for every brief |
| `assets/brand/BRAND.md` | Logo rules, colour tokens, contrast rule, type scale, geometry | Before any colour or logo decision |
| `assets/brand/*.svg` | The three official logo forms | Paste from these, verbatim |
| `assets/icons/*.svg` | 50 neutral line icons | When a slide needs iconography |
| `references/components.md` | Copy-paste markup for every component, plus the slide budget | While building slides |
| `references/icon-index.md` | Icon names, usage, and how to add one | When choosing an icon |
| `examples/example-deck.html` | Worked 5-slide deck; passes the quality gate | To see the target quality |
| `scripts/check_deck.py` | Quality gate — run before you hand anything over | Always, before delivery |
| `scripts/normalize_icon.py` | Force an arbitrary SVG into the icon house style | Adding a custom icon |
| `scripts/build_icons.py`, `build_onepager.py`, `build_example.py` | Regenerate the shipped assets | Only when changing the system itself |

## Accuracy and sourcing — non-negotiable

A deck is an argument someone will act on. A wrong number in a beautiful deck is worse than no
deck, because the polish buys it trust it has not earned.

- **Never invent a number, date, name, owner, or status.** If the user has not supplied it, ask, or
  write the placeholder in visible caps (`TBD — OWNER`) so it cannot ship unnoticed.
- **Do not round in a flattering direction.** 41% is 41%, not "over 40%".
- **Every slide carrying figures gets a `.source-note`** naming the system, date range, and any
  exclusions. If you cannot name the source, the number does not go on the slide.
- **Chart geometry must match the data.** A bar at 60% width for a 12% value is a false statement.
  If a true-to-scale bar is invisible, that is the finding — label it, do not inflate it.
- **Do not restate the user's claims as measured results.** "Expected" and "achieved" are different
  slides.

## The logo

Paste the SVG verbatim from `assets/brand/`. Never redraw, reconstruct, or substitute it — not with
stroke primitives, not with an icon, not with a text-only `Solventum.` wordmark. The lockup is the
one element every reader recognises instantly, so a wrong one discredits the whole document.

- Deep-green or dark surface → `solventum-logo-horz-white.svg`
- White or light surface → `solventum-logo-horz-dark.svg`
- Tight space, bar, favicon → `solventum-mark-green.svg`

In the deck shell, the title slide carries the inline white lockup and content-slide footers draw
the ink lockup from the `--logo-dark` token. Both are already wired; do not replace them.

## Colour, in one paragraph

`#05dd4d` is the logo green and it is **roughly 1.7:1 on white** — it fails accessible contrast for
text and vanishes on a projector. Use `var(--brand-deep)` (`#0a7d38`) for anything text-sized on a
light surface, and reserve `var(--brand)` for the logo, accents on deep green, and fills 24px or
larger. Full token table in `assets/brand/BRAND.md`.

---

## Workflow

### 1. Establish the argument — before touching HTML

Ask for what you do not have. Do not guess at these:

- **Audience and decision.** Who is in the room, and what do they need to decide or approve?
- **The one-sentence takeaway.** If the audience remembers one thing, what is it?
- **The source material.** Numbers, status, owners, dates — and where they came from.
- **Format.** Navigable deck, one-pager / exec brief, or both.
- **Length.** Executive readouts land at 5-8 slides. A 20-slide deck for a 15-minute slot is a
  planning failure, not a thoroughness win.

Use `ask_user_question` for anything genuinely blocking. Do not ask what you can read from files
the user has already given you.

### 2. Outline, and stop

Write the slide-by-slide outline as **headline sentences**, not topics. "Automation is now the
cheapest capacity we have" is a headline; "Automation update" is a label. If the headlines read in
sequence do not make the argument on their own, the deck will not either.

For each slide name the component you will use (see the mapping table below).

**STOP. Show the outline and get agreement before building.** Restructuring an outline costs a
minute; restructuring 12 slides of HTML costs an hour, and the user will have stopped reading.

### 3. Build

Copy `assets/shell.html` (deck) or `assets/onepager.html` (brief) to the target path. Then:

1. Set `<title>`, the title slide, and the footer note.
2. Add one `<section class="slide">` per outline slide, each with a `.slide-body` and a
   `.slide-footer`.
3. Paste components from `references/components.md` as direct children of `.slide-body`.
4. Update the nav counter text (`1 / N`) to the real slide count.

Never write your own CSS. Every class in the gallery is already defined in both shells. If you
find yourself adding a style rule, you are almost certainly rebuilding a component that exists —
check the gallery first. Genuine one-offs belong in a `style="--c:var(--amber)"` attribute, not a
new rule.

### 4. Verify

```bash
python3 scripts/check_deck.py path/to/deck.html
```

Fix every ERROR. Read every warning and decide deliberately.

Then look at it. The gate cannot see layout: open the file, arrow through every slide, and confirm
no `.slide-body` scrolls. A scrolling slide is a slide the room cannot read — split it, or add
`dense` to the `<section class="slide">` for about 20% more room.

Check the PDF too: click **PDF**, choose landscape, and confirm one slide per page with nothing
clipped.

### 5. Hand over

Report the file path, the slide count, and anything you had to leave as a placeholder. Call out
explicitly any number you could not source — that is the thing most likely to embarrass the user
in the room.

---

## Content to component

| The content is... | Use | Notes |
|---|---|---|
| A single point that deserves the whole slide | headline + `.callout` | The strongest slide in the system |
| Before / after, old / new, us / them | `.two-col` with `ul.clean` and `ul.clean check` | The check list is the "after" side |
| 3-6 parallel items, each a sentence | `.cards` (3-up) or `.cards.two` | Add `.tag` for stage or status |
| 4-8 labels with no prose | `.cards.four` | Two rows maximum |
| Time horizons (now / next / later) | `.tier-grid` with `--c` per card | Green, amber, indigo — not red |
| A sequence of 4-6 actions | `.steps-grid` | Above 6, switch to `.scenes` |
| A sequence of 6-9 stages, or a storyboard | `.scenes` | Densest sequence layout |
| Rows and columns of facts | `.dtable` with `.pill` and `.badge` | `.num` for figures; `dense` past 8 rows |
| Headline metrics | `.stat-grid` | 4 maximum, each with a `.stat-note` |
| Two quantities compared | `.bars` with one `.hero` row | Widths must be proportional |
| A pipeline, flow, or system path | `.arch-box` with `.hl` / `.hl2` / `.hl3` | ASCII, dark panel, prints cleanly |
| 4-6 supporting facts | `.mini-card` in a `.two-col` | Compact, left accent |
| Objections you expect | `.qa-grid` | Use the room's own words |
| A definition or caveat that would clutter the slide | `.ipill` tooltip | Never load-bearing — hidden in print |
| The ask, or the closing statement | `.callout inverse` | Once per deck |

## Quality gates

Before handing anything over, all of these are true:

- [ ] `scripts/check_deck.py` reports no errors
- [ ] The official logo is pasted verbatim; no redraw, no text substitute
- [ ] Every figure has a `.source-note`; nothing is invented
- [ ] Bar and chart geometry is proportional to the values
- [ ] No `.slide-body` scrolls at 1120x690
- [ ] `var(--brand)` is not used as text on a light surface
- [ ] Landscape PDF gives one slide per page, nothing clipped
- [ ] Exactly one slide carries `active`; the nav counter shows the real total
- [ ] Opens with no network: no CDN, webfont, or external `src`
- [ ] Any SVG taken from outside `assets/icons/` was run through
      `scripts/normalize_icon.py` first — pasted art can carry an `onload` handler or a
      `<foreignObject>`, and an SVG inlined into HTML executes in the page's origin
- [ ] Headlines read as an argument when read in sequence

## Habits worth keeping

**Headlines are sentences.** A slide titled "Risks" tells the reader nothing; "Two feeds are still
manual, so the numbers lag a day" tells them everything and survives being forwarded without you.

**One idea per slide.** If a slide needs three components to make its point, it is two slides that
have not been separated yet.

**Say the ask plainly, once.** Use `.callout inverse` exactly once, on the decision. Two of them and
neither reads as important.

**Let white space work.** `.slide-body` centres content when it fits. Do not pad a sparse slide to
look busy — a deliberate single-point slide is a strength.

**Same treatment, same meaning.** If amber means "watch" on slide 3, it cannot mean "in progress" on
slide 6. Inconsistent colour makes the reader re-learn the deck on every slide.

## Handing the file to someone at Solventum

The output is one `.html` file. It opens in any browser with no install, no network, and no
attachments. To hand over the *skill* rather than a deck, zip this folder and drop it in
`~/.snowflake/cortex/skills/` (or a project's `.cortex/skills/`) — see `README.md`.
