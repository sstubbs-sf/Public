# Icon Index

50 neutral line icons in `assets/icons/`. All are 24x24, `stroke="currentColor"`, `fill="none"`,
stroke-width 1.6, round caps. They inherit colour from the parent, so the same file works on white
and on deep green.

## How to use one

Open the `.svg` file, copy its contents, and paste it inline inside a `.icon` wrapper. Do not
reference the file with `<img src>` — an external reference breaks the single-file guarantee.

```html
<span class="icon" style="color:var(--brand-deep)">
  <!-- paste assets/icons/shield-check.svg here -->
</span>
```

In a chip (the usual treatment beside a card heading):

```html
<div class="icon-chip"><span class="icon"><!-- icon svg --></span></div>
```

Recolour by setting `color` on the wrapper: `var(--green)`, `var(--amber)`, `var(--red)`,
`var(--indigo)`, or `#fff` on a dark panel. Never set `fill` — these are stroke icons.

## Available icons

| Group | Names |
|---|---|
| Status | `check-circle` `x-circle` `alert-triangle` `clock` `flag` `eye` `gauge` |
| Trend & data | `trending-up` `trending-down` `bar-chart` `pie-chart` `layers` `grid` `percent` `dollar` |
| Systems | `database` `server` `cloud` `workflow` `link` `refresh` `code` `terminal` |
| Security | `lock` `shield` `shield-check` `key` |
| People | `user` `users` `message-square` `mail` |
| Documents | `file-text` `folder` `book` `clipboard-check` `search` `filter` |
| Direction & ideas | `arrow-right` `arrow-up-right` `target` `zap` `lightbulb` `plus-circle` `minus-circle` `calendar` `map-pin` `settings` |
| Clinical | `heart-pulse` `hospital` `stethoscope` |

## Choosing an icon

Icons should carry meaning, not decorate. A slide where every card has an icon and none of them
mean anything is worse than a slide with no icons, because the reader spends attention decoding
them and gets nothing back.

- Use an icon when it labels a **category** the reader will scan for (a security item vs a data item).
- Skip icons on slides that are already dense with numbers or tags.
- Use one icon per card, at one size, in one colour family per slide.

## Adding your own

Run `scripts/normalize_icon.py` on any pasted SVG to force it into house style:

```bash
python3 scripts/normalize_icon.py my-icon.svg --name pipeline
```

It rewrites the wrapper attributes (viewBox, stroke, widths, caps), rescales a non-24 viewBox,
and filters the art down to an allowlist of shape elements and geometry attributes before writing
`assets/icons/pipeline.svg`. It will refuse an SVG whose viewBox is not square-ish, because a
non-square icon will not sit correctly next to the rest of the set.

**Always run it on art from the internet.** An SVG inlined into HTML runs in the page's origin, so
a downloaded icon can carry an `onload` handler, a `javascript:` link, or a `<foreignObject>` that
would execute when someone opens the deck. The normalizer drops all of that and prints what it
removed. Anything it strips that you actually needed was not a 24px line icon.
