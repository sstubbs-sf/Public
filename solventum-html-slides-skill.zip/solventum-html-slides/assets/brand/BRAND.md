# Solventum Brand System — HTML Slides

Everything the deck system needs, in one place. These values are already in production in the
Solventum IT Scorecard application, so decks built here sit next to the app without a colour clash.

---

## Logo assets (in this folder)

| File | Use |
|---|---|
| `solventum-logo-horz-white.svg` | Horizontal lockup, white wordmark + green swoosh. For the **deep-green** brand bar, title slide, and any dark surface. |
| `solventum-logo-horz-dark.svg` | Same lockup with an ink (`#10201b`) wordmark. For **white / light** surfaces. |
| `solventum-mark-green.svg` | The swoosh mark alone (`viewBox="0 0 202.4 276.9"`). For compact bars, footers, favicons, bullet accents. |

### Never redraw the logo

Paste the SVG **verbatim** from these files. Do not hand-draw, reconstruct, simplify, or substitute it.
Specifically, do not:

- rebuild the swoosh from `<line>`/`<circle>`/stroke primitives
- use an emoji, an icon glyph, or a "close enough" S shape
- ship a text-only `Solventum.` wordmark where the lockup belongs (a text wordmark is a *fallback*, not the logo)
- omit the logo

A wrong logo is a defect even when everything else is perfect, because it is the one element a
reader recognises instantly. `scripts/check_deck.py` looks for the swoosh path marker
`M89.5 51.3c0-19.3` and fails the file if it is missing or if a stroke-based approximation is present.

**Provenance:** these files derive from the horizontal white lockup shipped in the production
Solventum IT Scorecard application (`public/solventum-logo-horz-white.svg`). The white file is a
byte-for-byte copy; the dark variant swaps only the wordmark fill (`#fff` -> `#10201b`); the mark
variant keeps only the `#05dd4d` swoosh path with its measured bounding box as the viewBox. If an
official Solventum brand-kit SVG supersedes this, drop it in and keep the filenames.

---

## Colour tokens

Both shells declare these on `:root`. Use the variable, not the hex, so a brand refresh is one edit.

| Token | Hex | Use for |
|---|---|---|
| `--primary` | `#143829` | Deep green chrome: brand bar, table headers, numbered badges |
| `--primary-2` | `#1c4d35` | Second stop of the chrome gradient |
| `--brand` | `#05dd4d` | The logo green. **Accents and large fills only** — see the contrast rule |
| `--brand-deep` | `#0a7d38` | The green that is legible on white: eyebrows, links, rules, bullets, small text |
| `--ink` | `#10201b` | Primary text, headings |
| `--slate` | `#3a4a45` | Body copy |
| `--muted` | `#6b7a75` | Secondary text, labels, captions |
| `--bg` | `#ffffff` | Slide / page surface |
| `--canvas` | `#f2f5f2` | Area behind the slide, section bands |
| `--panel` | `#f4f8f6` | Card and table-header fill |
| `--border` | `#e2e9e5` | All hairlines and card borders |
| `--green` | `#16a34a` | Status: on target, shipped, low risk |
| `--amber` | `#d97706` | Status: watch, next, medium risk |
| `--red` | `#dc2626` | Status: at risk, blocked, high risk |
| `--indigo` | `#4f46e5` | Neutral fourth accent, for "vision / future" items that are not a health status |
| `--header-grad` | `linear-gradient(135deg,#143829 0%,#1c4d35 100%)` | Brand bar |
| `--title-grad` | `linear-gradient(135deg,#06301c 0%,#0b5c2f 55%,#0a7d38 100%)` | Title and section-divider slides |
| `--inverse-bg` | `#06301c` | Inverse callout / closing panel background |
| `--inverse-ink` | `#eafff1` | Text on `--inverse-bg` |

### The contrast rule (the one that bites)

`#05dd4d` on white is roughly **1.7:1** — far below the 4.5:1 WCAG AA threshold for body text and
3:1 for large text. It looks fine on a monitor in a dark room and disappears on a projector.

- **Text, thin rules, small icons, bullets on a light surface -> `--brand-deep` (`#0a7d38`).**
- **`--brand` (`#05dd4d`) is for:** the swoosh in the logo, accents *on the deep green* (where it has
  roughly 7:1), and solid fills 24px or larger (progress bars, chips, bold rules).

`check_deck.py` flags `#05dd4d`/`var(--brand)` used as a `color:` on a light surface.

---

## Typography

```css
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, system-ui, sans-serif;
```

A system stack, deliberately. A webfont means a network request, which breaks the "one file that
works offline and emails cleanly" guarantee, and a missing font at render time is a worse defect
than a slightly different one. Headings carry `letter-spacing:-0.02em` so they read tight and
modern at large sizes.

Baseline scale (both shells ship these; scale *up* to fill a slide, not down):

| Element | Size |
|---|---|
| Title-slide `h1` | 46px / 800 |
| Slide `h2` | 27px / 800 |
| Section eyebrow | 12px / 800, `letter-spacing:.14em`, uppercase |
| Body copy, list items | 15px / 1.55 |
| Card body | 13px |
| Table body | 13px |
| Table header, labels | 11px / 800, uppercase, `.06em` |

---

## Geometry

| Property | Value |
|---|---|
| Card / panel radius | 12px |
| Slide radius (deck) | 16px |
| Chip / tag / pill radius | 20px (full round) |
| Numbered badge radius | 9px (square-ish) or 50% (circle) — pick one per deck |
| Hairline | `1px solid var(--border)` |
| Card shadow | none on cards; the *slide* carries `0 24px 70px rgba(0,0,0,.45)` against the dark stage |
| Slide padding | `46px 52px 60px` (bottom leaves room for the footer) |
| Content max-width | 1120px deck, 980px one-pager |
